
/*
 APPLICATION COFIGRATION FILE
*/
import { NgModule, InjectionToken } from '@angular/core';
import { CommonModule } from '@angular/common';
import { environment } from '../environments/environment';
export let APP_CONFIG = new InjectionToken<AppConfig>('app.config');

export class AppConfig {
  apiEndpoint: String;
  apiAssetsUrl: String;
  apiBaseUrl: String;
  apiImageUrl: String;
}

export const APP_DI_CONFIG: AppConfig = {
   apiEndpoint: environment.apiEndpoint,
     apiAssetsUrl: environment.apiAssetsUrl,
     apiBaseUrl: environment.apiBaseUrl,
     apiImageUrl: environment.apiImageUrl,

 // apiEndpoint: '',
 // apiAssetsUrl: ''
 // apiEndpoint: 'http://127.0.0.1:3000/api/admin/',
// apiAssetsUrl: 'http://127.0.0.1:3000/'
};
@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers: [{
    provide: APP_CONFIG,
    useValue: APP_DI_CONFIG
  }]
})
export class AppConfigModule { }
