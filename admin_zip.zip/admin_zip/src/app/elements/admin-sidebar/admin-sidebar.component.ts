import { Component, OnInit, Renderer2, Inject, ElementRef, ViewChild, Input } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import Swal from 'sweetalert2';
import { User } from '../../models/user';

import { UserService } from '../../services/user/user.service';
import { CommonService } from '../../services/common.service';
import { AuthService } from '../../services/auth.service';
import { APP_CONFIG, AppConfig } from '../../app-config.module';
import { Router, Event as NavigationEvent, NavigationEnd, ActivatedRoute, NavigationStart } from '@angular/router';

import { filter, map, mergeMap } from 'rxjs/operators';
// https://stackblitz.com/edit/angular-r6-detect-browser-refresh?file=src%2Fapp%2Fpage-a%2Fpage-a.component.html
@Component({
  selector: 'app-admin-sidebar',
  templateUrl: './admin-sidebar.component.html',
  styleUrls: ['./admin-sidebar.component.css'],
  providers: [
    UserService,
    CommonService,
    AuthService
  ]
})

export class AdminSidebarComponent implements OnInit {
  @Input() isLoggedIn: boolean;
  public loading = false;
  public userModel: User;
  public isCollapsed = false;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private commonService: CommonService,
    private userService: UserService,
    private authService: AuthService,
    @Inject(APP_CONFIG) private config: AppConfig,
  ) {
    this.userModel = new User();
  }
  ngOnInit() {
    /*const el = this.activatedRoute.children[0].snapshot.data.header_class;
    if (el && el !== undefined) {
      document.getElementById('headfix').removeAttribute('class');
      document.getElementById('headfix').classList.add(el);
    }

    this.router.events.pipe(
      filter((event) => event instanceof NavigationEnd),
      map(() => this.activatedRoute),
      map((route) => {
        while (route.firstChild) {
          route = route.firstChild;
        }
        return route;
      }),
      filter((route) => route.outlet === 'primary'),
      mergeMap((route) => route.data)
    ).subscribe(data => {
      document.getElementById('headfix').removeAttribute('class');
      const elementClass = this.activatedRoute.children[0].snapshot.data.header_class;
      if (elementClass && elementClass !== undefined) {
        document.getElementById('headfix').classList.add(elementClass);
      }
    });*/
    if (this.authService.isAuthenticated()) {
      // get logged in user data
      this.commonService.getService(this.config.apiEndpoint + 'getUser', this.userModel)
        .pipe(map(data => data.body))
        .subscribe(data => {
          this.loading = false;
          if (data.statusCode === 200) {
            this.userModel = {
              first_name: (data.data && data.data.first_name !== undefined) ? data.data.first_name : '',
              image: (data.data && data.data.profilePic !== undefined) ? data.data.profilePic : ''
            };
          } else {
            this.commonService.response(data.message, 'error');
          }
        }, error => {
          this.loading = false;
          this.commonService.response(error.message, 'error');
        });
    }
  }

  logout() {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to logout',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Logout!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        this.loading = true;

        // tslint:disable-next-line:max-line-length
        const Authorization = (JSON.parse(localStorage.getItem('adminUserInfo')) === null || JSON.parse(localStorage.getItem('adminUserInfo')) === undefined) ? '' : JSON.parse(localStorage.getItem('adminUserInfo'));
        console.log('Authorization', Authorization);
        this.userService.logout(Authorization)
          .pipe(map(data => data.body))
          .subscribe(data => {
            this.loading = false;
            if (data.statusCode === 200) {
              this.loading = false;
              this.authService.logout();
            } else {
              Swal.fire(data.message);
            }
          }, error => {
            this.loading = false;
            Swal.fire(error.error.message);
          });
      }
    });
  }

}


