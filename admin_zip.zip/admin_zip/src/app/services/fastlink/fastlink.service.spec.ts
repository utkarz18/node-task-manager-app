import { TestBed, inject } from '@angular/core/testing';

import { FastlinkService } from './fastlink.service';

describe('FastlinkService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FastlinkService]
    });
  });

  it('should be created', inject([FastlinkService], (service: FastlinkService) => {
    expect(service).toBeTruthy();
  }));
});
