import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { APP_CONFIG, AppConfig } from '../../app-config.module';
import { CommonService } from '../../services/common.service';

@Injectable()
export class FastlinkService {

  constructor(
    private commonService: CommonService,
    private http: HttpClient,
    @Inject(APP_CONFIG) private config: AppConfig
  ) { }

  getYodleeJwtToken(payload, is_params) {
    return this.commonService.getService(this.config.apiEndpoint + 'getYodleeToken', payload, is_params);
  }
}
