import { Injectable, Inject } from '@angular/core';
import { User } from '../../models/user';
import { CommonService } from '../../services/common.service';
import { APP_CONFIG, AppConfig } from '../../app-config.module';
import { ChangeEmailModel } from '../../models/user';
import { forkJoin, BehaviorSubject } from 'rxjs';

@Injectable()
export class UserService {

  constructor(
    private commonService: CommonService,
    @Inject(APP_CONFIG) private config: AppConfig) { }

  /*  USER LOGIN SERVICE */
  login(user: User) {
    return this.commonService.createService(this.config.apiEndpoint + 'login', user);
  }

  /*  USER SIGNUP SERVICE */
  signUp(user: User) {
    const request = { email: user.email, password: user.password };
    return this.commonService.createService(this.config.apiEndpoint + 'signUp', request);
  }

  /*  USER FORGOT PASSWORD SERVICE */
  forgotPassword(user: User) {
    return this.commonService.createService(this.config.apiEndpoint + 'forgotPassword', user);
  }


  logout(user: User) {
    return this.commonService.createService(this.config.apiEndpoint + 'logout', user);
  }

  resetPassword(user: User) {
    return this.commonService.createService(this.config.apiEndpoint + 'resetPassword', user);
  }

  resendVerification(user: User) {
     const request = { email: user.email };
    return this.commonService.createService(this.config.apiEndpoint + 'resendVerification', user);
  }

  updateUser(user: User) {
    const request = { name: user.first_name };
    return this.commonService.putService(this.config.apiEndpoint + 'updateProfile', request);
  }

  changeEmail(payload: ChangeEmailModel) {
    return this.commonService.createService(this.config.apiEndpoint + 'changeEmail', payload);
}

getYodleeJwtToken(payload, is_params) {
  return this.commonService.getService(this.config.apiEndpoint + 'getYodleeToken', payload, is_params);
}

saveYodleeBankDetails(data) {
   return this.commonService.createService(this.config.apiEndpoint + 'saveYodleeBankDetails', data);
}

getUserDetail(payload, is_params) {
  return this.commonService.getService(this.config.apiEndpoint + 'getUserDetail', payload, is_params);
}

requestDataFromMultipleSources(queue) {
  return forkJoin(queue);
}

}
