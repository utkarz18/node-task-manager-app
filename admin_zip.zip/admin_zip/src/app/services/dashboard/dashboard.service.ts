import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { APP_CONFIG, AppConfig } from '../../app-config.module';
import { CommonService } from '../../services/common.service';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(
    private commonService: CommonService,
    private http: HttpClient,
    @Inject(APP_CONFIG) private config: AppConfig
  ) { }

  getDetail(payload, is_params) {
    return this.commonService.getService(this.config.apiEndpoint + 'getUsersList', payload, is_params);
  }
  userActions(payload) {
    return this.commonService.createService(this.config.apiEndpoint + 'changeStatus', payload);
  }
  getVaultDetail(payload, is_params) {
    return this.commonService.getService(this.config.apiEndpoint + 'getVaultDetail', payload, is_params);
  }

  getFolderMemberListing(payload, is_params) {
    return this.commonService.getService(this.config.apiEndpoint + 'getFolderMemberListing', payload, is_params);
  }
  deleteUser(payload) {
    return this.commonService.createService(this.config.apiEndpoint + 'deleteUser', payload);
  }

  verifyUser(payload) {
    return this.commonService.createService(this.config.apiEndpoint + 'verifyUser', payload);
  }

}
