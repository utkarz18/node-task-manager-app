import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import * as _ from 'lodash';

@Injectable()
export class AuthService {

  constructor(
    private router: Router
  ) { }

  /* STORE USER TOKEN AND OTHER DETAILS  */
  storeUserInfo(input: any, params: any) {
    const parameter = JSON.parse(params);
    console.log('parameter', parameter);
    let user_data = {};
    if (parameter.remember_me && parameter.remember_me === true) {
      user_data = {
        remember_me: parameter.remember_me,
        email: parameter.email,
        password: parameter.password
      };
      localStorage.setItem('adminUserCredentials', JSON.stringify(user_data));
    } else {
      this.removeUserInfo('adminUserCredentials');
    }
    localStorage.setItem('adminUserInfo', JSON.stringify({ token: input.body.data.accessToken }));
  }

  removeUserInfo(input?: any) {
    let collection;
    if (input && input !== undefined) {
      collection = [input];
    } else {
      collection = ['adminUserInfo', 'adminUserCredentials'];
    }
    _.forEach(collection, function (value) {
      localStorage.removeItem(value);
    });
  }

  /* GET LOGIN USER INFORMATION  */
  getUserInfo() {
    return JSON.parse(localStorage.getItem('adminUserInfo'));
  }

  getUserCredentialsInfo() {
    return JSON.parse(localStorage.getItem('adminUserCredentials'));
  }

  /* USER LOGOUT SERVICE  */
  logout(): boolean {
    const user_data = this.getUserCredentialsInfo();
    if (user_data !== undefined && _.has(user_data, 'remember_me')) {
      this.removeUserInfo('adminUserInfo');
    } else {
      this.removeUserInfo();
    }
    this.router.navigate(['/login']);
    return true;
  }

  /* IS USER AUTHENTICATED */
  isAuthenticated(): boolean {
    const auth_token: any = JSON.parse(localStorage.getItem('adminUserInfo')) || '';
    if (auth_token.token && auth_token.token !== undefined) {
      return true;
    } else {
      return false;
    }
  }

}
