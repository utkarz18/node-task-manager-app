import {  Component, OnInit, Output, EventEmitter, ViewChild, AfterViewInit, Input, AfterContentInit } from '@angular/core';
import { APP_CONFIG, AppConfig } from '../../app-config.module';
import { Inject } from '@angular/core';
import { map } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { BsModalRef, BsModalService, ModalDirective } from 'ngx-bootstrap/modal';
import { NewsModel } from '../../models/news';
import { CommonService } from '../../services/common.service';
import { DashboardService } from '../../services/dashboard/dashboard.service';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as _ from 'lodash';
import * as moment from 'moment';

@Component({
  selector: 'app-news-detail',
  templateUrl: './news-detail.component.html',
  styleUrls: ['./news-detail.component.scss']
})
export class NewsDetailComponent implements OnInit, AfterViewInit {
  @Output() pageAddedEmitter: EventEmitter<any> = new EventEmitter();
  public newsModel: NewsModel = <NewsModel>{};
  @Input() news_id: String;
  public heading;
  public image;
  public imageUrl;
  public content;
  public saveModel: any;
  public total: Number = 0;
  public page: Number = 1;
  public limit: Number = 1;
  public loading: boolean = false;
  public editorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '200',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: 'Enter text here...',
    imageEndPoint: '',
    toolbar: [
      [
        'bold',
        'italic',
        'underline',
        'strikeThrough',
        'superscript',
        'subscript'
      ],
      ['fontName', 'fontSize', 'color'],
      [
        'justifyLeft',
        'justifyCenter',
        'justifyRight',
        'justifyFull',
        'indent',
        'outdent'
      ],
      ['cut', 'copy', 'delete', 'removeFormat', 'undo', 'redo'],
      [
        'paragraph',
        'blockquote',
        'removeBlockquote',
        'horizontalLine',
        'orderedList',
        'unorderedList'
      ],
      ['link', 'unlink'] // 'image', 'video'
    ]
  };
  constructor( @Inject(APP_CONFIG) private config: AppConfig,
  private route: ActivatedRoute,
  private commonService: CommonService,
  private modalService: BsModalService,
  private router: Router,
  private http: HttpClient,
  public bsModalRef: BsModalRef
) { }

ngOnInit() {
  this.loading = true;
  if (this.news_id) {
    this.getNewsdata();
  }
}

ngAfterViewInit() {
  setTimeout(() => {
    this.loading = false;
  }, 1000);
}

getNewsdata() {
  this.loading = true;
    this.commonService
      .getService(this.config.apiEndpoint + 'viewNews', { id: this.news_id }, true)
      .pipe(map((data) => data.body))
      .subscribe(
        (data) => {
          this.loading = false;
          if (data.statusCode === 200) {
            this.imageUrl = this.config.apiImageUrl;
            this.newsModel = data.data;
          } else {
            this.commonService.response(data.message, 'error');
          }
        },
        (error) => {
          this.loading = false;
          this.commonService.response(error.message, 'error');
        }
      );
}

upload(event: any) {
  this.loading = true;
  const elem = event.target;
  if (elem.files.length > 0) {
    const formData = new FormData;
    formData.append('image', elem.files[0]);
    formData.append('filename', elem.files[0].name);
    this.commonService.uploadFile(this.config.apiEndpoint + 'uploadFile', formData)
      .subscribe((data: any) => {
        event.srcElement.value = null;
        this.loading = false;
        if (data.statusCode === 200) {
          this.newsModel.image_url = data.data.imageUrl;
          this.newsModel.image = data.data.fileName;
          // this.commonService.response(data.message, 'success');
        } else {
          this.commonService.response(data.message, 'error');
        }
      }, (data: any) => {
        this.loading = false;
        this.commonService.response(data.message, 'error');
      });
  }
}

editupload(event: any) {
  this.loading = true;
  const elem = event.target;
  if (elem.files.length > 0) {
    const formData = new FormData;
    formData.append('image', elem.files[0]);
    formData.append('filename', elem.files[0].name);
    this.commonService.uploadFile(this.config.apiEndpoint + 'uploadFile', formData)
      .subscribe((data: any) => {
        event.srcElement.value = null;
        this.loading = false;
        if (data.statusCode === 200) {
          this.newsModel.image_url = data.data.imageUrl;
          this.newsModel.image = data.data.fileName;
          // this.commonService.response(data.message, 'success');
        } else {
          this.commonService.response(data.message, 'error');
        }
      }, (data: any) => {
        this.loading = false;
        this.commonService.response(data.message, 'error');
      });
  }
}


saveFaq() {
 // console.log('this.newsModel', this.newsModel);
  this.loading = true;
  let url = '';
  if (this.newsModel._id !== undefined) {
    url = 'editNews';
   this.saveModel = {
      id: this.newsModel._id,
      title: this.newsModel.title,
      image: this.newsModel.image,
      image_url: this.newsModel.image_url,
      content: this.newsModel.content,
      posted_date: moment(this.newsModel.posted_date).format('YYYY-MM-DD')
    };
  } else {
    url = 'createNews';
    this.saveModel = {
      title: this.newsModel.title,
      image: this.newsModel.new_name,
      image_url: this.newsModel.image_url,
      content: this.newsModel.content,
      posted_date: moment(this.newsModel.posted_date).format('YYYY-MM-DD')
    };
  }
  console.log(this.saveModel);
  this.commonService
    .createService(`${this.config.apiEndpoint}${url}`, this.saveModel)
    .pipe(map((data) => data.body))
    .subscribe(
      (data) => {
        this.loading = false;
        if (data.statusCode === 200) {
          setTimeout(() => {
            this.bsModalRef.hide();
            this.pageAddedEmitter.emit();
          }, 1000);
          this.commonService.response(data.message, 'success');
          this.commonService.closeSwal(3000);
        } else {
          this.commonService.response(data.message, 'error');
        }
      },
      (error) => {
        this.loading = false;
        this.commonService.response(error.message, 'error');
      }
    );
  }

}
