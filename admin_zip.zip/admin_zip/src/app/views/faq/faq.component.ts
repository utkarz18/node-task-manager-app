import {
  Component,
  OnInit,
  Inject,
  ViewChild,
  AfterViewInit
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { APP_CONFIG, AppConfig } from 'src/app/app-config.module';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../../services/common.service';
import { FaqModel } from '../../models/faq';
import { HttpClient } from '@angular/common/http';
import { Subject, Observable } from 'rxjs';
import {
  map,
  debounceTime,
  distinctUntilChanged,
  mergeMap,
  tap
} from 'rxjs/operators';
import {
  BsModalRef,
  BsModalService,
  ModalDirective
} from 'ngx-bootstrap/modal';
import { FaqDetailComponent } from '../faq-detail/faq-detail.component';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FaqComponent implements OnInit, AfterViewInit {
  public faqs: FaqModel[] = [];
  public loading: boolean = false;
  public total: number = 0;
  public page: number = 1;
  public limit: number = 1;
  public bsModalRef: BsModalRef;

  constructor(
    private route: ActivatedRoute,
    private commonService: CommonService,
    private router: Router,
    private http: HttpClient,
    private modalService: BsModalService,
    @Inject(APP_CONFIG) private config: AppConfig
  ) {}

  ngOnInit() {
    this.loading = true;
    this.getDetail(1);
  }
  ngAfterViewInit() {
    setTimeout(() => {
      this.loading = false;
    }, 1000);
  }

  getDetail(page: number = 1): any {
    this.loading = true;
    this.commonService
      .getService(this.config.apiEndpoint + 'getFaqs', { page: page }, true)
      .pipe(map((data) => data.body))
      .subscribe(
        (data: any) => {
          this.loading = false;
          if (data.statusCode === 200) {
            this.faqs = data.data.faqData;
            this.total = data.data.total;
            this.page = page;
            this.limit = 10;
          } else {
            this.commonService.response(data.message, 'error');
          }
        },
        (error) => {
          this.loading = false;
          this.commonService.response(error.message, 'error');
        }
      );
  }
  editPageModal(data) {
    let initialState = {};
    if (data._id) {
      initialState = {
        faq_id: data._id,
        title: 'Edit Faq'
      };
    } else {
      initialState = {
        title: 'Add Faq'
      };
    }
    this.bsModalRef = this.modalService.show(FaqDetailComponent, {
      initialState
    });
    this.bsModalRef.content.pageAddedEmitter.subscribe(
      this.onPageAdded.bind(this)
    );
    this.bsModalRef.content.closeBtnName = 'Cancel';
  }
  onPageAdded() {
    this.getDetail(1);
  }

  deleteFaq(id) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to delete this faq',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        this.loading = true;
        this.commonService.createService(this.config.apiEndpoint + 'deleteFaq', { id: id })
          .pipe(map((data) => data.body))
          .subscribe(
            (data) => {
              this.loading = false;
              if (data.statusCode === 200) {
                 this.getDetail(1);
                this.commonService.response(data.message, 'success');
                this.commonService.closeSwal(2000);
              } else {
                this.commonService.response(data.message, 'error');
              }
            },
            (error) => {
              this.loading = false;
              this.commonService.response(error.message, 'error');
            }
          );
      }
    });
  }
}
