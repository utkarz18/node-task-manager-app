import { Component, OnInit, Inject, ViewChild, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { APP_CONFIG, AppConfig } from 'src/app/app-config.module';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../../services/common.service';
import { DashboardService } from '../../services/dashboard/dashboard.service';
import { FolderCreatedModel } from '../../models/vault';
import { HttpClient } from '@angular/common/http';
import { Subject, Observable } from 'rxjs';
import { map, debounceTime, distinctUntilChanged, mergeMap, tap } from 'rxjs/operators';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  providers: [
    CommonService,
    DashboardService
  ]
})
export class DashboardComponent implements OnInit, AfterViewInit {

  constructor(
    @Inject(APP_CONFIG) private config: AppConfig) { }

  ngOnInit() {
  }
  ngAfterViewInit() {
  }

}



