import { Component, OnInit, Inject, ViewChild, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { APP_CONFIG, AppConfig } from 'src/app/app-config.module';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../../services/common.service';
import { NewsModel } from '../../models/news';
import { HttpClient } from '@angular/common/http';
import { Subject, Observable } from 'rxjs';
import { map, debounceTime, distinctUntilChanged, mergeMap, tap } from 'rxjs/operators';
import { BsModalRef, BsModalService, ModalDirective } from 'ngx-bootstrap/modal';
import { NewsDetailComponent } from '../news-detail/news-detail.component';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.scss']
})
export class NewsComponent implements OnInit {
  public news: Array<NewsModel> = [];
  private loading: boolean = false;
  public total: number = 0;
  public page: number = 1;
  public limit: number = 1;
  public bsModalRef: BsModalRef;

  constructor( private route: ActivatedRoute,
    private commonService: CommonService,
    private router: Router,
    private http: HttpClient,
    private modalService: BsModalService,
    @Inject(APP_CONFIG) private config: AppConfig) { }

    ngOnInit() {
      this.getDetail(1);
    }

    getDetail(page: number = 1): any {
      this.loading = true;
      this.commonService.getService(this.config.apiEndpoint + 'getNews', { page: page }, true)
        .pipe(map((data) => data.body))
        .subscribe(
          (data: any) => {
            this.loading = false;
            if (data.statusCode === 200) {
              this.news = data.data.newsData;
              this.total = data.data.total;
              this.page = page;
              this.limit = 10;
            } else {
              this.commonService.response(data.message, 'error');
            }
          },
          (error) => {
            this.loading = false;
            this.commonService.response(error.message, 'error');
          }
        );
    }


    editNewsModal(data) {
      let initialState = {};
      if (data._id) {
        initialState = {
          news_id: data._id,
          heading: 'Edit News'
        };
      } else {
        initialState = {
          heading: 'Add News'
        };
      }
      this.bsModalRef = this.modalService.show(NewsDetailComponent, {
        initialState
      });
      this.bsModalRef.content.pageAddedEmitter.subscribe(
        this.onNewsAdded.bind(this)
      );
      this.bsModalRef.content.closeBtnName = 'Cancel';
    }

    onNewsAdded() {
      this.getDetail(1);
    }

    deleteNews(id) {
      Swal.fire({
        title: 'Are you sure?',
        text: 'You want to delete this news',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, keep it'
      }).then((result) => {
        if (result.value) {
          this.loading = true;
          this.commonService.createService(this.config.apiEndpoint + 'deleteNews', { id: id })
            .pipe(map((data) => data.body))
            .subscribe(
              (data) => {
                this.loading = false;
                if (data.statusCode === 200) {
                   this.getDetail(1);
                  this.commonService.response(data.message, 'success');
                  this.commonService.closeSwal(2000);
                } else {
                  this.commonService.response(data.message, 'error');
                }
              },
              (error) => {
                this.loading = false;
                this.commonService.response(error.message, 'error');
              }
            );
        }
      });
    }
}
