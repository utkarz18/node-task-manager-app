import { Component, OnInit, Inject, ViewChild, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { APP_CONFIG, AppConfig } from 'src/app/app-config.module';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../../services/common.service';
import { DashboardService } from '../../services/dashboard/dashboard.service';
import { FolderCreatedModel } from '../../models/vault';
import { HttpClient } from '@angular/common/http';
import { Subject, Observable } from 'rxjs';
import { map, debounceTime, distinctUntilChanged, mergeMap, tap } from 'rxjs/operators';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss'],
  providers: [
    CommonService,
    DashboardService
  ]
})
export class UsersComponent implements OnInit, AfterViewInit {
  public users = [];
  public loading: boolean = false;
  public total: number = 0;
  public page: number = 1;
  public limit: number = 1;
  public searchTextChanged = new Subject;
  public subscription: any;

  constructor(
    private route: ActivatedRoute,
    private commonService: CommonService,
    private dashboardService: DashboardService,
    private router: Router,
    private http: HttpClient,
    @Inject(APP_CONFIG) private config: AppConfig) { }

  ngOnInit() {
    this.getDetail(1, '');

    this.subscription = this.searchTextChanged
      .pipe(
        debounceTime(500),
        distinctUntilChanged(),
      )
      .subscribe((data: any) => {
        this.getDetail(1, data);
      });
  }
  ngAfterViewInit() {
    setTimeout(() => {
      this.loading = false;
    }, 1000);
  }
  search($event) {
    this.searchTextChanged.next($event.target.value);
  }


  getDetail(page: number = 1, search: any): any {
    this.loading = true;
    this.dashboardService.getDetail({page: page, search: search !== undefined ? search : '' }, true)
      .pipe(map((data) => data.body))
      .subscribe(
        (data: any) => {
          this.loading = false;
          if (data.statusCode === 200) {
            this.users = data.data.userData;
            this.total = data.data.total;
            this.page = page;
            this.limit = 10;
          } else {
            this.commonService.response(data.message, 'error');
          }
        },
        (error) => {
          this.loading = false;
          this.commonService.response(error.message, 'error');
        }
      );
  }

  verifyUser(id) {
    console.log(id);
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to verify user',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
        this.loading = true;
        this.dashboardService.verifyUser({ id: id })
          .pipe(map(data => data.body))
          .subscribe(data => {
            this.loading = false;
            if (data.statusCode === 200) {
              this.getDetail(1, '');
              this.commonService.response(data.message, 'success');
              this.commonService.closeSwal(2000);
            } else {
              this.commonService.response(data.message, 'error');
            }
          }, error => {
            this.loading = false;
            this.commonService.response(error.message, 'error');
          });
      }
    });
  }

  userActions(id, status) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to change user status',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, change it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        this.loading = true;
        this.dashboardService.userActions({ id: id, status: status })
          .pipe(map(data => data.body))
          .subscribe(data => {
            this.loading = false;
            if (data.statusCode === 200) {
              this.getDetail(1, '');
              this.commonService.response(data.message, 'success');
              this.commonService.closeSwal(2000);
            } else {
              this.commonService.response(data.message, 'error');
            }
          }, error => {
            this.loading = false;
            this.commonService.response(error.message, 'error');
          });
      }
    });
  }

  deleteUser(id) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to delete this user',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        this.loading = true;
        this.dashboardService.deleteUser({ id: id})
          .pipe(map(data => data.body))
          .subscribe(data => {
            this.loading = false;
            if (data.statusCode === 200) {
              this.getDetail(1, '');
              this.commonService.response(data.message, 'success');
              this.commonService.closeSwal(2000);
            } else {
              this.commonService.response(data.message, 'error');
}
          }, error => {
            this.loading = false;
            this.commonService.response(error.message, 'error');
          });
      }
    });
  }

}
