import { Component, OnInit, Inject, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { APP_CONFIG, AppConfig } from 'src/app/app-config.module';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../../services/common.service';
import { UserService } from '../../services/user/user.service';
import { HttpClient } from '@angular/common/http';
import { Subject, Observable } from 'rxjs';
import { map, debounceTime, distinctUntilChanged, mergeMap, tap } from 'rxjs/operators';
import Swal from 'sweetalert2';
import * as io from 'socket.io-client';

@Component({
  selector: 'app-fastlink',
  templateUrl: './fastlink.component.html',
  styleUrls: ['./fastlink.component.scss'],
  providers: [
    CommonService,
    UserService
  ]
})


export class FastlinkComponent implements OnInit, AfterViewInit {
  @ViewChild('myDiv') myDiv: ElementRef<HTMLElement>;
  public userJwtToken = '';
  public userId: String;
  private url = 'http://localhost:3002';
  private socket;
  constructor(
    private route: ActivatedRoute,
    private commonService: CommonService,
    private userService: UserService,
    private router: Router,
    private http: HttpClient,
    @Inject(APP_CONFIG) private config: AppConfig) {
      this.socket = io(this.url);
    this.route.params.subscribe(params => this.userId = params.userId);
    }

  ngOnInit() {
    this.socket.on('connect', () => {
      console.log('socket connecteed');
      this.socket.emit('new-message', {message: 'abcsd' });
    });
    setTimeout(() => {
      this.myDiv.nativeElement.click();
      }, 200);
      this.socket.on('read-message', res => {
        console.log('resssssssssssssssss', res);
      });
  }

  ngAfterViewInit() {
    setTimeout(() => {
    }, 1000);
  }

  openFastLink() {
      this.userService.getYodleeJwtToken({'userId': this.userId}, true)
      .pipe(map((data) => data.body))
      .subscribe(
          (data: any) => {
           // this.loading = false;
            if (data.statusCode === 200) {
                this.userJwtToken = data.data.token;
                const thisVar = this;
                (<any>window).fastlink.open({
                  fastLinkURL: 'https://development.node.yodlee.com/authenticate/development-138/?channelAppName=tieredpreprod',
                  // tslint:disable-next-line:max-line-length
                  jwtToken: 'Bearer ' + this.userJwtToken,
                  params: '',
                  // tslint:disable-next-line:no-shadowed-variable
                  onSuccess: function(data) {
                    thisVar.RunCallbackFunction(data, function(err, res) {
                      if (err) {
                        thisVar.ngOnInit();
                        setTimeout(() => {
                          thisVar.commonService.response(err.message, 'error');
                        }, 1000);
                      }
                    });
                  },
                  // tslint:disable-next-line:no-shadowed-variable
                  onError: function(data) {
                      console.log('success2', data);
                  },
                  // tslint:disable-next-line:no-shadowed-variable
                  onExit: function(data) {
                    thisVar.bankAccountSuccess();
                    console.log('success3', data);
                   (<any>window).postMessage(JSON.stringify(data));
                  },
                  // tslint:disable-next-line:no-shadowed-variable
                  onEvent: function(data) {
                      console.log('success4', data);
                  }
              }, 'container-fastlink');
            } else {
              this.commonService.response(data.message, 'error');
            }
          },
          (error) => {
           // this.loading = false;datas
            this.commonService.response(error.message, 'error');
          }
      );
  }

  RunCallbackFunction(bankData, callback) {
    const bankModel = {
      user_id: this.userId,
      providerId: bankData.providerId,
      providerAccountId: bankData.providerAccountId
    };
    this.userService.saveYodleeBankDetails(bankModel)
    .pipe(map(data => data.body))
      .subscribe(
          (data: any) => {
            if (data.statusCode === 200) {
             // return 1;
            } else {
              callback(data);
            }
          });
  }

  bankAccountSuccess() {
    this.commonService.redirect('bankSuccess');
  }

}
