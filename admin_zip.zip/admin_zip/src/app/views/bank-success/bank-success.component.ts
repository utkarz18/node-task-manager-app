import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bank-success',
  templateUrl: './bank-success.component.html',
  styleUrls: ['./bank-success.component.scss']
})
export class BankSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
