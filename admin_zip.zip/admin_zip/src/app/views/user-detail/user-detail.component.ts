import { Component, OnInit, Inject, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from '../../services/common.service';
import { APP_CONFIG, AppConfig } from 'src/app/app-config.module';
import { map } from 'rxjs/operators';
import Swal from 'sweetalert2';
import { NgForm } from '@angular/forms';
import { BsModalService, BsModalRef, ModalDirective } from 'ngx-bootstrap/modal';
import { HttpClient } from '@angular/common/http';

import { UserService } from '../../services/user/user.service';
import { User , CountryModel } from '../../models/user';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.scss'],
  providers: [
    CommonService,
    UserService
  ]
})
export class UserDetailComponent implements OnInit, AfterViewInit {

  public loading: boolean = false;
  public userId: String;
  public userModel: User = {};
  public bsModalRef: BsModalRef;
  public submitted: Boolean = false;
  public countryModel: Array<CountryModel>[];

  constructor(
    private route: ActivatedRoute,
    private commonService: CommonService,
    private userService: UserService,
    private router: Router,
    private http: HttpClient,
    private modalService: BsModalService,
    @Inject(APP_CONFIG) private config: AppConfig) {
    this.route.params.subscribe(params => this.userId = params.id);
  }

  ngOnInit() {
    this.getVaultDetail();
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.loading = false;
    }, 1000);
  }

  getVaultDetail() {
    this.loading = true;

    const queue = [
      this.http.get(this.config.apiBaseUrl + 'countries/getCountries'),
      this.http.get(this.config.apiEndpoint + `getUserDetail?${this.commonService.arrayObjectToString({ userId: this.userId })}`)
    ];


    this.userService.requestDataFromMultipleSources(queue)
      .subscribe((data: any) => {
        this.loading = false;
        const [countryModel, userModel] = data;
        this.userModel = userModel.data.user;
        this.countryModel = countryModel.data;
      }, error => {
        this.loading = false;
        this.commonService.response(error.message, 'error');
      });

   /* this.commonService.getService(this.config.apiEndpoint + 'getUserDetail', { userId: this.userId}, true)
    .pipe(map(data => data.body))
    .subscribe(data => {
      this.loading = false;
      if (data.statusCode === 200) {
        this.userModel = data.data.user;
      } else {
        this.commonService.response(data.message, 'error');
      }
    }, error => {
      this.loading = false;
      this.commonService.response(error.message, 'error');
    });*/
  }

  updateUser() {
    console.log(this.userModel);
    this.loading = true;
    let url = '';
    url = 'updateUser';
    const userData = {
      _id: this.userModel._id,
      first_name: this.userModel.first_name,
      last_name: this.userModel.last_name,
      dob: this.userModel.dob,
      gender: this.userModel.gender,
      country: this.userModel.country,
      address: this.userModel.address,
      city: this.userModel.city,
      state: this.userModel.state,
      pinCode: this.userModel.pinCode
    };
    this.commonService
      .createService(`${this.config.apiEndpoint}${url}`, userData)
      .pipe(map((data) => data.body))
      .subscribe(
        (data) => {
          this.loading = false;
          if (data.statusCode === 200) {
            this.commonService.response(data.message, 'success');
          } else {
            this.commonService.response(data.message, 'error');
          }
        },
        (error) => {
          this.loading = false;
          this.commonService.response(error.message, 'error');
        }
      );
  }


}



