import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  ViewChild,
  AfterViewInit,
  Input,
  AfterContentInit
} from '@angular/core';
import { APP_CONFIG, AppConfig } from '../../app-config.module';
import { Inject } from '@angular/core';
import { map } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import {
  BsModalRef,
  BsModalService,
  ModalDirective
} from 'ngx-bootstrap/modal';
import { PageModel } from '../../models/pages';
import { CommonService } from '../../services/common.service';
import { DashboardService } from '../../services/dashboard/dashboard.service';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as _ from 'lodash';

@Component({
  selector: 'app-faq-detail',
  templateUrl: './faq-detail.component.html',
  styleUrls: ['./faq-detail.component.scss']
})
export class FaqDetailComponent implements OnInit, AfterViewInit {
  @Output() pageAddedEmitter: EventEmitter<any> = new EventEmitter();
  public pageModel: PageModel = <PageModel>{};
  @Input() faq_id: String;
  public title;
  public question;
  public my_vault_data = [];
  public total: Number = 0;
  public page: Number = 1;
  public limit: Number = 1;
  public loading: boolean = false;
  public editorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '200',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: 'Enter text here...',
    imageEndPoint: '',
    toolbar: [
      [
        'bold',
        'italic',
        'underline',
        'strikeThrough',
        'superscript',
        'subscript'
      ],
      ['fontName', 'fontSize', 'color'],
      [
        'justifyLeft',
        'justifyCenter',
        'justifyRight',
        'justifyFull',
        'indent',
        'outdent'
      ],
      ['cut', 'copy', 'delete', 'removeFormat', 'undo', 'redo'],
      [
        'paragraph',
        'blockquote',
        'removeBlockquote',
        'horizontalLine',
        'orderedList',
        'unorderedList'
      ],
      ['link', 'unlink'] // 'image', 'video'
    ]
  };
  constructor(
    @Inject(APP_CONFIG) private config: AppConfig,
    private route: ActivatedRoute,
    private commonService: CommonService,
    private modalService: BsModalService,
    private router: Router,
    private http: HttpClient,
    public bsModalRef: BsModalRef
  ) { }

  ngOnInit() {
    this.loading = true;
    if (this.faq_id) {
      this.getFaqdata();
    }
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.loading = false;
    }, 1000);
  }

  getFaqdata() {
    this.loading = true;
    this.commonService
      .getService(this.config.apiEndpoint + 'viewFaq', { id: this.faq_id }, true)
      .pipe(map((data) => data.body))
      .subscribe(
        (data) => {
          this.loading = false;
          if (data.statusCode === 200) {
            this.pageModel = data.data;
          } else {
            this.commonService.response(data.message, 'error');
          }
        },
        (error) => {
          this.loading = false;
          this.commonService.response(error.message, 'error');
        }
      );
  }

  saveFaq() {
    let url = '';
    if (this.pageModel._id !== undefined) {
      url = 'editFaq';
    } else {
      url = 'createFaq';
    }
    this.loading = true;
    this.commonService
      .createService(`${this.config.apiEndpoint}${url}`, this.pageModel)
      .pipe(map((data) => data.body))
      .subscribe(
        (data) => {
          this.loading = false;
          if (data.statusCode === 200) {
            setTimeout(() => {
              this.bsModalRef.hide();
              this.pageAddedEmitter.emit();
            }, 1000);
            this.commonService.response(data.message, 'success');
            this.commonService.closeSwal(3000);
          } else {
            this.commonService.response(data.message, 'error');
          }
        },
        (error) => {
          this.loading = false;
          this.commonService.response(error.message, 'error');
        }
      );
  }
}
