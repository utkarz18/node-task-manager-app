import { Component, OnInit, Inject, ViewChild, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { APP_CONFIG, AppConfig } from 'src/app/app-config.module';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../../services/common.service';
import { PageModel } from '../../models/pages';
import { HttpClient } from '@angular/common/http';
import { Subject, Observable } from 'rxjs';
import { map, debounceTime, distinctUntilChanged, mergeMap, tap } from 'rxjs/operators';
import { BsModalRef, BsModalService, ModalDirective } from 'ngx-bootstrap/modal';
import { PageDetailComponent } from '../page-detail/page-detail.component';

import Swal from 'sweetalert2';
@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss']
})
export class PagesComponent implements OnInit {
  public pages: PageModel[] = [];
  private loading: boolean = false;
  public total: number = 0;
  public page: number = 1;
  public limit: number = 1;
  public bsModalRef: BsModalRef;

  constructor(
    private route: ActivatedRoute,
    private commonService: CommonService,
    private router: Router,
    private http: HttpClient,
    private modalService: BsModalService,
    @Inject(APP_CONFIG) private config: AppConfig) { }

  ngOnInit() {
    this.getDetail(1);
  }

  getDetail(page: number = 1): any {
    this.loading = true;
    this.commonService.getService(this.config.apiEndpoint + 'getPages', { page: page }, true)
      .pipe(map((data) => data.body))
      .subscribe(
        (data: any) => {
          this.loading = false;
          if (data.statusCode === 200) {
            this.pages = data.data.pagesData;
            this.total = data.data.total;
            this.page = page;
            this.limit = 10;
          } else {
            this.commonService.response(data.message, 'error');
          }
        },
        (error) => {
          this.loading = false;
          this.commonService.response(error.message, 'error');
        }
      );
  }
  editPageModal(data) {
    const initialState = {
      page_id: data._id,
      title: data.meta_key
    };
    this.bsModalRef = this.modalService.show(PageDetailComponent, { initialState });
    this.bsModalRef.content.pageAddedEmitter.subscribe(this.onPageAdded.bind(this));
    this.bsModalRef.content.closeBtnName = 'Cancel';
  }
  onPageAdded() {
    this.getDetail(1);
  }
}
