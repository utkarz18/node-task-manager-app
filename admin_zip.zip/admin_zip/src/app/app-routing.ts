/*
##############################
 ALL TYPE OF COMPONENT WILL LOAD HERE AND ROUTING WILL BULID HERE
#############################
 */
import { Routes, RouterModule, CanActivate, CanActivateChild } from '@angular/router';
import { AuthGuardService as AuthGuard } from './services/auth-guard.service';
import { CommonService } from './services/common.service';

/* ADMIN LAYOUT COMPONENTS */
import { AdminLoginComponent } from './layouts/admin-login/admin-login.component';
import { AdminDashboardComponent } from './layouts/admin-dashboard/admin-dashboard.component';

/* ADMIN ELEMENT COMPONENTS */
import { AdminHeaderComponent } from './elements/admin-header/admin-header.component';
import { AdminFooterComponent } from './elements/admin-footer/admin-footer.component';
import { AdminSidebarComponent } from './elements/admin-sidebar/admin-sidebar.component';


import { LoginComponent } from './views/login/login.component';
import { DashboardComponent } from './views/dashboard/dashboard.component';
import { ProfileComponent } from './views/profile/profile.component';
import { ProfileImageComponent } from './views/profile-image/profile-image.component';


import { ForgotPasswordComponent } from './views/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './views/reset-password/reset-password.component';
import { VerificationComponent } from './views/verification/verification.component';
import { ChangePasswordComponent } from './views/change-password/change-password.component';
import { PagesComponent } from './views/pages/pages.component';
import { PageDetailComponent } from './views/page-detail/page-detail.component';
import { FaqComponent } from './views/faq/faq.component';
import { FaqDetailComponent } from './views/faq-detail/faq-detail.component';
import { FastlinkComponent } from './views/fastlink/fastlink.component';
import { UsersComponent } from './views/users/users.component';
import { BankSuccessComponent } from './views/bank-success/bank-success.component';
import { UserDetailComponent } from './views/user-detail/user-detail.component';
import { NewsComponent } from './views/news/news.component';
import { NewsDetailComponent } from './views/news-detail/news-detail.component';


const appRoutes: Routes = [
    {
        path: '',
        component: AdminLoginComponent, // Before Login Layout
        data: { class: '' },
        children: [
            { path: '', component: LoginComponent, pathMatch: 'full', data: { public: false, title: 'Login', class: 'header-bg' } },
            {
                path: 'login', component: LoginComponent, pathMatch: 'full', data: {
                    public: false,
                    title: 'Login',
                    header_class: ''
                }
            },
            {
                path: 'forgot-password', component: ForgotPasswordComponent, data: {
                    public: false,
                    title: 'Forgot Password',
                    header_class: ''
                }
            },
            { path: 'reset-password/:token', component: ResetPasswordComponent, data: { title: 'Reset Password', header_class: '' } },
            { path: 'verification/:token', component: VerificationComponent, data: { title: 'Verification', header_class: '' } },
            // tslint:disable-next-line:max-line-length
            { path: 'fastlink/:userId', component: FastlinkComponent, data: { public: false, title: 'FastLink', header_class: '' } },
            { path: 'bankSuccess', component: BankSuccessComponent, data: { public: false, title: 'Bank Success', header_class: '' } }
        ]
    },
    {
        path: '',
        canActivate: [AuthGuard],
        component: AdminDashboardComponent, // After Login Layout
        data: { class: '' },
        children: [
            {
                path: 'dashboard', component: DashboardComponent, pathMatch: 'full', data: {
                    isMain: true,
                    title: 'dashboard',
                    header_class: ''
                }
            }
        ]
    },
    {
        path: '',
        canActivate: [AuthGuard],
        component: AdminDashboardComponent, // After Login Layout
        data: { class: '' },
        children: [
            {
                path: 'users', component: UsersComponent, pathMatch: 'full', data: {
                    isMain: true,
                    title: 'User Management',
                    header_class: ''
                }
            }
        ]
    },
    {
        path: '',
        canActivate: [AuthGuard],
        component: AdminDashboardComponent, // After Login Layout
        data: { class: '' },
        children: [
            {
                path: 'user-detail/:id', component: UserDetailComponent, pathMatch: 'full', data: {
                    isMain: true,
                    title: 'User Detail',
                    header_class: ''
                }
            }
        ]
    },
    {
        path: '',
        canActivate: [AuthGuard],
        component: AdminDashboardComponent, // After Login Layout
        data: { class: '' },
        children: [
            {
                path: 'change-password', component: ChangePasswordComponent, pathMatch: 'full', data: {
                    title: 'Change Password', header_class: ''
                }
            }
        ]
    },
    {
        path: '',
        canActivate: [AuthGuard],
        component: AdminDashboardComponent, // After Login Layout
        data: { class: '' },
        children: [
            {
                path: 'pages', component: PagesComponent, pathMatch: 'full', data: {
                    isMain: true,
                    title: 'Content Management',
                    header_class: ''
                }
            }
        ]
    },
    {
        path: '',
        canActivate: [AuthGuard],
        component: AdminDashboardComponent, // After Login Layout
        data: { class: '' },
        children: [
            {
                path: 'faq', component: FaqComponent, pathMatch: 'full', data: {
                    isMain: true,
                    title: 'Faq Management',
                    header_class: ''
                }
            }
        ]
    },
    {
        path: '',
        canActivate: [AuthGuard],
        component: AdminDashboardComponent, // After Login Layout
        data: { class: '' },
        children: [
            {
                path: 'news', component: NewsComponent, pathMatch: 'full', data: {
                    isMain: true,
                    title: 'News Management',
                    header_class: ''
                }
            }
        ]
    },
    { path: '**', redirectTo: 'login' }
];
export const ROUTES = RouterModule.forRoot(appRoutes);
/*
######################
COMPONENTS WILL LOAD HERE
#####################
*/
export const COMPONENTS = [
    AdminLoginComponent,
    AdminDashboardComponent,
    AdminHeaderComponent,
    AdminFooterComponent,
    AdminSidebarComponent,
    LoginComponent,
    DashboardComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    ProfileComponent,
    VerificationComponent,
    ChangePasswordComponent,
    ProfileImageComponent,
    PagesComponent,
    PageDetailComponent,
    FaqComponent,
    FaqDetailComponent,
    FastlinkComponent,
    UsersComponent,
    BankSuccessComponent,
    UserDetailComponent,
    NewsComponent,
    NewsDetailComponent
];

export const PROVIDERS = [
    CommonService
];



export const DIRECTIVES = [

];





