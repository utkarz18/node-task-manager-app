export interface NewsModel {
    _id: String;
    title: String;
    image?: any;
    new_name: String;
    edit_name: String;
    content: Number;
    posted_date: any;
    status: Number;
    created_at: Number;
    updated_at: Number;
    image_url: String;
}
