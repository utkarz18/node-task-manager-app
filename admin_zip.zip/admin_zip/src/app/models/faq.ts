export interface FaqModel {
    id?: String;
    question: String;
    answer: String;
    status?: Number;
    created_at?: Number;
    updated_at?: Number;
}
