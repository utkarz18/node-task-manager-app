export interface PageModel {
    _id: String;
    meta_key: String;
    meta_value: String;
    status: Number;
    created_at: Number;
    updated_at: Number;
    question: String;
    answer: String;
}
