export interface AdsModel {
    id: any;
    category_id: any;
    link: any;
    file: any;
    stats_count: any;
    status: any;
    created_at: any;
    updated_at: any;
    category: {
        id: 1;
        name: String;
        slug: String;
        width: any;
        height: any;
    };
}
