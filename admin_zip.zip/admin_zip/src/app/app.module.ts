import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { COMPONENTS } from './app-routing';
import { AppConfigModule } from './app-config.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PageDetailComponent } from './views/page-detail/page-detail.component';
import { FaqDetailComponent } from './views/faq-detail/faq-detail.component';
import { NewsDetailComponent } from './views/news-detail/news-detail.component';
import { NgxLoadingModule } from 'ngx-loading';
import { BsDropdownModule, TabsModule, ModalModule, CollapseModule } from 'ngx-bootstrap';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgxPaginationModule } from 'ngx-pagination';

import { NgxEditorModule } from 'ngx-editor';

const ngxBootstrapI = [
  BsDropdownModule.forRoot(),
  TabsModule.forRoot(),
  BsDatepickerModule.forRoot(),
  //MomentModule,
  ModalModule.forRoot(),
  CollapseModule.forRoot()
];
const ngxBootstrapE = [
  BsDropdownModule,
  TabsModule,
  BsDatepickerModule,
  //MomentModule,
  ModalModule
];

@NgModule({
  declarations: [
    AppComponent,
    COMPONENTS
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    AppConfigModule,
    FormsModule,
    ReactiveFormsModule,
    NgxLoadingModule.forRoot({}),
    ngxBootstrapI,
    NgxEditorModule,
    NgxPaginationModule
  ],
  exports: [
    ngxBootstrapE
  ],
  providers: [],
  entryComponents: [PageDetailComponent, FaqDetailComponent, NewsDetailComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
