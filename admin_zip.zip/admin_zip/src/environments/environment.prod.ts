export const environment = {
  apiEndpoint: 'https://midas-touch-api.herokuapp.com/api/admin/',
  apiAssetsUrl: 'https://midas-touch-api.herokuapp.com/',
  apiBaseUrl: 'https://midas-touch-api.herokuapp.com/api/',
  apiImageUrl: 'https://midas-touch-api.herokuapp.com/assets/',
  production: true
};
