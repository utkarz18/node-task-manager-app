package com.sapient.feecalculator.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sapient.feecalculator.service.FeeCalculatorService;

@RestController
public class FeeCalculatorController {

	@Autowired
	FeeCalculatorService feeCalculatorService;
	
	@GetMapping("processTransactionFees")
	public String processTransactionFees() throws Exception
	{
		return feeCalculatorService.processTransactionFees();
	}
}
