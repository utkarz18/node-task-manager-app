package com.sapient.feecalculator.util;

public class Constants {

	public enum FILE_EXT {
		CSV("CSV"), EXCEL("XLSX");
		public String type;

		FILE_EXT(String type) {
			this.type = type;
		}
	}

	public enum TRANSACTION_TYPE {
		BUY("BUY"), SELL("SELL"), DEPOSIT("DEPOSIT"), WITHDRAW("WITHDRAW");
		private String type;

		TRANSACTION_TYPE(String type) {
			this.type = type;
		}

		public String getType() {
			return type;
		}
	}

	public enum PROCESSING_FEE {
		TEN(10), FIFTY(50), HUNDRED(100), FIVEHUNDRED(500);
		private Integer fee;

		PROCESSING_FEE(int fee) {
			this.fee = fee;
		}

		public Integer getFee() {
			return fee;
		}
	}

	public final static String SAMPLE_INPUT_FILE_PATH = "Sample_Input.csv";

}
