package com.sapient.feecalculator.service;

public interface FeeCalculatorService{
	
	public String processTransactionFees() throws Exception;

}
