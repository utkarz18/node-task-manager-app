package com.sapient.feecalculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeeCalculatorApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(FeeCalculatorApplication.class, args);
	}

}
