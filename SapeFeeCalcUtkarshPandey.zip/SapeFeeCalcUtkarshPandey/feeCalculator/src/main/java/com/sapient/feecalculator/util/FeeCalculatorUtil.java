package com.sapient.feecalculator.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.sapient.feecalculator.model.Transaction;

public class FeeCalculatorUtil {
	
	public static LocalDate parseDate(String date) {
		try{
			LocalDate localdate = LocalDate.parse(date, DateTimeFormatter.ofPattern("M/d/yyyy"));
			return localdate;
		}catch(Exception  ex){
			return null;
		}
	}
	
	public static void performFinalSort(List<Transaction> transactions) {
		Collections.sort(transactions, new Comparator<Transaction>() {

			@Override
			public int compare(Transaction trans1, Transaction trans2) {

				int comp1 = trans1.getClientId().compareTo(trans2.getClientId());
				if (comp1 == 0) {
					int comp2 = trans1.getTransactionType().compareTo(trans2.getTransactionType());
					if (comp2 == 0) {
						int comp3 = trans1.getTransactionDate().compareTo(trans2.getTransactionDate());
						if (comp3 == 0) {
							return trans1.getPriority().compareTo(trans2.getPriority());
						} else {
							return comp3;
						}

					} else {
						return comp2;
					}
				}
				return comp1;
			}

		});
	}
}
