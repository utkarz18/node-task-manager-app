package com.sapient.feecalculator.inputreaderImpl;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import com.sapient.feecalculator.inputreader.TransactionReader;
import com.sapient.feecalculator.model.Transaction;
import com.sapient.feecalculator.util.FeeCalculatorUtil;

@Component("csvTransactionReader")
public class CsvTransactionReader implements TransactionReader {

	@Override
	public List<Transaction> readFile(String filePath) throws IOException {
		File resource = new ClassPathResource(filePath).getFile();
		Reader reader = Files.newBufferedReader(resource.toPath());
		CSVParser csvParser = new CSVParser(reader,
				CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());
		return getTransctions(csvParser);
	}

	private List<Transaction> getTransctions(CSVParser csvParser) {
		List<Transaction> transactions = new ArrayList<>();
		csvParser.forEach(record -> {
			Transaction transaction = new Transaction();
			transaction.setExternalTransactionID(record.get("External Transaction Id"));
			transaction.setClientId(record.get("Client Id"));
			transaction.setSecurityId(record.get("Security Id"));
			transaction.setTransactionType(record.get("Transaction Type"));
			LocalDate date = FeeCalculatorUtil.parseDate((record.get("Transaction Date")));
			transaction.setTransactionDate(date);
			transaction.setMarketValue(Double.valueOf(record.get("Market Value")));
			boolean priority = record.get("Priority Flag").equalsIgnoreCase("Y");
			transaction.setPriority(priority);
			transactions.add(transaction);
		});

		return transactions;
	}

}
