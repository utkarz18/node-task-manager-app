package com.sapient.feecalculator.inputreader;

import java.util.List;

import com.sapient.feecalculator.model.Transaction;

public interface TransactionReader {

	public List<Transaction> readFile(String filePath) throws Exception;
}
