package com.sapient.feecalculator.serviceImpl;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.sapient.feecalculator.inputreader.TransactionReader;
import com.sapient.feecalculator.model.Transaction;
import com.sapient.feecalculator.service.FeeCalculatorService;
import com.sapient.feecalculator.util.Constants;
import com.sapient.feecalculator.util.FeeCalculatorUtil;

@Component
public class FeeCalculatorServiceImpl implements FeeCalculatorService {

	@Autowired
	@Qualifier("csvTransactionReader")
	TransactionReader csvTransactionReader;

	// Other readers can be extended using the same TransactionReader Interface
	// @Autowired
	// @Qualifier("excelTransactionReader")
	// TransactionReader excelTransactionReader;

	@Override
	public String processTransactionFees() throws Exception{
		List<Transaction> transactions = null;
		String filePath = Constants.SAMPLE_INPUT_FILE_PATH;
		String fileExtension = filePath.substring(filePath.lastIndexOf(".") + 1, filePath.length()).toUpperCase();
		Constants.FILE_EXT fileExt = Constants.FILE_EXT.valueOf(fileExtension);
		switch (fileExt) {
		case CSV:
			transactions = csvTransactionReader.readFile(filePath);
			break;
		// like above multiple file formats can be handled accordingly
		// case EXCEL:
		// transactions = excelTransactionReader.readFile(filePath));
		// break;
		default:
			System.out.println("Invalid file format");
		}
		return processTransactions(transactions);
	}
	
	private String processTransactions(List<Transaction> transactions)
	{
		Collections.sort(transactions);
		processItraDaytransactions(transactions);
		processNormalTransactions(transactions);
		FeeCalculatorUtil.performFinalSort(transactions);
		return printSummaryReport(transactions);
	}
	
	private void processItraDaytransactions(List<Transaction> transactions)
	{
		for(int i = 0; i < transactions.size() - 1; ++i)
		{
			Transaction t1 = transactions.get(i);
			Transaction t2 = transactions.get(i + 1);
			if(t1.getTransactionDate().equals(t2.getTransactionDate())
					&& t1.getClientId().equals(t2.getClientId())
					&& t1.getSecurityId().equals(t2.getSecurityId()))
			{
				Constants.TRANSACTION_TYPE type1 = Constants.TRANSACTION_TYPE.valueOf(t1.getTransactionType());
				Constants.TRANSACTION_TYPE type2 = Constants.TRANSACTION_TYPE.valueOf(t1.getTransactionType());
				if(!type1.equals(type2) && (type1.equals(Constants.TRANSACTION_TYPE.BUY) || type1.equals(Constants.TRANSACTION_TYPE.SELL))
					&& (type2.equals(Constants.TRANSACTION_TYPE.BUY) || type2.equals(Constants.TRANSACTION_TYPE.SELL)))
				{
					t1.setProcessingFee(Constants.PROCESSING_FEE.TEN.getFee());
					t2.setProcessingFee(Constants.PROCESSING_FEE.TEN.getFee());
					i++;
				}
	
			}
		}
	}
	
	private void processNormalTransactions(List<Transaction> transactions) {
		for (Transaction transaction : transactions) {
			int processingfee = 0;
			if (transaction.getPriority()) {
				processingfee = Constants.PROCESSING_FEE.FIVEHUNDRED.getFee();
				if (transaction.getProcessingFee() != null)
					processingfee += transaction.getProcessingFee();
				transaction.setProcessingFee(processingfee);

			} else {
				if(transaction.getTransactionType().equals(Constants.TRANSACTION_TYPE.SELL.getType())
						|| transaction.getTransactionType().equals(Constants.TRANSACTION_TYPE.WITHDRAW.getType()))
				{
					processingfee = Constants.PROCESSING_FEE.HUNDRED.getFee();
					if (transaction.getProcessingFee() != null)
						processingfee += transaction.getProcessingFee();
					transaction.setProcessingFee(processingfee);
				}
				else if(transaction.getTransactionType().equals(Constants.TRANSACTION_TYPE.BUY.getType())
						|| transaction.getTransactionType().equals(Constants.TRANSACTION_TYPE.DEPOSIT.getType()))
				{
					processingfee = Constants.PROCESSING_FEE.FIFTY.getFee();
					if (transaction.getProcessingFee() != null)
						processingfee += transaction.getProcessingFee();
					transaction.setProcessingFee(processingfee);
				}
			}
		}
	}
	
	private String printSummaryReport(List<Transaction> transactions)
	{
		StringBuffer sb = new StringBuffer();
		sb.append("<h1>Summary Report</h1>");
		sb.append("\n<table cellspacing = 15px>");
		sb.append("\n\t<tbody>");
		sb.append("\n\t<tr>");
		sb.append("\n\t<th>Client ID</th>");
		sb.append("\n\t<th>Transaction Type</th>");
		sb.append("\n\t<th>Transaction Date</th>");
		sb.append("\n\t<th>Priority</th>");
		sb.append("\n\t<th>Processing Fee</th>");
		sb.append("\n\t</tr>");
		transactions.forEach(transaction -> {
			String priority = transaction.getPriority() ? "Y" : "N";
			sb.append("\n\t<tr>");
			sb.append("\n\t<td>" + transaction.getClientId() + "</td>");
			sb.append("\n\t<td>" + transaction.getTransactionType() + "</td>");
			sb.append("\n\t<td>" + transaction.getTransactionDate() + "</td>");
			sb.append("\n\t<td>" + priority + "</td>");
			sb.append("\n\t<td>" + transaction.getProcessingFee() + "</td>");
			sb.append("\n\t</tr>");
		});
		sb.append("\n\t</tbody>");
		sb.append("\n\t</table>");
		return sb.toString();
	}
}
