package com.sapient.feecalculator.model;

import java.time.LocalDate;

public class Transaction implements Comparable<Transaction>{
	private String externalTransactionID;
	
    private String clientId;
    
    private String securityId;
    
    private String transactionType;
    
    private LocalDate transactionDate;
    
    private Double marketValue;
    
    private Boolean priority;
    
    private Integer processingFee;

	public String getExternalTransactionID() {
		return externalTransactionID;
	}

	public void setExternalTransactionID(String externalTransactionID) {
		this.externalTransactionID = externalTransactionID;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getSecurityId() {
		return securityId;
	}

	public void setSecurityId(String securityId) {
		this.securityId = securityId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public LocalDate getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Double getMarketValue() {
		return marketValue;
	}

	public void setMarketValue(Double marketValue) {
		this.marketValue = marketValue;
	}

	public Boolean getPriority() {
		return priority;
	}

	public void setPriority(Boolean priority) {
		this.priority = priority;
	}

	public Integer getProcessingFee() {
		return processingFee;
	}

	public void setProcessingFee(Integer processingFee) {
		this.processingFee = processingFee;
	}

	@Override
	public String toString() {
		return "Transaction [externalTransactionID=" + externalTransactionID + ", clientId=" + clientId
				+ ", securityId=" + securityId + ", transactionType=" + transactionType + ", transactionDate="
				+ transactionDate + ", marketValue=" + marketValue + ", priority=" + priority + ", processingFee="
				+ processingFee + "]";
	}

	@Override
	public int compareTo(Transaction other) {
		return this.getTransactionDate().compareTo(other.getTransactionDate()) > 1 ? -1 : 1;
	}
    
	
    
}
