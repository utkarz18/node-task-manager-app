'use strict';

const communication = require('../../../utils/communication');
const logger = require('@open-age/logger')('processors:user:crete');
const webConfig = require('config').get('adminServer');

const process = async(data, context) => {
    const log = logger.start('process');

    const user = await db.users.findById(data.id);

    const content = {
        template: 'admin-verify-user',
        data: {
            name: user.first_name,
            email: user.email
        }
    };
    context.logger = log;
    communication.forward(user, content, ['email', 'push'], false, context);

    log.end();
    return Promise.resolve();
};

exports.process = process;