'use strict';

const communication = require('../../../utils/communication');
const logger = require('@open-age/logger')('processors:user:crete');
const adminEmail = require('config').get('Support_Email');

const process = async(data, context) => {
    const log = logger.start('process');

    const user = await db.users.findById(data.id);
    const admin = {
        email: adminEmail
    };
    const content = {
        template: 'send-message',
        data: {
            name: user.first_name,
            email: user.email,
            phone: user.phone,
            reason: data.reason,
            contact_type: data.contact_type,
            message: data.message
        }
    };
    context.logger = log;
    communication.forward(admin, content, ['email'], false, context);

    log.end();
    return Promise.resolve();
};

exports.process = process;