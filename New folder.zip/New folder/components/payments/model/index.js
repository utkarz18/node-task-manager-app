'use strict';
const hooks = require('../hooks');

const payment = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    amountType: { type: String }, // recurring, roundup, one_time, cash_balance, sell, reward
    amountInDollars: { type: Number },
    amountInCents: { type: Number },
    stripeFeeInCents: { type: Number },
    conversionFee: { type: Number },
    currency: { type: String },
    type: { type: String }, // added, invested, withdrawn
    stripeChargeId: { type: String },
    recurring_interval: { type: String }, // day,month, week, bi-week
    payment_type: { type: String }, // credit/debit
    metal_investment: {
        gold: { type: Number, default: 0 },
        silver: { type: Number, default: 0 },
        platinum: { type: Number, default: 0 },
        palladium: { type: Number, default: 0 },
        rhodium: { type: Number, default: 0 },
    },
    plan_id: { type: String }, // plan id of stripe plan
    account_id: { type: mongoose.Schema.Types.ObjectId, ref: 'accounts' }, // account if on which payment or recurring setup
    status: { type: Number, default: 1 },
    created_at: { type: Number }
}, {
    versionKey: false
});


hooks.configure(payment);
module.exports = payment;