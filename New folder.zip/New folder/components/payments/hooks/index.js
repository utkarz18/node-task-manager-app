'use strict';

const moment = require('moment');

const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (payment) => {
    payment.pre('save', function(next) {
        next();
    });

    payment.post('save', async(doc) => {});

    payment.pre('find', function(next) {
        next();
    });

    payment.pre('findOne', function(next) {
        next();
    });
};