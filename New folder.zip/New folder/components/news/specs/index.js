'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    getNews: {
        description: 'Get news data',
        notes: 'Get news data)',
        tags: ['api', 'news'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.getNews.query,
            failAction: response.failAction
        }
    },
    newsDetail: {
        description: 'Get news detail',
        notes: 'Get news detail)',
        tags: ['api', 'news'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.newsDetail.query,
            failAction: response.failAction
        }
    }
};