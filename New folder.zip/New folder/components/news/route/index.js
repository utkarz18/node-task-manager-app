'use strict';
const api = require('../api');
const specs = require('../specs');

module.exports = [{
    method: 'GET',
    path: '/api/news/getNews',
    options: specs.getNews,
    handler: api.getNews
}, {
    method: 'GET',
    path: '/api/news/newsDetail',
    options: specs.newsDetail,
    handler: api.newsDetail
}];