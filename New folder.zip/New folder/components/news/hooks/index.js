'use strict';

const moment = require('moment');

const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (news) => {
    news.pre('save', function(next) {
        next();
    });

    news.post('save', async(doc) => {});

    news.pre('find', function(next) {
        next();
    });

    news.pre('findOne', function(next) {
        next();
    });
};