'use strict';

const mapper = require('../mapper');
const service = require('../service');
const path = require('path');

/* function to get the list all the news 
 * params : page no
 * output : list of news
 */
exports.getNews = async(request, h) => {
    const log = logger.start('news:api:getNews');
    try {
        const message = await service.getNews(request.query);
        log.end();
        return response.success(h, message);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

/* function to get the detail of news
 * params : news_id
 * output : news object
 */
exports.newsDetail = async(request, h) => {
    const log = logger.start('news:api:newsDetail');
    try {
        const message = await service.newsDetail(request.query);
        log.end();
        return response.success(h, message);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};