'use strict';
const hooks = require('../hooks');

const news = new mongoose.Schema({
    title: { type: String },
    image: { type: String },
    content: { type: String },
    posted_date: { type: String },
    status: { type: Number }, // 1- Active, 2- delete
    created_at: { type: Number },
    updated_at: { type: Number }
}, {
    versionKey: false
});


hooks.configure(news);
module.exports = news;