'use strict';

const md5 = require('md5');
const auth = require('../../../utils/auth');
const config = require('config');
const message = require('../../../utils/messages');

/* function to get the list all the news 
 * params : page no
 * output : list of news
 */
exports.getNews = async(params) => {
    const log = logger.start('news:service:getNews');

    var skip = (params.page - 1) * 10;
    const news = await db.news.find({ 'status': 1 }).skip(skip).limit(10);

    if (!news) {
        throw new Error(message.no_record);
    }

    const total = await db.news.count({ 'status': 1 });

    log.end();
    return {
        'message': message.news_fetch,
        'data': { 'newsData': news, 'total': total }
    };
};

/* function to get the detail of news
 * params : news_id
 * output : news object
 */
exports.newsDetail = async(params) => {
    const log = logger.start('news:service:newsDetail');

    const news = await db.news.findOne({ _id: params.news_id });

    if (!news) throw new Error(message.no_record);
    log.end();
    return {
        'message': message.news_fetch,
        'data': { 'newsData': news }
    };
};