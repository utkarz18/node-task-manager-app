'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    getCards: {
        description: 'Get user saved cards',
        notes: 'User cards',
        tags: ['api', 'razorpay'],
        validate: {
            query: validator.getCards.query,
            failAction: response.failAction
        }
    }
};