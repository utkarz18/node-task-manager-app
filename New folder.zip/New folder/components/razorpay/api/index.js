'use strict';

const mapper = require('../mapper');
const service = require('../service');
const path = require('path');

/*
 * function : get user saved cards
 * params : customer_id
 * output : success & failure with details
 */
exports.getCards = async(request, h) => {
    const log = logger.start('razorpay:api:getCards');
    try {
        const message = await service.getCards(request.query);
        log.end();
        return response.success(h, message);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};