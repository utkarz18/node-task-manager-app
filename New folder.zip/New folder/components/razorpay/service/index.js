'use strict';

const md5 = require('md5');
const twilio = require('twilio');
const razorpayCredentials = require('config').get('RAZORPAY_CREDENTIALS');
const auth = require('../../../utils/auth');
const message = require('../../../utils/messages');
const Razorpay = require('razorpay');
var request = require('request');

let rzp = new Razorpay({
    key_id: razorpayCredentials.key_id, // your `KEY_ID`
    key_secret: razorpayCredentials.key_secret // your `KEY_SECRET`
});

/*
 * function : get user saved cards
 * params : customer_id
 * output : success & failure with details
 */
exports.getCards = async(params) => {
    console.log('here');
    // const log = logger.start('razorpay:service:getCards');
    // var url = 'https://api.razorpay.com/v1/customers/cust_DJYDz5cVGKXGII/tokens';
    //   const res = await fetch(url);
    //   const data = await res.json();
    /*  let options = {};

      options.url = 'https://api.razorpay.com/v1/' + razorpayCredentials.key_id + '/' + razorpayCredentials.key_secret + 'customers/cust_DJYDz5cVGKXGII/tokens';
      options.method = 'GET';
      options.headers = {};
      options.json = true;
      // eslint-disable-next-line handle-callback-err
      request(options, function(error, response, body) {
          console.log('error', error);
          console.log('response', response);
          console.log('body', body);
      });


      return false; */

    const a = await rzp.customers.fetchToken('cust_DJYDz5cVGKXGII', 'card_DJYUUZPfuxvgk5');
    console.log(a);
    /*  log.end();
      return {
          'message': message.page_data,
          data: page
      }; */
};