'use strict';
const hooks = require('../hooks');

const reward = new mongoose.Schema({
    weight: { type: Number },
    tree: { type: Number },
    currency: { type: Number },
    currency_badge: { type: String },
    referral: { type: Number },
    referral_badge: { type: String }
}, {
    versionKey: false
});


hooks.configure(reward);
module.exports = reward;