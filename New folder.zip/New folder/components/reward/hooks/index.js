'use strict';

const moment = require('moment');

const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (reward) => {
    reward.pre('save', function(next) {
        next();
    });

    reward.post('save', async(doc) => {});

    reward.pre('find', function(next) {
        next();
    });

    reward.pre('findOne', function(next) {
        next();
    });
};