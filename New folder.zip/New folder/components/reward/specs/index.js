'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    getForest: {
        description: 'Get user forest',
        notes: 'User forest',
        tags: ['api', 'reward'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.getForest.query,
            failAction: response.failAction
        }
    }
};