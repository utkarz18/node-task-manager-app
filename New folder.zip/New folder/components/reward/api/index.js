'use strict';

const mapper = require('../mapper');
const service = require('../service');
const path = require('path');

/*
 * function : get user forest
 * params : 
 * output : success & failure with details
 */
exports.getForest = async(request, h) => {
    const log = logger.start('reward:api:getForest');
    try {
        const message = await service.getForest(request.userInfo);
        log.end();
        return response.success(h, message);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};