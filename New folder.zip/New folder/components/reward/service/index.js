'use strict';

const md5 = require('md5');
const message = require('../../../utils/messages');

/*
 * function : get user forest
 * params : 
 * output : success & failure with details
 */
exports.getForest = async(params) => {
    const log = logger.start('reward:service:getForest');

    /* console.log('params', params.userRegisterationTime);
     let dates = timeAgo(1568891125 * 1000); // moment('20190909', 'YYYYMMDD').fromNow();
     console.log('dates', dates);
     return false; */

    let treeBadge;
    let currenyBadge;
    let referralBadge;

    let oz = 0.3;
    let currency = 120;
    let referral = await db.invites.count({ invited_by: params.id, status: 1 });

    if (oz >= 0.1) {
        const addTree = await db.reward.aggregate([
            // Project a diff field that's the absolute difference along with the original doc.
            { $project: { diff: { $abs: { $subtract: [oz, '$weight'] } }, doc: '$$ROOT' } },
            // Order the docs by diff
            { $sort: { diff: 1 } },
            // Take the first one
            { $limit: 1 }
        ]);
        treeBadge = addTree;
    } else {
        treeBadge = {};
    }

    if (currency >= 50) {
        const addCurreny = await db.reward.aggregate([
            { $match: { currency: { $ne: null } } },
            // Project a diff field that's the absolute difference along with the original doc.
            { $project: { diff: { $abs: { $subtract: [currency, '$currency'] } }, doc: '$$ROOT' } },
            // Order the docs by diff
            { $sort: { diff: 1 } },
            // Take the first one
            { $limit: 1 }
        ]);
        currenyBadge = addCurreny;
    } else {
        currenyBadge = {};
    }

    if (referral >= 1) {
        const addReferral = await db.reward.aggregate([
            { $match: { referral: { $ne: null } } },
            // Project a diff field that's the absolute difference along with the original doc.
            { $project: { diff: { $abs: { $subtract: [referral, '$referral'] } }, doc: '$$ROOT' } },
            // Order the docs by diff
            { $sort: { diff: 1 } },
            // Take the first one
            { $limit: 1 }
        ]);
        referralBadge = addReferral;
    } else {
        referralBadge = {};
    }

    log.end();
    return {
        'message': message.forest,
        data: {
            treeBadge: treeBadge,
            currenyBadge: currenyBadge,
            referralBadge: referralBadge
        }
    };
};

const timeAgo = (time) => {
    var seconds = Math.floor((new Date() - new Date(time)) / 1000);
    var interval = Math.floor(seconds / 31536000);

    if (interval >= 1) {
        let text = interval > 1 ? ' years' : ' year';
        return interval + text;
    }

    interval = Math.floor(seconds / 2592000);
    if (interval >= 1) {
        let text = interval > 1 ? ' months' : ' month';
        return interval + text;
    }

    interval = Math.floor(seconds / 604800);
    if (interval >= 1) {
        let text = interval > 1 ? ' weeks' : ' week';
        return interval + text;
    }

    return 0;
    /* interval = Math.floor(seconds / 86400);
    if (interval >= 1) {
        let text = interval > 1 ? ' days' : ' day';
        return interval + text;
    }

    interval = Math.floor(seconds / 3600);
    if (interval >= 1) {
        let text = interval > 1 ? ' hours' : ' hour';
        return interval + text;
    }

    interval = Math.floor(seconds / 60);
    if (interval >= 1) {
        let text = interval > 1 ? ' minutes' : ' minute';
        return interval + text;
    }

    if (seconds === 0 || seconds === 1) {
        return 'Now';
    }
    return Math.floor(seconds) + ' seconds'; */
};