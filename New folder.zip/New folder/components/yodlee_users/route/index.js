/**
author : Aditi
created_on : 26 June 2019
**/
'use strict';
const api = require('../api');
const specs = require('../specs');

module.exports = [{
        method: 'GET',
        path: '/api/yodlee/getFastLink',
        options: specs.getFastLink,
        handler: api.getFastLink
    },
    {
        method: 'GET',
        path: '/api/yodlee/bankList',
        options: specs.bankList,
        handler: api.bankList
    },
    {
        method: 'POST',
        path: '/api/yodlee/addBankAccount',
        options: specs.addBankAccount,
        handler: api.addBankAccount
    }
];