/* eslint-disable camelcase */
'use strict';
const hooks = require('../hooks');

const yodlee_user = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    email: { type: String },
    loginName: { type: String },
    providerId: { type: Number },
    providerAccountId: { type: Number },
    bankAccountId: { type: String },
    bankAccountNumber: { type: Number }, // last four digits of account number
    stripeCardId: { type: String },
    stripeCustomerId: { type: String },
    stripeWalletId: { type: String },
    indResAPIKey: { type: String },
    indResSecretKey: { type: String },
}, {
    versionKey: false
});

hooks.configure(yodlee_user);
module.exports = yodlee_user;