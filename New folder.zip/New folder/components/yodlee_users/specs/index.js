'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    getFastLink: {
        description: 'Get Yodlee Fastlink ',
        notes: 'Yodlee Fastlink',
        tags: ['api', 'yodlee'],
        // pre: [{ method: context.validateToken, assign: 'token' }],
        validate: {
            // headers: validator.header,
            query: validator.getFastLink.query,
            failAction: response.failAction
        }
    },
    bankList: {
        description: 'Get bank listing',
        notes: 'Bank List',
        tags: ['api', 'yodlee'],
        pre: [{ method: context.validateToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            query: validator.bankList.query,
            failAction: response.failAction
        }
    },
    addBankAccount: {
        description: 'Add bank account of user to yodlee',
        notes: 'Add bank account',
        tags: ['api', 'yodlee'],
        pre: [{ method: context.validateToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.addBankAccount.payload,
            failAction: response.failAction
        }
    }
};