'use strict';

// const mapper = require('../mapper')
const service = require('../service');
const path = require('path');

/*
 * function : get Fast link
 * params : request object
 * output : success & failure
 */
exports.getFastLink = async(request, h) => {
    const log = logger.start('yodlee:api:getFastLink');

    try {
        const res = await service.getFastLink(request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function : get bank list api
 * params : request object
 * output : success & failure
 */
exports.bankList = async(request, h) => {
    const log = logger.start('yodlee:api:bankList');

    try {
        const res = await service.bankList(request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function : add user bank account in selected provider
 * params : request (provider id, username, password)
 * output : success & failure
 */
exports.addBankAccount = async(request, h) => {
    const log = logger.start('yodlee:api:addBankAccount');

    try {
        const res = await service.addBankAccount(request.userInfo, request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};