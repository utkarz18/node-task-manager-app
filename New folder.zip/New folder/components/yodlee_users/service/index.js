/* eslint-disable no-empty */
/* eslint-disable camelcase */
'use strict';

const md5 = require('md5');
const auth = require('../../../utils/auth');
const yodlee = require('../../../utils/yodlee');
const yodleeBaseUrl = require('config').get('yodleeBaseURL');
const adminUrl = require('config').get('adminServer');
var request = require('request');
const fetch = require('node-fetch');
const NodeRSA = require('node-rsa');
const path = require('path');
const fs = require('fs');
const appRoot = require('app-root-path');
var RSAKey = require('rsa-key');
const crypto = require('crypto');
const ursaLib = require('ursa');

/*
    function : to fetch bank listing from yodlee
    params : name
    output : list of banks
*/
exports.bankList = async(params) => {
    const applicationToken = yodlee.applicationToken();
    let url = '';
    if (params && params.name !== '' && params.name !== undefined) {
        url = yodleeBaseUrl + '/providers?name=' + params.name + '&top=16';
    } else {
        url = yodleeBaseUrl + '/providers?top=16';
    }

    const res = await fetch(url, {
        method: 'get',
        headers: {
            'Api-Version': '1.1',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + applicationToken
        },
    });
    const datas = await res.json();
    let providers = datas.provider;
    var providerData = [];
    providers.forEach(provider => {
        providerData.push({
            id: provider.id,
            name: provider.name,
            logo: provider.logo
        });
    });
    return {
        'message': 'Bank listing fetched successfully.',
        'data': providerData
    };
};


/*
    function : get fastlink url for browser open specific to user
    params : userId
    output : link of yodlee user specific
*/
exports.getFastLink = async(params) => {
    const link = adminUrl.url + '/fastlink/' + params.userId;
    return {
        'message': 'FAstlink fetched successfully.',
        'data': {
            'fastlink': link
        }
    };
};

/*
    function : attach user bank account on yodlee, check bank account are  not repeated, fetch account details register user bank account on stripe fro ACH
    params : provider_id, username(bank username), password(bank password)
    output : success or error
*/
exports.addBankAccount = async(userData, params) => {
    let yodlee_id = '';
    const applicationToken = yodlee.applicationToken();
    const userToken = yodlee.userToken(userData.loginName);
    // console.log(userToken);
    // return false;
    // fetch providers detail
    let url = yodleeBaseUrl + '/providers/' + params.provider_id;

    const res = await fetch(url, {
        method: 'get',
        headers: {
            'Api-Version': '1.1',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + applicationToken
        },
    });
    // console.log('datas1', res);
    const datas = await res.json();
    console.log('datas.provider[0].loginForm', datas.provider[0].loginForm);
    console.log('datas.provider[0].dataset', datas.provider[0].dataset);
    // add account to yodlee
    var keyPEMConstant = '-----BEGIN PUBLIC KEY-----\r\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjcsSuXgiICWinjdkiIqdpPYObGPPUH1csaZXPs5GAhqi1yryr7fuHDG55W+hITLImppwEl7J/CLIR+LyipIbdVB49/OcI7qd7WUH6xw89G8KNOGlRTRN1/Cp2kk6MjfenIb8Dr5rz2TWv7jgVuYUAXkiQDbJMzPSikU1zWwwassSeN0ngM/Ns4ul9vMMql4pKgKf18JOb5HQ+rkKA2Ph0HryVpYVEv6sf8OCnyZFA4E9xOUxTii/3cbZw2vDu+tHmAES73fONVL4kL6ahEjiGvGmtmG4oc9VnyrZHAASpOPt7vl/xgCkxY3EwppaCGQ+X5M9sGLdFHAtUVO66BKqMQIDAQAB\r\n-----END PUBLIC KEY-----';
    // Setting the public key
    var pubKey = ursaLib.createPublicKey(keyPEMConstant);
    // Encrypting the data
    var username = '12272018_1:' + pubKey.encrypt(params.username, 'utf8', 'hex', ursaLib.RSA_PKCS1_PADDING);
    var password = '12272018_1:' + pubKey.encrypt(params.password, 'utf8', 'hex', ursaLib.RSA_PKCS1_PADDING);

    var details = {
        'loginForm': {
            'row': [{
                    'field': [{
                        'id': datas.provider[0].loginForm[0].row[0].field[0].id,
                        'value': username
                    }]
                },
                {
                    'field': [{
                        'id': datas.provider[0].loginForm[0].row[1].field[0].id,
                        'value': password
                    }]
                }
            ]
        }
    };

    let url2 = yodleeBaseUrl + '/providerAccounts?providerId=' + params.provider_id;

    const res2 = await fetch(url2, {
        method: 'post',
        body: JSON.stringify(details),
        headers: {
            'Api-Version': '1.1',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + userToken
        },
    });

    const datas2 = await res2.json();
    console.log('datas2', datas2);
    if (res2.status === 201) {
        var providerAccountId = datas2.providerAccount[0].id;
        console.log(providerAccountId, 'providerAccountId');
        const chkAcc = await db.yodlee_users.findOne({ providerAccountId: providerAccountId, providerId: params.provider_id });
        if (chkAcc) {
            throw new Error('Bank account already linked');
        }

        let url3 = yodleeBaseUrl + '/providerAccounts/' + providerAccountId;
        const accountStatus = await tryUntilSuccess(url3, userToken);
        if (accountStatus === 'SUCCESS' || accountStatus === 'PARTIAL_SUCCESS' || accountStatus === 'FAILED') {
            if (accountStatus === 'FAILED') {
                throw new Error('Unable to link your bank account, please check your credentials');
            } else {
                const chkAch = await db.yodlee_users.findOne({ userId: userData.id, isPrimary: true });
                if (chkAch) {} else {}
                var yodleeModel = {
                    userId: userData.id,
                    providerId: params.provider_id,
                    providerAccountId: providerAccountId,
                    isPrimary: true
                };
                const addAccount = await db.yodlee_users.save(yodleeModel);
                yodlee_id = addAccount._id;
            }
        }
    } else {
        return {
            'message': 'Error in attach bank account to yodlee.',
            'data': {}
        };
    }
};

/*
    function : recursive function for getting success from the yodlee for account linking
    params : api url, user token
    output : success or error
*/
const tryUntilSuccess = async(url, token) => {
    try {
        const acc = await checkStatus(url, token);
        if (acc === 'FAILED' || acc === 'SUCCESS' || acc === 'PARTIAL_SUCCESS') {
            console.log('in if..', acc);
            return acc;
        } else {
            console.log('else', acc);
            tryUntilSuccess(url, token);
        }
    } catch (error) {
        throw new Error(error);
    }

};

/*
    function : function for acctount linking status
    params : api url, user token
    output : success or error
*/
const checkStatus = async(url, token) => {
    var options = {};
    options.url = url;
    options.method = 'get';
    options.headers = {
        'Api-Version': '1.1',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token
    };
    return new Promise((resolve, reject) => {
        request(options, function(error, response, body) {
            if (!response) {
                console.log('here');
                reject(error);
            }
            if (response && response.statusCode !== 200) {
                console.log('here1');
                reject(body.errorMessage);
            }
            if (!error && response.statusCode === 200) {
                console.log('here2');
                var finalData = JSON.parse(body);
                console.log(finalData.providerAccount[0], 'finalData.providerAccount[0].loginForm');

                // console.log(finalData.providerAccount[0].loginForm[0].row[0].field, 'finalData.providerAccount[0].loginForm')
                var status = finalData.providerAccount[0].status;
                resolve(status);
            }
        });
    });
};