'use strict';
const Joi = require('joi');

module.exports = {
    getFastLink: {
        query: {
            'userId': Joi.string().required()
        }
    },
    bankList: {
        query: {
            'name': Joi.string().default('')
        }
    },
    addBankAccount: {
        payload: {
            'provider_id': Joi.string().required(),
            'username': Joi.string().required(),
            'password': Joi.string().required(),
        }
    },
    accessGranted: Joi.object({
        isSuccess: Joi.boolean(),
        status: Joi.string(),
        statusCode: Joi.number().default(200),
        data: Joi.object({})
    }),
    accessDenied: Joi.object({
        isSuccess: Joi.boolean().default(false),
        status: Joi.string(),
        statusCode: Joi.number().default(400),
        message: Joi.string()
    }),
    failure: Joi.object({
        isSuccess: Joi.boolean().default(false),
        status: Joi.string(),
        statusCode: Joi.number().default(320),
        message: Joi.string()
    }),
    success: Joi.object({
        isSuccess: Joi.boolean(),
        status: Joi.string(),
        statusCode: Joi.number().default(200),
        message: Joi.string()
    }),
    header: Joi.object({
        'x-logintoken': Joi.string().required().trim().description('Provide token to access api')
    }).unknown()
};