/* eslint-disable camelcase */
'use strict';

const moment = require('moment');

const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (yodlee_user) => {
    yodlee_user.pre('save', function(next) {
        next();
    });

    yodlee_user.post('save', async(doc) => {});

    yodlee_user.pre('find', function(next) {
        next();
    });

    yodlee_user.pre('findOne', function(next) {
        next();
    });
};