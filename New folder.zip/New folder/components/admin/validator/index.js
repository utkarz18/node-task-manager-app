'use strict';
const Joi = require('joi');

module.exports = {
    /* signUp: {
         payload: {
             full_name: Joi.string().required().lowercase().trim().description('Full Name'),
             email: Joi.string().email().required().description('Valid email Id'),
             phone: Joi.string().required().min(8).max(16).description('Mobile Number'),
             password: Joi.string().regex(/^(?=.*?[a-zA-Z])(?=.*?[a-zA-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,15}$/).options({ language: { string: { regex: { base: 'must be between 6-15 characters including a number and a special character.is invalid' } } } }).label('Password').required().description('Password:MinLength:8')
         }
     }, */
    login: {
        payload: {
            email: Joi.string().email().required().description('Enter valid email'),
            password: Joi.string().required(),
            remember_me: Joi.boolean().optional().default('false'),
        }
    },
    forgot: {
        payload: {
            email: Joi.string().email().required().trim().description('Email')
        }
    },
    resetPasswordToken: {
        query: {
            token: Joi.string().required()
        }
    },
    resetPassword: {
        payload: {
            forgot_password_token: Joi.string().required(),
            password: Joi.string().regex(/^(?=.*?[a-zA-Z])(?=.*?[a-zA-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,20}$/).options({ language: { string: { regex: { base: 'must be between 8-20 characters including a number and a special character.is invalid' } } } }).label('Password').required().description('Password:MinLength:8'),
            confirm_password: Joi.string().required()
        }
    },
    getUser: {
        query: {

        }
    },
    getUsersList: {
        query: {
            search: Joi.string().allow('').description('Search by email or name'),
            page: Joi.number().default(1).description('Page number')
        }
    },
    verifyUser: {
        payload: {
            id: Joi.string().required()
        }
    },
    changeStatus: {
        payload: {
            id: Joi.string().required(),
            status: Joi.number().required().valid([1, 2]),
        }
    },
    deleteUser: {
        payload: {
            id: Joi.string().required()
        }
    },
    logout: {
        payload: {
            token: Joi.string().required()
        }
    },
    getYodleeToken: {
        query: {
            userId: Joi.string().required()
        }
    },
    changePassword: {
        payload: {
            old_password: Joi.string().required().description('Old Password'),
            password: Joi.string().required().description('New Password'),
            password_confirmation: Joi.string().required().description('New Password'),
        }
    },
    saveYodleeBankDetails: {
        payload: {
            user_id: Joi.string().required().description('User id'),
            providerId: Joi.number().required().description('Provider Id'),
            providerAccountId: Joi.number().required().description('provider account id'),
        }
    },
    getPages: {
        query: {
            page: Joi.number().required().description('Page Number'),
        }
    },
    getPage: {
        query: {
            page_id: Joi.string().required().description('Page id'),
        }
    },
    updatePage: {
        payload: {
            _id: Joi.string().required().description('Page id'),
            meta_key: Joi.string().required().description('Page slug'),
            meta_value: Joi.string().required().description('Page Content'),
            status: Joi.number().required().description('Page status'),
            created_at: Joi.number().description('Page created time'),
            updated_at: Joi.number().description('Page updated time'),
        }
    },
    getFaqs: {
        query: {
            page: Joi.number().required().description('Page Number'),
        }
    },
    createFaq: {
        payload: {
            question: Joi.string().required().description('Question'),
            answer: Joi.string().required().description('Answer')
        }
    },
    viewFaq: {
        query: {
            id: Joi.string().required().description('Faq id'),
        }
    },
    editFaq: {
        payload: {
            _id: Joi.string().required().description('Faq id'),
            question: Joi.string().required().description('Question'),
            answer: Joi.string().required().description('Answer'),
            status: Joi.number().required().description('Faq status'),
            created_at: Joi.number().description('Faq created time'),
            updated_at: Joi.number().description('Faq updated time'),
        }
    },
    deleteFaq: {
        payload: {
            id: Joi.string().required().description('Faq id'),
        }
    },
    getUserDetail: {
        query: {
            userId: Joi.string().required().description('User Id'),
        }
    },
    updateUser: {
        payload: {
            _id: Joi.string().required().description('user id'),
            first_name: Joi.string().required().trim().description('First Name'),
            last_name: Joi.string().required().trim().description('Last Name'),
            dob: Joi.string().required().description('Date of birth'),
            gender: Joi.string().required().valid(['Male', 'Female', 'Other']).description('Gender'),
            country: Joi.string().required().description('Country Id'),
            address: Joi.string().required().trim().description('Address'),
            city: Joi.string().required().trim().description('City'),
            state: Joi.string().required().trim().description('State'),
            pinCode: Joi.string().required().trim().description('Pincode'),
        }
    },
    getNews: {
        query: {
            page: Joi.number().required().description('Page Number'),
        }
    },
    createNews: {
        payload: {
            title: Joi.string().required().description('Title'),
            image: Joi.string().required().description('image'),
            image_url: Joi.string().required().description('image_url'),
            content: Joi.string().required().description('Content'),
            posted_date: Joi.string().required().description('date')
        }
    },
    viewNews: {
        query: {
            id: Joi.string().required().description('News id'),
        }
    },
    editNews: {
        payload: {
            id: Joi.string().required().description('News id'),
            title: Joi.string().required().description('title'),
            image: Joi.string().required().description('image'),
            image_url: Joi.string().required().description('image_url'),
            content: Joi.string().required().description('content'),
            posted_date: Joi.string().required().description('date')
        }
    },
    deleteNews: {
        payload: {
            id: Joi.string().required().description('News id'),
        }
    },
    uploadFile: {
        payload: {
            image: Joi.any().required().meta({ swaggerType: 'file' }).description('image'),
            filename: Joi.any().required()
        }
    },
    accessGranted: Joi.object({
        isSuccess: Joi.boolean(),
        status: Joi.string(),
        statusCode: Joi.number().default(200),
        data: Joi.object({})
    }),
    accessDenied: Joi.object({
        isSuccess: Joi.boolean().default(false),
        status: Joi.string(),
        statusCode: Joi.number().default(400),
        message: Joi.string()
    }),
    failure: Joi.object({
        isSuccess: Joi.boolean().default(false),
        status: Joi.string(),
        statusCode: Joi.number().default(320),
        message: Joi.string()
    }),
    success: Joi.object({
        isSuccess: Joi.boolean(),
        status: Joi.string(),
        statusCode: Joi.number().default(200),
        message: Joi.string()
    }),
    header: Joi.object({
        'admin_access_token': Joi.string().required().trim().description('Provide token to access api')
    }).unknown()
};