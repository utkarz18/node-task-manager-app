/* eslint-disable no-unused-vars */
'use strict';

const md5 = require('md5');
// const twilio = require('twilio');
// const twilioCredentials = require('config').get('TWILIO_CREDENTIALS');
const yodlee = require('../../../utils/yodlee');
// const yodleeModel = require('../../yodlee_users/model');
const yodleeBaseUrl = require('config').get('yodleeBaseURL');
const auth = require('../../../utils/auth');
const fetch = require('node-fetch');
const stripe = require('stripe')('sk_test_zblSW9BrYlsHw4BRhqq8MYDa00ww0CGFRO');
const offline = require('../../../utils/offline');
const message = require('../../../utils/messages');
const cloudinary = require('../../../utils/cloudinary');

/*
    function : get user details with email
    params: emailId
    output : user object
*/
// eslint-disable-next-line no-unused-vars
const getUserByEmail = async(emailId) => {
    const log = logger.start(`users:services:getUserByEmail:${emailId}`);

    const user = await db.users.findOne({
        email: emailId,
        isDeleted: false
    });
    log.end();

    return user;
};

/*
    function : login admin
    params: email, password
    output : success with user object
*/
exports.login = async(params) => {
    const log = logger.start('admin:service:login');
    const user = await db.users.findOne({
        email: params.email,
        password: md5(params.password)
    });

    if (!user) {
        throw new Error(message.invalid_credentials);
    }

    var accessToken = auth.createToken(user._id);

    const userDatas = await db.users.findOneAndUpdate({
        email: params.email,
    }, {
        loginTime: moment().unix(),
        $push: {
            accessToken: accessToken
        }
    }, {
        new: true,
        lean: true
    });

    log.end();
    return {
        message: message.admin_login,
        data: {
            'id': userDatas._id,
            'full_name': userDatas.full_name,
            'email': userDatas.email,
            'accessToken': accessToken
        }
    };
};

/*
    function : admin forgot password
    params: email
    output : success with send email to user for forgot passowrd
*/
exports.forgotPassword = async(params) => {
    const log = logger.start('admin:service:forgotPassword');

    const user = await db.users.findOne({
        email: params.email,
        userRole: 'admin',
        isDeleted: false
    });

    if (!user)
        throw new Error(message.invalid_credentials);


    user.resetPasswordToken = auth.randomToken(user.id);
    await user.save();

    offline.queue('admin', 'forgot-password', {
        id: user.id
    }, {});

    log.end();

    return message.forgot_email;
};

/*
    function : admin reset password token verify
    params: token
    output : success or error
*/
exports.resetPasswordToken = async(params) => {
    const log = logger.start('admin:service:resetPasswordToken');

    const user = await db.users.findOne({
        resetPasswordToken: params.token
    });

    if (!user) {
        throw new Error(message.link_expire);
    }
    log.end();
    return message.valid_link;
};

/*
    function : admin reset password 
    params: token, password
    output : success or error
*/
exports.resetPassword = async(params) => {
    const log = logger.start('admin:service:resetPassword');

    const user = await db.users.findOne({
        resetPasswordToken: params.forgot_password_token
    });
    if (!user) throw new Error(message.link_expire);

    await db.users.findOneAndUpdate({
        _id: user._id
    }, {
        password: md5(params.password),
        $unset: {
            resetPasswordToken: 1
        }
    });
    log.end();
    return message.password_update;
};

/*
    function : admin get user information 
    params: login token
    output : success with user object
*/
exports.getUser = async(userInfo) => {
    const log = logger.start('admin:service:getUser');

    log.end();
    return {
        'message': message.user_info,
        'data': userInfo
    };
};

/*
    function : admin logout from application 
    params: token
    output : success 
*/
exports.logout = async(params) => {
    const log = logger.start('admin:service:logout');

    await db.users.update({
        'accessToken': {
            '$in': [params.token]
        }
    }, {
        $pull: {
            'accessToken': params.token
        },
        logoutTime: moment().unix()

    });

    log.end();
    return 'Logout successfully.';
};

/*
    function : get user token for yodlee fastlink open
    params: userId
    output : success with application token 
*/
exports.getYodleeToken = async(params) => {

    /* const yodlUser = await db.yodlee_users.findOne({
        userId: params.userId
    })
    if (!yodlUser)
        throw new Error('Invalid userid')

    const applicationToken = yodlee.userToken(yodlUser.loginName); */
    const applicationToken = yodlee.userToken('sdm4');
    return {
        message: 'Yodlee token.',
        data: {
            'token': applicationToken
        }
    };
};

/*
    function : get user token for yodlee fastlink open
    params: userId
    output : success with application token 
*/
exports.changePassword = async(userInfo, params) => {
    const log = logger.start('admin:service:changePassword');
    const chkOldPass = await db.users.findOne({
        '_id': userInfo._id,
        password: md5(params.old_password)
    });

    if (!chkOldPass) {
        throw new Error('Incorrect old password');
    }

    await db.users.findOneAndUpdate({
        _id: chkOldPass.id
    }, {
        password: md5(params.password)
    });
    log.end();
    return {
        'message': 'Password updated successfully.',
        'data': {}
    };

};

exports.saveYodleeBankDetails = async(params) => {
    console.log('params', params);
    const log = logger.start('admin:service:saveYodleeBankDetails');

    // check is account already registered 
    /* const isAlreadyUser = await db.yodlee_users.findOne({
         'providerId': params.providerId,
         'providerAccountId': params.providerAccountId
     });

     if (isAlreadyUser) {
         throw new Error('Bank account already registered')
     } */

    const accountVerification = await yodleeBankAccountVerification(params);

    /*  const stripeBank = await addBankOnStripe(params, accountVerification)
      if (stripeBank != 'verified') {
          throw new Error('User bank account is not verified')
      }

      const user = await db.yodlee_users.findOneAndUpdate({
          'userId': params.user_id
      }, {
          providerId: params.providerId,
          providerAccountId: params.providerAccountId
      });

      if (!user) {
          throw new Error('No user found.')
      }

      const updateUser = await db.users.findOneAndUpdate({
          '_id': params.user_id
      }, {
          isBankAccountAdded: true
      }) */

    log.end();
    return {
        'message': 'Bank details updated successfully.',
        'data': {}
    };

};

const yodleeBankAccountVerification = async(data) => {

    /*  const yodlUser = await db.yodlee_users.findOne({
          userId: data.user_id
      })
      if (!yodlUser)
          throw new Error('Invalid userid') */

    const applicationToken = yodlee.userToken('sdm4');
    // const applicationToken = yodlee.userToken('sbMemeEqVSATtKXMIS4');

    const url = yodleeBaseUrl + 'accounts?container=bank&include=fullAccountNumber,profile,holder,paymentProfile&providerAccountId=' + data.providerAccountId;
    const res = await fetch(url, {
        method: 'get',
        headers: {
            'Api-Version': '1.1',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + applicationToken
        },
    });
    const datas = await res.json();
    console.log(datas);
    var accountDetail = {
        country: 'US',
        currency: 'usd',
        account_holder_name: 'Jenny Rosen',
        account_holder_type: 'individual',
        routing_number: '110000000',
        account_number: '000123456789'
    };
    return accountDetail;
};

const addBankOnStripe = async(data, bankDetail) => {

    const bankToken = await stripe.tokens.create({
        bank_account: bankDetail
    });
    if (!bankToken) {
        throw new Error('unable to create stripe bank account token');
    }

    // attach bank to customer
    const yodlUser = await db.yodlee_users.findOne({
        userId: data.user_id
    });
    const attachBank = await stripe.customers.createSource(yodlUser.stripeCustomerId, {
        source: bankToken.id
    });
    if (!attachBank) {
        throw new Error('unable to attach bank account to customer');
    }
    // save user bank id from stripe in database
    const saveDetails = await db.yodlee_users.findOneAndUpdate({
        userId: data.user_id
    }, {
        bankAccountId: attachBank.id,
        bankAccountNumber: attachBank.last4
    });

    // verify user account for ACH
    const verifyAch = await stripe.customers.verifySource(yodlUser.stripeCustomerId, attachBank.id, {
        amounts: [32, 45],
    });
    if (!verifyAch) {
        throw new Error('unable to verify user account for ACh');
    }
    return verifyAch.status;
};

exports.getUsersList = async(params) => {
    const log = logger.start('admin:service:getUsersList');

    var totalCondition = [{
        $match: {
            isDeleted: false,
            userRole: 'user'
        }
    }, ];

    if (params.search && params.search !== '') {
        totalCondition.push({
            $match: { $or: [{ first_name: { $regex: '.*' + params.search + '.*' } }, { email: { $regex: '.*' + params.search + '.*' } }] }
        });
    }

    totalCondition.push({
        $count: 'totalCount'
    });

    const records = await db.users.aggregate([
        totalCondition,
    ]);
    var skip = (params.page - 1) * 10;

    var condition = [{
        $match: {
            isDeleted: false,
            userRole: 'user'
        }
    }, ];

    condition.push({
        $lookup: {
            from: 'countries',
            localField: 'country',
            foreignField: '_id',
            as: 'usercountries'
        }
    }, );

    if (params.search && params.search !== '') {
        condition.push({
            $match: { $or: [{ first_name: { $regex: '.*' + params.search + '.*' } }, { email: { $regex: '.*' + params.search + '.*' } }] }
        });
    }

    condition.push({ $skip: skip }, { $limit: 10 });

    const userlist = await db.users.aggregate([
        condition
    ]);

    log.end();
    return {
        'message': 'User list fetched successfully.',
        'data': { 'userData': userlist, 'total': records[0].totalCount }
    };

};

exports.verifyUser = async(params) => {
    const log = logger.start('admin:service:verifyUser');
    const user = await db.users.findOneAndUpdate({
        '_id': params.id
    }, {
        isVerified: 2,
        accountVerificationTime: moment().unix(),
        $unset: {
            otpCode: 1
        }
    });

    if (!user) {
        throw new Error('No user found.');
    }

    offline.queue('admin', 'verify', {
        id: params.id
    }, {});

    log.end();
    return {
        'message': 'Account approved successfully.',
        'data': {}
    };

};

exports.changeStatus = async(params) => {
    const log = logger.start('admin:service:changeStatus');

    if (params.status === 1) {
        var isActive = true;
        var isDeactivated = false;
    } else {
        // eslint-disable-next-line no-redeclare
        var isActive = false;
        var isDeactivated = true;
    }

    const user = await db.users.findOneAndUpdate({
        '_id': params.id
    }, {
        isActive: isActive,
        isDeactivated: isDeactivated
    });

    if (!user) {
        throw new Error('No user found.');
    }

    log.end();
    return {
        'message': 'Account status successfully.',
        'data': {}
    };

};

exports.deleteUser = async(params) => {
    const log = logger.start('admin:service:deleteUser');

    const user = await db.users.findOneAndUpdate({
        '_id': params.id
    }, {
        isDeleted: true
    });

    if (!user) {
        throw new Error('No user found.');
    }

    log.end();
    return {
        'message': 'User deleted successfully.',
        'data': {}
    };

};

exports.getPages = async(params) => {
    const log = logger.start('admin:service:getPages');

    var skip = (params.page - 1) * 10;
    const pages = await db.pages.find({
        'status': 1
    }, {
        $skip: skip
    }, {
        $limit: 10
    });

    if (!pages) {
        throw new Error('No records found.');
    }

    const total = await db.pages.count({ 'status': 1 });

    log.end();
    return {
        'message': 'Pages found successfully.',
        'data': { 'pagesData': pages, 'total': total }
    };

};

exports.getPage = async(params) => {
    const log = logger.start('admin:service:getPage');


    const pages = await db.pages.findOne({
        '_id': params.page_id
    });

    if (!pages) {
        throw new Error('Invalid page id');
    }

    log.end();
    return {
        'message': 'Page found successfully.',
        'data': { 'pagesData': pages }
    };

};

exports.updatePage = async(params) => {
    const log = logger.start('admin:service:updatePage');


    const pages = await db.pages.findOneAndUpdate({
        '_id': params._id
    }, {
        meta_value: params.meta_value,
        updated_at: moment().unix()
    });

    if (!pages) {
        throw new Error('Invalid page id');
    }

    log.end();
    return {
        'message': 'Page updated successfully.',
        'data': {}
    };

};

exports.getFaqs = async(params) => {
    const log = logger.start('admin:service:getFaqs');

    var skip = (params.page - 1) * 10;
    const faqs = await db.faqs.find({
        'status': 1
    }, {
        $skip: skip
    }, {
        $limit: 10
    });

    if (!faqs) {
        throw new Error('No records found.');
    }

    const total = await db.faqs.count({ 'status': 1 });

    log.end();
    return {
        'message': 'Faq\'s fetched successfully.',
        'data': { 'faqData': faqs, 'total': total }
    };

};

exports.createFaq = async(params) => {
    const log = logger.start('admin:service:createFaq');

    const faqData = {
        question: params.question,
        answer: params.answer,
        status: 1,
        created_at: moment().unix(),
        updated_at: moment().unix()
    };

    // eslint-disable-next-line new-cap
    const faqs = await new db.faqs(faqData);
    var x = await faqs.save();

    if (!x) {
        throw new Error('Error in adding faq.');
    }

    log.end();
    return {
        'message': 'Faq added successfully.',
        'data': {}
    };

};

exports.viewFaq = async(params) => {
    const log = logger.start('admin:service:viewFaq');

    const faqs = await db.faqs.findOne({ _id: params.id, 'status': 1 });

    if (!faqs) {
        throw new Error('Invalid faq id.');
    }

    log.end();
    return {
        'message': 'Faq fetched successfully.',
        'data': faqs
    };

};

exports.editFaq = async(params) => {
    const log = logger.start('admin:service:editFaq');

    const faqs = await db.faqs.findOneAndUpdate({
        _id: params._id
    }, {
        question: params.question,
        answer: params.answer,
        status: 1,
        created_at: moment().unix(),
        updated_at: moment().unix()
    });

    if (!faqs) {
        throw new Error('Error in updating faq.');
    }

    log.end();
    return {
        'message': 'Faq updated successfully.',
        'data': {}
    };
};

exports.deleteFaq = async(params) => {
    const log = logger.start('admin:service:deleteFaq');

    const faqs = await db.faqs.findOne({
        _id: params.id
    }).remove();

    if (!faqs) {
        throw new Error('Error in deleting faq.');
    }

    log.end();
    return {
        'message': 'Faq deleted successfully.',
        'data': {}
    };
};

exports.getUserDetail = async(params) => {
    const log = logger.start('admin:service:getUserDetail');

    const user = await db.users.findOne({
        _id: params.userId
    });

    if (!user) {
        throw new Error('No record found.');
    }

    log.end();
    return {
        'message': 'User fetched successfully.',
        'data': { user: user }
    };
};

exports.updateUser = async(params) => {
    const log = logger.start('admin:service:updateUser');

    var user = await db.users.findOneAndUpdate({ _id: params._id }, {
        first_name: params.first_name,
        last_name: params.last_name,
        dob: params.dob,
        gender: params.gender,
        country: params.country,
        address: params.address,
        city: params.city,
        state: params.state,
        pinCode: params.pinCode,
        lastProfileUpdatedTime: moment().unix()
    }, { new: true });

    if (!user) throw new Error('Error in updating profile.');
    log.end();
    return { message: 'User Profile updated successfully.', data: { user: user } };
};

/*
 * function: to get the listing of all news in the admin
 * params: pageno
 * output : list of all news
 */
exports.getNews = async(params) => {
    const log = logger.start('admin:service:getNews');

    var skip = (params.page - 1) * 10;
    const news = await db.news.find({
        'status': 1
    }, {
        $skip: skip
    }, {
        $limit: 10
    });

    if (!news) {
        throw new Error('No records found.');
    }

    const total = await db.news.count({ 'status': 1 });

    log.end();
    return {
        'message': 'News fetched successfully.',
        'data': { 'newsData': news, 'total': total }
    };

};

/*
 * function: create new news
 * params: title, content, image, posted_date
 * output : success & failure
 */
exports.createNews = async(params) => {
    const log = logger.start('admin:service:createNews');
    const newsData = {
        title: params.title,
        content: params.content,
        image: params.image,
        image_url: params.image_url,
        posted_date: params.posted_date,
        status: 1,
        created_at: moment().unix(),
        updated_at: moment().unix()
    };

    const news = await new db.news(newsData);
    var x = await news.save();

    if (!x) {
        throw new Error('Error in adding News.');
    }

    log.end();
    return {
        'message': 'News added successfully.',
        'data': {}
    };

};

/*
 * function: view news
 * params: news id
 * output : news object
 */
exports.viewNews = async(params) => {
    const log = logger.start('admin:service:viewNews');

    const news = await db.news.findOne({ _id: params.id, 'status': 1 });

    if (!news) {
        throw new Error('Invalid news id.');
    }

    log.end();
    return {
        'message': 'News fetched successfully.',
        'data': news
    };

};

/*
 * function: delete news
 * params: news id
 * output : success or failure
 */
exports.deleteNews = async(params) => {
    const log = logger.start('admin:service:deleteNews');

    const faqs = await db.news.findOne({
        _id: params.id
    }).remove();

    if (!faqs) {
        throw new Error('Error in deleting news.');
    }

    log.end();
    return {
        'message': 'News deleted successfully.',
        'data': {}
    };
};


/*
 * function: upload file
 * params: file
 * output : success or failure
 */
exports.uploadFile = async(params) => {
    const log = logger.start('admin:services:uploadFile');
    const response = await cloudinary.uploadFile(params);

    return {
        message: message.file_uploaded,
        data: { 
            imageUrl: response.imageUrl,
            fileName: response.fileName
         }
    };
};

/*
 * function: edit news
 * params: updated news
 * output : success or failure
 */
exports.editNews = async(params) => {
    const log = logger.start('admin:service:editNews');
    const newsData = {
        title: params.title,
        content: params.content,
        image: params.image,
        image_url: params.image_url,
        posted_date: params.posted_date,
        status: 1,
        created_at: moment().unix(),
        updated_at: moment().unix()
    };

    const news = await db.news.findOneAndUpdate({ _id: params.id }, newsData);
    var x = await news.save();

    if (!x) {
        throw new Error('Error in editing News.');
    }

    log.end();
    return {
        'message': 'News updated successfully.',
        'data': {}
    };

};