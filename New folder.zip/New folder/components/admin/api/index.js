'use strict';

const mapper = require('../mapper');
const service = require('../service');;


exports.login = async(request, h) => {
    const log = logger.start('admin:api:login');
    try {
        const res = await service.login(request.payload);
        log.end();

        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.adminsuccess(h, res.message, mapper.toModel(res.data));
    } catch (err) {
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.forgotPassword = async(request, h) => {
    const log = logger.start('admin:api:forgotPassword');

    try {
        const message = await service.forgotPassword(request.payload);
        log.end();
        return response.success(h, message);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.resetPasswordToken = async(request, h) => {
    const log = logger.start('admin:api:resetPasswordToken');

    try {
        const message = await service.resetPasswordToken(request.query);
        log.end();
        return response.success(h, message);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.resetPassword = async(request, h) => {
    const log = logger.start('admin:api:resetPassword');

    try {
        const message = await service.resetPassword(request.payload);
        log.end();
        return response.success(h, message);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.getUser = async(request, h) => {
    const log = logger.start('admin:api:getUser');

    try {
        const message = await service.getUser(request.userInfo);
        log.end();
        return response.success(h, message);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.logout = async(request, h) => {
    const log = logger.start('admin:api:logout');

    try {
        const message = await service.logout(request.payload);
        log.end();
        return response.success(h, message);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.getYodleeToken = async(request, h) => {
    const log = logger.start('yodlee:api:getYodleeToken');

    try {
        const res = await service.getYodleeToken(request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.changePassword = async(request, h) => {
    const log = logger.start('admin:api:changePassword');

    try {
        const res = await service.changePassword(request.userInfo, request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.saveYodleeBankDetails = async(request, h) => {
    const log = logger.start('admin:api:saveYodleeBankDetails');
    try {
        const res = await service.saveYodleeBankDetails(request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.getUsersList = async(request, h) => {
    const log = logger.start('admin:api:getUsersList');
    try {
        const res = await service.getUsersList(request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.verifyUser = async(request, h) => {
    const log = logger.start('admin:api:verifyUser');
    try {
        const res = await service.verifyUser(request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.changeStatus = async(request, h) => {
    const log = logger.start('admin:api:changeStatus');
    try {
        const res = await service.changeStatus(request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.deleteUser = async(request, h) => {
    const log = logger.start('admin:api:deleteUser');
    try {
        const res = await service.deleteUser(request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.getPages = async(request, h) => {
    const log = logger.start('admin:api:getPages');
    try {
        const res = await service.getPages(request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.getPage = async(request, h) => {
    const log = logger.start('admin:api:getPage');
    try {
        const res = await service.getPage(request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.updatePage = async(request, h) => {
    const log = logger.start('admin:api:updatePage');
    try {
        const res = await service.updatePage(request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.getFaqs = async(request, h) => {
    const log = logger.start('admin:api:getFaqs');
    try {
        const res = await service.getFaqs(request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.createFaq = async(request, h) => {
    const log = logger.start('admin:api:createFaq');
    try {
        const res = await service.createFaq(request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.viewFaq = async(request, h) => {
    const log = logger.start('admin:api:viewFaq');
    try {
        const res = await service.viewFaq(request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.editFaq = async(request, h) => {
    const log = logger.start('admin:api:editFaq');
    try {
        const res = await service.editFaq(request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.deleteFaq = async(request, h) => {
    const log = logger.start('admin:api:deleteFaq');
    try {
        const res = await service.deleteFaq(request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.getUserDetail = async(request, h) => {
    const log = logger.start('admin:api:getUserDetail');
    try {
        const res = await service.getUserDetail(request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.updateUser = async(request, h) => {
    const log = logger.start('admin:api:updateUser');
    try {
        const res = await service.updateUser(request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function: to get the listing of all news in the admin
 * params: pageno
 * output : list of all news
 */
exports.getNews = async(request, h) => {
    const log = logger.start('admin:api:getNews');
    try {
        const res = await service.getNews(request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function: create new news
 * params: title, content, image, posted_date
 * output : success & failure
 */
exports.createNews = async(request, h) => {
    const log = logger.start('admin:api:createNews');
    try {
        const res = await service.createNews(request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function: view news
 * params: news id
 * output : news object
 */
exports.viewNews = async(request, h) => {
    const log = logger.start('admin:api:viewNews');
    try {
        const res = await service.viewNews(request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function: edit news
 * params: updated news
 * output : success or failure
 */
exports.editNews = async(request, h) => {
    const log = logger.start('admin:api:editNews');
    try {
        const res = await service.editNews(request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function: delete news
 * params: news id
 * output : success or failure
 */
exports.deleteNews = async(request, h) => {
    const log = logger.start('admin:api:deleteNews');
    try {
        const res = await service.deleteNews(request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function: upload file
 * params: file
 * output : success or failure
 */
exports.uploadFile = async(request, h) => {
    try {
        const res = await service.uploadFile(request.payload);
        return response.success(h, res.message, res.data);
    } catch (err) {
        return response.failure(h, err.message);
    }
};