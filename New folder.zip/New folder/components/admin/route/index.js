/**
author : Aditi
created_on : 12 Nov 2018
**/
'use strict';
const api = require('../api');
const specs = require('../specs');

module.exports = [{
        method: 'POST',
        path: '/api/admin/login',
        options: specs.login,
        handler: api.login
    }, {
        method: 'POST',
        path: '/api/admin/forgotPassword',
        options: specs.forgotPassword,
        handler: api.forgotPassword
    }, {
        method: 'GET',
        path: '/api/admin/resetPasswordToken',
        options: specs.resetPasswordToken,
        handler: api.resetPasswordToken
    }, {
        method: 'POST',
        path: '/api/admin/resetPassword',
        options: specs.resetPassword,
        handler: api.resetPassword
    },
    {
        method: 'GET',
        path: '/api/admin/getUser',
        options: specs.getUser,
        handler: api.getUser
    },
    {
        method: 'POST',
        path: '/api/admin/logout',
        options: specs.logout,
        handler: api.logout
    },
    {
        method: 'GET',
        path: '/api/admin/getYodleeToken',
        options: specs.getYodleeToken,
        handler: api.getYodleeToken
    },
    {
        method: 'PUT',
        path: '/api/admin/changePassword',
        options: specs.changePassword,
        handler: api.changePassword
    },
    {
        method: 'POST',
        path: '/api/admin/saveYodleeBankDetails',
        options: specs.saveYodleeBankDetails,
        handler: api.saveYodleeBankDetails
    },
    {
        method: 'GET',
        path: '/api/admin/getUsersList',
        options: specs.getUsersList,
        handler: api.getUsersList
    },
    {
        method: 'POST',
        path: '/api/admin/verifyUser',
        options: specs.verifyUser,
        handler: api.verifyUser
    },
    {
        method: 'POST',
        path: '/api/admin/changeStatus',
        options: specs.changeStatus,
        handler: api.changeStatus
    },
    {
        method: 'POST',
        path: '/api/admin/deleteUser',
        options: specs.deleteUser,
        handler: api.deleteUser
    },
    {
        method: 'GET',
        path: '/api/admin/getPages',
        options: specs.getPages,
        handler: api.getPages
    },
    {
        method: 'GET',
        path: '/api/admin/getPage',
        options: specs.getPage,
        handler: api.getPage
    },
    {
        method: 'POST',
        path: '/api/admin/updatePage',
        options: specs.updatePage,
        handler: api.updatePage
    },
    {
        method: 'GET',
        path: '/api/admin/getFaqs',
        options: specs.getFaqs,
        handler: api.getFaqs
    },
    {
        method: 'POST',
        path: '/api/admin/createFaq',
        options: specs.createFaq,
        handler: api.createFaq
    },
    {
        method: 'GET',
        path: '/api/admin/viewFaq',
        options: specs.viewFaq,
        handler: api.viewFaq
    },
    {
        method: 'POST',
        path: '/api/admin/editFaq',
        options: specs.editFaq,
        handler: api.editFaq
    },
    {
        method: 'POST',
        path: '/api/admin/deleteFaq',
        options: specs.deleteFaq,
        handler: api.deleteFaq
    },
    {
        method: 'GET',
        path: '/api/admin/getUserDetail',
        options: specs.getUserDetail,
        handler: api.getUserDetail
    },
    {
        method: 'POST',
        path: '/api/admin/updateUser',
        options: specs.updateUser,
        handler: api.updateUser
    },
    {
        method: 'GET',
        path: '/api/admin/getNews',
        options: specs.getNews,
        handler: api.getNews
    },
    {
        method: 'POST',
        path: '/api/admin/createNews',
        options: specs.createNews,
        handler: api.createNews
    },
    {
        method: 'GET',
        path: '/api/admin/viewNews',
        options: specs.viewNews,
        handler: api.viewNews
    },
    {
        method: 'POST',
        path: '/api/admin/editNews',
        options: specs.editNews,
        handler: api.editNews
    },
    {
        method: 'POST',
        path: '/api/admin/deleteNews',
        options: specs.deleteNews,
        handler: api.deleteNews
    },
    {
        method: 'POST',
        path: '/api/admin/uploadFile',
        options: specs.uploadFile,
        handler: api.uploadFile
    }
];