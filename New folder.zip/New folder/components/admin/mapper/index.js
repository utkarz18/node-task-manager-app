'use strict';

exports.toModel = (entity) => {
    const model = {
        id: entity.id,
        full_name: entity.full_name ? entity.full_name : entity.full_name,
        email: entity.email,
        role: entity.role,
        deviceType: entity.deviceType,
        deviceToken: entity.deviceToken,
        accessToken: entity.accessToken,
        isSplashView: entity.isSplashView,
        phoneOrEmail: entity.phoneOrEmail
    };

    return model;
};