'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    login: {
        description: 'Admin Login',
        notes: 'Admin login ',
        tags: ['api', 'admin'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        headers: {
                            schema: {
                                'x-access-token': 'string',
                                description: 'x-logintoken is found in response headers'
                            }
                        },
                        schema: validator.accessGranted
                    },
                    400: {
                        description: 'UnAuthorized User',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        validate: {
            payload: validator.login.payload,
            failAction: response.accessDeniedAction
        }
    },
    forgotPassword: {
        description: 'Forgot Password Api',
        notes: 'Verify email to get reset password Details',
        tags: ['api', 'admin'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    },
                    400: {
                        description: 'invalid token/user',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        validate: {
            payload: validator.forgot.payload,
            failAction: response.failAction
        }
    },
    resetPasswordToken: {
        description: 'Verify token for password change',
        notes: 'Token verify For password change',
        tags: ['api', 'admin'],
        validate: {
            query: validator.resetPasswordToken.query,
            failAction: response.failAction
        }
    },
    resetPassword: {
        description: 'Admin Password reset',
        notes: 'To reset password via resetPasswordToken',
        tags: ['api', 'admin'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    }
                }
            }
        },
        validate: {
            payload: validator.resetPassword.payload,
            failAction: response.failAction
        }
    },
    getUser: {
        description: 'Get admin details',
        notes: 'Get login admin details',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            query: validator.getUser.query,
            failAction: response.failAction
        }
    },
    logout: {
        description: 'Admin Logout',
        notes: 'Logout Admin from application',
        tags: ['api', 'admin'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    }
                }
            }
        },
        validate: {
            payload: validator.logout.payload,
            failAction: response.failAction
        }
    },
    getYodleeToken: {
        description: 'Get yodlee token',
        notes: 'Yodlee jwt token',
        tags: ['api', 'admin'],
        // pre: [{ method: context.validateToken, assign: 'token' }],
        validate: {
            query: validator.getYodleeToken.query,
            failAction: response.failAction
        }
    },
    changePassword: {
        description: 'Admin change password',
        notes: 'Admin Panel change password',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.changePassword.payload,
            failAction: response.failAction
        }
    },
    saveYodleeBankDetails: {
        description: 'Save user yodlee bank details',
        notes: 'Save user yodlee bank details',
        tags: ['api', 'admin'],
        validate: {
            payload: validator.saveYodleeBankDetails.payload,
            failAction: response.failAction
        }
    },
    getUsersList: {
        description: 'Get all user list',
        notes: 'Get all users list',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            query: validator.getUsersList.query,
            failAction: response.failAction
        }
    },
    verifyUser: {
        description: 'Verify user account by admin',
        notes: 'Verify user account by admin',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.verifyUser.payload,
            failAction: response.failAction
        }
    },
    changeStatus: {
        description: 'Activate & deactivate user account',
        notes: 'Activate & deactivate user account',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.changeStatus.payload,
            failAction: response.failAction
        }
    },
    deleteUser: {
        description: 'Delete user account',
        notes: 'Delete user account',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.deleteUser.payload,
            failAction: response.failAction
        }
    },
    getPages: {
        description: 'Get all pages (terms/privacy etc)',
        notes: 'Get all static pages',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            query: validator.getPages.query,
            failAction: response.failAction
        }
    },
    getPage: {
        description: 'Get page data',
        notes: 'Get page data',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            query: validator.getPage.query,
            failAction: response.failAction
        }
    },
    updatePage: {
        description: 'Update page data',
        notes: 'Update page data',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.updatePage.payload,
            failAction: response.failAction
        }
    },
    getFaqs: {
        description: 'Get faqs list',
        notes: 'Get faqs list',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            query: validator.getFaqs.query,
            failAction: response.failAction
        }
    },
    createFaq: {
        description: 'Add new faq question',
        notes: 'Add faq',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.createFaq.payload,
            failAction: response.failAction
        }
    },
    viewFaq: {
        description: 'View faq',
        notes: 'View faq',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            query: validator.viewFaq.query,
            failAction: response.failAction
        }
    },
    editFaq: {
        description: 'Update faq',
        notes: 'update faq',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.editFaq.payload,
            failAction: response.failAction
        }
    },
    deleteFaq: {
        description: 'Delete faq',
        notes: 'Delete faq',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.deleteFaq.payload,
            failAction: response.failAction
        }
    },
    getUserDetail: {
        description: 'Get user detail',
        notes: 'Get user detail',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            query: validator.getUserDetail.query,
            failAction: response.failAction
        }
    },
    updateUser: {
        description: 'Update User details',
        notes: 'Update User details',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.updateUser.payload,
            failAction: response.failAction
        }
    },
    getNews: {
        description: 'Get news list',
        notes: 'Get news list',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            query: validator.getNews.query,
            failAction: response.failAction
        }
    },
    createNews: {
        description: 'Add new news',
        notes: 'Add news',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.createNews.payload,
            failAction: response.failAction
        }
    },
    viewNews: {
        description: 'View news',
        notes: 'View news',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            query: validator.viewNews.query,
            failAction: response.failAction
        }
    },
    editNews: {
        description: 'Update news',
        notes: 'update news',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.editNews.payload,
            failAction: response.failAction
        }
    },
    deleteNews: {
        description: 'Delete news',
        notes: 'Delete news',
        tags: ['api', 'admin'],
        pre: [{ method: context.validateAdminToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.deleteNews.payload,
            failAction: response.failAction
        }
    },
    uploadFile: {
        description: 'upload file',
        notes: 'Upload user profile pic , cover pic, Artist profile pic , cover pic, and song cover pic, profile (user,song,artist), type (cover/profile) ',
        tags: ['api', 'admin'],
        plugins: {
            'hapi-swagger': {
                payloadType: 'form',
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    }
                }
            }
        },
        pre: [{
            method: context.validateAdminToken,
            assign: 'token'
        }],
        payload: {
            maxBytes: 30485760,
            output: 'stream',
            parse: true,
            allow: 'multipart/form-data'
        },
        validate: {
            headers: validator.header,
            payload: validator.uploadFile.payload,
            failAction: response.failAction
        }
    }

};