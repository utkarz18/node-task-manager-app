'use strict';

const fs = require('fs');

const models = async(logger) => {
    const log = logger.start('components:models');
    const components = fs.readdirSync(__dirname);

    try {
        for (const component of components) {
            if (component !== 'index.js' && fs.existsSync(`${__dirname}/${component}/model`)) {
                mongoose.model(component, require(`./${component}/model`));
            }
        }
        log.end();
    } catch (err) {
        log.error(err);
        log.error('error while configuring models');
        log.end();
    }
};

const routes = async(server, logger) => {
    const log = logger.start('components:routes');
    const components = fs.readdirSync(__dirname);

    try {
        for (const component of components) {
            if (component !== 'index.js' && fs.existsSync(`${__dirname}/${component}/route`)) {
                server.route(require(`./${component}/route`));
            }
        }

        server.route({
            method: 'GET',
            path: '/assets/{name}',
            handler: async(request, h) => {
                try {
                    return h.file('./assets/' + request.params.name);
                } catch (err) {
                    return response.failure(h, err.message);
                }
            }
        });
        log.end();
    } catch (err) {
        log.error(err);
        log.error('error while configuring routes');
        log.end();
    }
};
exports.models = models;
exports.routes = routes;