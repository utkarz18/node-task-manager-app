'use strict';
const hooks = require('../hooks');

// eslint-disable-next-line no-undef
const account = new mongoose.Schema({
    // eslint-disable-next-line no-undef
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    bankId: { type: String, default: '' },
    cardId: { type: String, default: '' },
    accountName: { type: String },
    type: { type: String }, // card, bank
    card_type: { type: String, default: '' }, // credit_card , debit_card
    bankAccountNumber: { type: String }, // last 4 digit of bank account number
    isPrimary: { type: Boolean },
    status: { type: Number }, // 1 - Active, 2- Deactive, 3- Deleted
    createdAt: { type: Number },
    updatedAt: { type: Number }
}, {
    versionKey: false
});


hooks.configure(account);
module.exports = account;