'use strict';

const service = require('../service');

/*
 * function : to list the user all linked accounts
 * params : userId
 * output : success or error
 */
exports.userAccountListing = async(request, h) => {
    // eslint-disable-next-line no-undef
    const log = logger.start('accounts:api:userAccountListing');
    try {
        const res = await service.userAccountListing(request.userInfo.id);
        log.end();
        // eslint-disable-next-line no-undef
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.end();
        return response.failure(h, err.message);
    }
};