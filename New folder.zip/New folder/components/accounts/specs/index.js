'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    userAccountListing: {
        description: 'Get user all linked accounts',
        notes: 'Get user all linked accounts',
        tags: ['api', 'accounts'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.userAccountListing.query,
            // eslint-disable-next-line no-undef
            failAction: response.failAction
        }
    }
};