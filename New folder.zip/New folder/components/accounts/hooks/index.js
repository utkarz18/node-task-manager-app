/* eslint-disable no-unused-vars */
'use strict';


const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (account) => {
    account.pre('save', function(next) {
        next();
    });

    account.post('save', async(doc) => {});

    account.pre('find', function(next) {
        next();
    });

    account.pre('findOne', function(next) {
        next();
    });
};