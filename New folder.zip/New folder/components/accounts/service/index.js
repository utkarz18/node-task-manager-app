'use strict';
const message = require('../../../utils/messages');

/*
 * function : to list the user all linked accounts
 * params : userId
 * output : success or error
 */
exports.userAccountListing = async(userId) => {
    const log = logger.start('accounts:service:userAccountListing');

    const accounts = await db.accounts.find({ userId: userId });
    if (!accounts) throw new Error('No records found.');

    log.end();
    return {
        message: message.account_list,
        data: accounts
    };
};