'use strict';

// const mapper = require('../mapper')
const service = require('../service');
const path = require('path');

/*
 * function : get saltedge connect url for user
 * params : request object
 * output : success & failure
 */
exports.getConnectUrl = async(request, h) => {
    const log = logger.start('saltEdge:api:getConnectUrl');

    try {
        const res = await service.getConnectUrl(request.userInfo, request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function : get saltedge user linked bank all entities (like cc, card account etc)
 * params : request object
 * output : success & failure
 */
exports.getBankEntities = async(request, h) => {
    const log = logger.start('saltEdge:api:getConnectUrl');

    try {
        const res = await service.getBankEntities(request.userInfo);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function : save user bank entities for roundup
 * params : array of ids
 * output : success & failure
 */
exports.saveEntityForRoundUp = async(request, h) => {
    const log = logger.start('saltEdge:api:saveEntityForRoundUp');

    try {
        const res = await service.saveEntityForRoundUp(request.userInfo, request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function : get transactions fort roundup
 * params :
 * output : success & failure
 */
exports.getTransactionsRoundUp = async(request, h) => {
    const log = logger.start('saltEdge:api:getTransactionsRoundUp');

    try {
        const res = await service.getTransactionsRoundUp(request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};