/**
author : Aditi
created_on : 26 June 2019
**/
'use strict';
const api = require('../api');
const specs = require('../specs');

module.exports = [{
        method: 'GET',
        path: '/api/saltEdge/getConnectUrl',
        options: specs.getConnectUrl,
        handler: api.getConnectUrl
    }, {
        method: 'GET',
        path: '/api/saltEdge/getBankEntities',
        options: specs.getBankEntities,
        handler: api.getBankEntities
    },
    {
        method: 'POST',
        path: '/api/saltEdge/saveEntityForRoundUp',
        options: specs.saveEntityForRoundUp,
        handler: api.saveEntityForRoundUp
    },
    {
        method: 'GET',
        path: '/api/saltEdge/getTransactionsRoundUp',
        options: specs.getTransactionsRoundUp,
        handler: api.getTransactionsRoundUp
    }
];