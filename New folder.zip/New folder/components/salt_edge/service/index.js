'use strict';

const fetch = require('node-fetch');
const saltModel = require('../../salt_edge/model');
const saltEdgeKeys = require('config').get('SALTEDGE_KEYS');
const roundUpBaseAmount = require('config').get('RoundUp_Amount');
const schedule = require('node-schedule');
const saltEdgeReturnUrl = require('config').get('SlatEdge_Return_Url');
const message = require('../../../utils/messages');

// var event = schedule.scheduleJob("*/3 * * * * *", function() {
// console.log('This runs here every 3 sec');
// });

/*
    function : get fastlink url for browser open specific to user
    params : userId
    output : link of yodlee user specific
*/
exports.getConnectUrl = async(userData, params) => {
    var reqBody = {
        'data': {
            'customer_id': userData.loginName,
            'consent': {
                'scopes': ['account_details', 'transactions_details'],
                'from_date': moment().format('YYYY-MM-DD')
            },
            'attempt': {
                'return_to': saltEdgeReturnUrl
            }
        }
    };
    const url = saltEdgeKeys.base_url + 'connect_sessions/create';
    const res = await fetch(url, {
        method: 'post',
        body: JSON.stringify(reqBody),
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'App-id': saltEdgeKeys.app_id,
            'Secret': saltEdgeKeys.secret,
            'Customer-Secret': userData.customerSecret
        },
    });

    const datas = await res.json();
    return {
        'message': message.connect_url,
        'data': {
            'saltedge': datas.data.connect_url
        }
    };
};

/*
    function : get saltedge user linked bank all entities (like cc, card account etc)
    params : userData
    output : link of yodlee user specific
*/
exports.getBankEntities = async(userData) => {
    // get connections of the user (i.e bank accounts of the user)
    const url = saltEdgeKeys.base_url + 'connections?customer_id=' + userData.loginName;
    const res = await fetch(url, {
        method: 'get',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'App-id': saltEdgeKeys.app_id,
            'Secret': saltEdgeKeys.secret,
            'Customer-Secret': userData.customerSecret
        },
    });

    const datas = await res.json();

    if (datas.data.length === 0) {
        throw new Error(message.no_bank_account);
    }

    if (datas.error !== undefined) {
        throw new Error(datas.error.class);
    }

    // save account id in user table 
    const saveAccountId = await db.users.findOneAndUpdate({ _id: userData.id }, { connectionId: datas.data[0].id }, { new: true, lean: true });

    // fetch connections currently only one bank account
    const url2 = saltEdgeKeys.base_url + 'accounts?connection_id=' + datas.data[0].id;
    const res2 = await fetch(url2, {
        method: 'get',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'App-id': saltEdgeKeys.app_id,
            'Secret': saltEdgeKeys.secret,
            'Customer-Secret': userData.customerSecret
        },
    });
    const datas2 = await res2.json();
    if (datas2.data.length === 0) {
        throw new Error(message.no_bank_entities);
    }
    return {
        'message': message.bank_entities,
        'data': {
            'bankData': datas.data[0],
            'accounts': datas2.data
        }
    };
};

/*
 * function : save user bank entities for roundup
 * params : array of ids
 * output : success & failure
 */
exports.saveEntityForRoundUp = async(userData, params) => {
    var accountIds = params.entity_id;
    var accId = [];
    accountIds.forEach(ids => {
        accId = {
            userId: userData.id,
            accountId: userData.connectionId,
            entityId: ids,
            createdAt: moment().unix(),
            updatedAt: moment().unix(),
        };
        const saveAcc = db.salt_edge.create(accId);
    });
    return {
        'message': message.account_saved_roundup,
        'data': {}
    };
};

exports.getTransactionsRoundUp = async(params) => {

    let criteria = { isRoundUpEnabled: true, isDeleted: false };
    const users = await db.users.aggregate([
        { $match: criteria },
        {
            $lookup: {
                from: 'salt_edges',
                localField: '_id',
                foreignField: 'userId',
                as: 'accountsData'
            }
        },
        {
            $project: {
                'accountsData._id': 1,
                'accountsData.accountId': 1,
                'accountsData.entityId': 1,
                'accountsData.roundupAmount': 1,
                first_name: 1,
                last_name: 1,
                profilePic: 1,
                dob: 1,
                loginName: 1,
                customerSecret: 1,
                connectionId: 1,
                roundup: 1
            }
        }
    ]);
    if (users.length > 0) {
        users.forEach(async(user) => {
            user.accountsData.forEach(async(account) => {
                const url = saltEdgeKeys.base_url + 'transactions?connection_id=' + account.accountId + '&account_id=' + account.entityId;
                const res = await fetch(url, {
                    method: 'get',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'App-id': saltEdgeKeys.app_id,
                        'Secret': saltEdgeKeys.secret,
                        'Customer-Secret': user.customerSecret
                    },
                });

                const datas = await res.json();
                var total = (account.roundupAmount && account.roundupAmount !== undefined) ? account.roundupAmount : 0;
                datas.data.forEach(async(transaction) => {
                    // transaction.made_on == moment().subtract(1, 'days').format('YYYY-MM-DD') && 
                    if (transaction.amount > 0) {
                        let remainingAmount = Math.ceil(transaction.amount) - transaction.amount;
                        if (remainingAmount === 0) {
                            remainingAmount = 1;
                        }
                        remainingAmount = parseFloat(remainingAmount.toFixed(2));
                        total = total + remainingAmount;
                    }
                });

                if (total >= roundUpBaseAmount) {
                    let totalRoundUpAmount = (roundUpBaseAmount * user.roundup.gold) + (roundUpBaseAmount * user.roundup.silver) + (roundUpBaseAmount * user.roundup.platinum) + (roundUpBaseAmount * user.roundup.palladium) + (roundUpBaseAmount * user.roundup.rhodium);
                    // payment gateway transaction and save in payment table 
                    console.log('account._id', account._id);
                    const updateAmount = await db.salt_edge.findOneAndUpdate({ _id: account._id }, {
                        roundupAmount: 0
                    });
                } else {
                    const updateAmount = await db.salt_edge.findOneAndUpdate({ _id: account._id }, {
                        roundupAmount: total
                    });

                }
            });
        });
    }

};