/* eslint-disable camelcase */
'use strict';
const hooks = require('../hooks');

const salt_edge = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    accountId: { type: Number },
    entityId: { type: Number },
    roundupAmount: { type: Number },
    createdAt: { type: Number },
    updatedAt: { type: Number }
}, {
    versionKey: false
});

hooks.configure(salt_edge);
module.exports = salt_edge;