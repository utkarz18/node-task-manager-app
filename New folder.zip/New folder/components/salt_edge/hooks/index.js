/* eslint-disable camelcase */
'use strict';

const moment = require('moment');

const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (salt_edge) => {
    salt_edge.pre('save', function(next) {
        next();
    });

    salt_edge.post('save', async(doc) => {});

    salt_edge.pre('find', function(next) {
        next();
    });

    salt_edge.pre('findOne', function(next) {
        next();
    });
};