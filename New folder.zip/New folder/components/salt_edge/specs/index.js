'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    getConnectUrl: {
        description: 'Get Salt-edge Connect url for user',
        notes: 'SaltEdge Connect url',
        tags: ['api', 'saltEdge'],
        pre: [{ method: context.validateToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            query: validator.getConnectUrl.query,
            failAction: response.failAction
        }
    },
    getBankEntities: {
        description: 'Get user attached bank linked entities',
        notes: 'Get user attached bank linked entities',
        tags: ['api', 'saltEdge'],
        pre: [{ method: context.validateToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            query: validator.getBankEntities.query,
            failAction: response.failAction
        }
    },
    saveEntityForRoundUp: {
        description: 'Save user bank entities for roundup transactions',
        notes: 'Save user bank entities for roundup transactions',
        tags: ['api', 'saltEdge'],
        pre: [{ method: context.validateToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.saveEntityForRoundUp.payload,
            failAction: response.failAction
        }
    },
    getTransactionsRoundUp: {
        description: 'Get transactions from user accounts linked for roundup',
        notes: 'Get transactions from user accounts linked for roundup',
        tags: ['api', 'saltEdge'],
        // pre: [{ method: context.validateToken, assign: 'token' }],
        validate: {
            //  headers: validator.header,
            query: validator.getTransactionsRoundUp.query,
            failAction: response.failAction
        }
    }
};