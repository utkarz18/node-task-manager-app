/**
author : Aditi
created_on : 26 June 2019
**/
'use strict';
const api = require('../api');
const specs = require('../specs');

module.exports = [{
        method: 'GET',
        path: '/api/contact/reasons',
        options: specs.reasons,
        handler: api.reasons
    },
    {
        method: 'POST',
        path: '/api/users/contactUs',
        options: specs.contactUs,
        handler: api.contactUs
    }
];