'use strict';

// const mapper = require('../mapper')
const service = require('../service');

exports.reasons = async(request, h) => {
    const log = logger.start('contact:api:reasons');

    try {
        const res = await service.reasons(request.query);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.contactUs = async(request, h) => {
    const log = logger.start('contact:api:contactUs');

    try {
        const res = await service.contactUs(request.userInfo, request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};