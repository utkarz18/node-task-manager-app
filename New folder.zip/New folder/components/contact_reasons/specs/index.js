'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    reasons: {
        description: 'Get contact reasons',
        notes: 'Get contact reasons',
        tags: ['api', 'contact'],
        pre: [{ method: context.validateToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            query: validator.reasons.query,
            failAction: response.failAction
        }
    },
    contactUs: {
        description: 'Send us a message',
        notes: 'Send us a message',
        tags: ['api', 'contact'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    },
                    400: {
                        description: 'invalid token/user',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            payload: validator.contactUs.payload,
            failAction: response.failAction
        }
    }
};