'use strict';

const md5 = require('md5');
const auth = require('../../../utils/auth');
const message = require('../../../utils/messages');


exports.reasons = async(params) => {
    const log = logger.start('contact:services:reasons');

    const contactReason = await db.contact_reasons.find({ status: 1 });
    log.end();

    return {
        'message': message.contact_reason,
        'data': contactReason
    };

};

exports.contactUs = async(userData, params) => {
    const log = logger.start('contact:services:contactUs');

    const contactReason = await db.contact_reasons.findOne({ _id: mongoose.Types.ObjectId(params.reason_id) });
    console.log('contactReason', contactReason);
    if (!contactReason)
        throw new Error(message.reason_id);

    offline.queue('contact', 'send-message', {
        id: userData.id,
        reason: contactReason.reason,
        message: params.message,
        contact_type: params.contact_type
    }, {});

    log.end();

    return {
        'message': message.contact_success,
        'data': {}
    };

};