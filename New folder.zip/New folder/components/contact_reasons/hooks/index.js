/* eslint-disable camelcase */
/* eslint-disable no-unused-vars */
'use strict';


const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (contact_reason) => {
    contact_reason.pre('save', function(next) {
        next();
    });

    contact_reason.post('save', async(doc) => {});

    contact_reason.pre('find', function(next) {
        next();
    });

    contact_reason.pre('findOne', function(next) {
        next();
    });
};