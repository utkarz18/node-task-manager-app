/* eslint-disable camelcase */
'use strict';
const hooks = require('../hooks');

const contact_reason = new mongoose.Schema({
    reason: { type: String },
    status: { type: Number }
}, {
    versionKey: false
});

hooks.configure(contact_reason);
module.exports = contact_reason;