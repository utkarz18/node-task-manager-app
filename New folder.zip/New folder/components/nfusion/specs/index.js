'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    getMetals: {
        description: 'Get list of all metals',
        notes: 'Metals List',
        tags: ['api', 'nfusion'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.getMetals.query,
            failAction: response.failAction
        }
    },
    getMetalDetail: {
        description: 'Get metal details',
        notes: 'Metal Detail',
        tags: ['api', 'nfusion'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.getMetalDetail.query,
            failAction: response.failAction
        }
    },
    getAllMetalDetails: {
        description: 'Get all metal details',
        notes: 'All Metal Detail',
        tags: ['api', 'nfusion'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.getAllMetalDetails.query,
            failAction: response.failAction
        }
    },
    getIntervalData: {
        description: 'Get all metal data interval wise(today,week,month,ytd,5year,10year,25year)',
        notes: 'All Metal Detail interval based',
        tags: ['api', 'nfusion'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.getIntervalData.query,
            failAction: response.failAction
        }
    }
};