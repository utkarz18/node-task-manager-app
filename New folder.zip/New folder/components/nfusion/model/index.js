'use strict';
const hooks = require('../hooks');

const nfusion = new mongoose.Schema({
    name: { type: String },
    symbol: { type: String },
    description: { type: String },
    status: { type: Number }
}, {
    versionKey: false
});


hooks.configure(nfusion);
module.exports = nfusion;