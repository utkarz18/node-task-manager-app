/* eslint-disable require-atomic-updates */
'use strict';

const nfusionCredentials = require('config').get('Nfusion');
const request = require('request');
const fetch = require('node-fetch');
const schedule = require('node-schedule');
const message = require('../../../utils/messages');

/*
 * function : get metals listing
 * params : n/a
 * output : success & failure with listing
 */
exports.getMetals = async() => {
    // eslint-disable-next-line no-undef
    const log = logger.start('nfusion:services:getMetals');

    var url = nfusionCredentials.nfusion_baseUrl + 'spot/supported?token=' + nfusionCredentials.nfusion_token + '&format=json';

    const res = await fetch(url);
    const data = await res.json();

    log.end();
    return {
        'message': message.metal_fetch,
        'data': data
    };

};

/*
 * function : get metals details
 * params : metal symbol
 * output : success & failure with details
 */
exports.getMetalDetail = async(params) => {
    // eslint-disable-next-line no-undef
    const log = logger.start('nfusion:services:getMetalDetails');

    // eslint-disable-next-line no-undef
    const metalDetail = await db.nfusion.findOne({ 'name': params.symbol });
    if (!metalDetail) {
        throw new Error(message.no_metal);
    }

    let metalData;
    // const metalData = await getTodayData(params.symbol);
    if (params.symbol === 'Rhodium') {
        // eslint-disable-next-line require-atomic-updates
        params.interval = 'year';
        metalData = await rhodiumYearlyData(params);
    } else {
        // eslint-disable-next-line require-atomic-updates
        params.start_date = moment().subtract(365, 'days').format('YYYY-MM-DD');
        params.end_date = moment().format('YYYY-MM-DD');
        params.interval = 'm';
        // data = await getMetalsData(params);
        metalData = await getMetalsData(params);
    }
    log.end();
    return {
        'message': message.metal_fetch,
        'data': { vaultData: {}, data: metalData[0], description: metalDetail.description }
    };

};

/*
 * function : get metals listing with details
 * params : n/a
 * output : success & failure with details
 */
exports.getAllMetalDetails = async(params) => {
    const log = logger.start('nfusion:services:getAllMetalDetails');

    const data = await todayMetalData();
    return {
        'message': message.metal_data,
        'data': data
    };

};

/*
 * function for getting the current object for the metals (gold,silver,platinum,palladium,rhodium)
 */
const metalsCurrentObject = async() => {
    // for gold current object
    var gold = nfusionCredentials.nfusion_baseUrl + 'spot/summary?token=' + nfusionCredentials.nfusion_token + '&metals=Gold&currency=USD&unitofmeasure=toz&format=json';
    const goldres = await fetch(gold);
    const golddata = await goldres.json();

    // for silver current object
    var silver = nfusionCredentials.nfusion_baseUrl + 'spot/summary?token=' + nfusionCredentials.nfusion_token + '&metals=Silver&currency=USD&unitofmeasure=toz&format=json';
    const silverres = await fetch(silver);
    const silverdata = await silverres.json();

    // for platinum current object
    var platinum = nfusionCredentials.nfusion_baseUrl + 'spot/summary?token=' + nfusionCredentials.nfusion_token + '&metals=Platinum&currency=USD&unitofmeasure=toz&format=json';
    const platinumres = await fetch(platinum);
    const platinumdata = await platinumres.json();

    // for palladium current object
    var palladium = nfusionCredentials.nfusion_baseUrl + 'spot/summary?token=' + nfusionCredentials.nfusion_token + '&metals=Palladium&currency=USD&unitofmeasure=toz&format=json';
    const palladiumres = await fetch(palladium);
    const palladiumdata = await palladiumres.json();

    // for rhodium current object
    var rhodium = nfusionCredentials.nfusion_baseUrl + 'spot/summary?token=' + nfusionCredentials.nfusion_token + '&metals=Rhodium&currency=USD&unitofmeasure=toz&format=json';
    const rhodiumres = await fetch(rhodium);
    const rhodiumdata = await rhodiumres.json();

    return { gold: golddata, silver: silverdata, platinum: platinumdata, palladium: palladiumdata, rhodium: rhodiumdata };
};

/*
 * function to fetch today data for all metals
 */
const todayMetalData = async() => {
    const metalsData = await metalsCurrentObject();
    const currentDate = moment().format('YYYY-MM-DD');
    // get all metals today data hourly basis (listing)
    var url = nfusionCredentials.nfusion_baseUrl + 'spot/history?token=' + nfusionCredentials.nfusion_token + '&metals=Gold,Silver,Platinum,Palladium,Rhodium&start=' + currentDate + '&interval=h&historicalfx=true&currency=USD&unitofmeasure=toz&format=json';
    const res = await fetch(url);
    const data = await res.json();

    data.forEach(function(value, key) {

        if (value.requestedSymbol === 'Gold') {
            let currentData = {
                amount: metalsData.gold[0].data.last,
                oneDayChange: metalsData.gold[0].data.oneDayChange,
                oneDayPercentChange: metalsData.gold[0].data.oneDayPercentChange,
                timeStamp: metalsData.gold[0].data.timeStamp,
            };
            Object.assign(value, currentData);
        }

        if (value.requestedSymbol === 'Silver') {
            let currentData = {
                amount: metalsData.silver[0].data.last,
                oneDayChange: metalsData.silver[0].data.oneDayChange,
                oneDayPercentChange: metalsData.silver[0].data.oneDayPercentChange,
                timeStamp: metalsData.silver[0].data.timeStamp,
            };
            Object.assign(value, currentData);
        }

        if (value.requestedSymbol === 'Platinum') {
            let currentData = {
                amount: metalsData.platinum[0].data.last,
                oneDayChange: metalsData.platinum[0].data.oneDayChange,
                oneDayPercentChange: metalsData.platinum[0].data.oneDayPercentChange,
                timeStamp: metalsData.platinum[0].data.timeStamp,
            };
            Object.assign(value, currentData);
        }

        if (value.requestedSymbol === 'Palladium') {
            let currentData = {
                amount: metalsData.palladium[0].data.last,
                oneDayChange: metalsData.palladium[0].data.oneDayChange,
                oneDayPercentChange: metalsData.palladium[0].data.oneDayPercentChange,
                timeStamp: metalsData.palladium[0].data.timeStamp,
            };
            Object.assign(value, currentData);
        }

        if (value.requestedSymbol === 'Rhodium') {
            let currentData = {
                amount: metalsData.rhodium[0].data.last,
                oneDayChange: metalsData.rhodium[0].data.oneDayChange,
                oneDayPercentChange: metalsData.rhodium[0].data.oneDayPercentChange,
                timeStamp: metalsData.rhodium[0].data.timeStamp,
            };
            Object.assign(value, currentData);
        }
    });
    return data;
};

/*
 * function : to get the metals data on theinterval based i.e (today, week, month, ytd, 5year,10year,25 year)
 * params : symbol (metal name - gold,silver,platinum,palladium,rhodium), interval (today, week, month, ytd, 5year,10year,25 year)
 * output : success & failure
 */
exports.getIntervalData = async(params) => {
    const log = logger.start('nfusion:services:getIntervalData');
    let data;
    if (params.interval === 'today') {
        data = await getTodayData(params.symbol);
    }

    if (params.interval === 'week') {
        params.start_date = moment().subtract(6, 'days').format('YYYY-MM-DD');
        params.end_date = moment().format('YYYY-MM-DD');
        params.interval = 'd';
        data = await getMetalsData(params);
    }

    if (params.interval === 'month') {
        params.start_date = moment().subtract(29, 'days').format('YYYY-MM-DD');
        params.end_date = moment().format('YYYY-MM-DD');
        params.interval = 'd';
        data = await getMetalsData(params);
    }

    if (params.interval === 'ytd') {
        if (params.symbol === 'Rhodium') {
            data = await rhodiumYearlyData(params);
        } else {
            const currentYear = moment().format('YYYY');
            params.start_date = currentYear + '-01-01';
            params.end_date = moment().format('YYYY-MM-DD');
            params.interval = 'm';
            data = await getMetalsData(params);
        }
    }

    if (params.interval === 'year') {
        if (params.symbol === 'Rhodium') {
            data = await rhodiumYearlyData(params);
        } else {
            params.start_date = moment().subtract(365, 'days').format('YYYY-MM-DD');
            params.end_date = moment().format('YYYY-MM-DD');
            params.interval = 'm';
            data = await getMetalsData(params);
        }
    }

    if (params.interval === '5year') {
        if (params.symbol === 'Rhodium') {
            let days = 365 * 5;
            params.year = 5;
            params.start_date = moment().subtract(days, 'days').format('YYYY-MM-DD');
            params.end_date = moment().format('YYYY-MM-DD');
            data = await rhodiumAnnualData(params);
        } else {
            params.years = 5;
            data = await getAnnualData(params);
        }
    }

    if (params.interval === '10year') {
        if (params.symbol === 'Rhodium') {
            let days = 365 * 10;
            params.year = 10;
            params.start_date = moment().subtract(days, 'days').format('YYYY-MM-DD');
            params.end_date = moment().format('YYYY-MM-DD');
            data = await rhodiumAnnualData(params);
        } else {
            params.years = 10;
            data = await getAnnualData(params);
        }
    }

    if (params.interval === '25year') {
        if (params.symbol === 'Rhodium') {
            let days = 365 * 25;
            params.year = 25;
            params.start_date = moment().subtract(days, 'days').format('YYYY-MM-DD');
            params.end_date = moment().format('YYYY-MM-DD');
            data = await rhodiumAnnualData(params);
        } else {
            params.years = 25;
            data = await getAnnualData(params);
        }
    }

    return {
        'message': message.metal_data,
        'data': data[0]
    };
};

/*
 * function to fetch today data of single metal
 */
const getTodayData = async(metalName) => {
    const metalsData = await metalsCurrentObject();
    const currentDate = moment().format('YYYY-MM-DD');
    // get all metals today data hourly basis (listing)
    var url = nfusionCredentials.nfusion_baseUrl + 'spot/history?token=' + nfusionCredentials.nfusion_token + '&metals=' + metalName + '&start=' + currentDate + '&interval=h&historicalfx=true&currency=USD&unitofmeasure=toz&format=json';
    const res = await fetch(url);
    const data = await res.json();

    if (metalName === 'Gold') {
        data[0].amount = metalsData.gold[0].data.last;
        data[0].oneDayChange = metalsData.gold[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.gold[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.gold[0].data.timeStamp;
    }

    if (metalName === 'Silver') {
        data[0].amount = metalsData.silver[0].data.last;
        data[0].oneDayChange = metalsData.silver[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.silver[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.silver[0].data.timeStamp;
    }

    if (metalName === 'Platinum') {
        data[0].amount = metalsData.platinum[0].data.last;
        data[0].oneDayChange = metalsData.platinum[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.platinum[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.platinum[0].data.timeStamp;
    }

    if (metalName === 'Palladium') {
        data[0].amount = metalsData.palladium[0].data.last;
        data[0].oneDayChange = metalsData.palladium[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.palladium[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.palladium[0].data.timeStamp;
    }

    if (metalName === 'Rhodium') {
        data[0].amount = metalsData.rhodium[0].data.last;
        data[0].oneDayChange = metalsData.rhodium[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.rhodium[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.rhodium[0].data.timeStamp;
    }

    return data;
};

/*
 * function to fetch metals data on parameters (week, month, ytd)
 */
const getMetalsData = async(params) => {
    const metalsData = await metalsCurrentObject();

    // get all metals today data hourly basis (listing)
    var url = nfusionCredentials.nfusion_baseUrl + 'spot/history?token=' + nfusionCredentials.nfusion_token + '&metals=' + params.symbol + '&start=' + params.start_date + '&end=' + params.end_date + '&interval=' + params.interval + '&historicalfx=true&currency=USD&unitofmeasure=toz&format=json';
    const res = await fetch(url);
    const data = await res.json();

    if (params.symbol === 'Gold') {
        data[0].amount = metalsData.gold[0].data.last;
        data[0].oneDayChange = metalsData.gold[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.gold[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.gold[0].data.timeStamp;
    }

    if (params.symbol === 'Silver') {
        data[0].amount = metalsData.silver[0].data.last;
        data[0].oneDayChange = metalsData.silver[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.silver[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.silver[0].data.timeStamp;
    }

    if (params.symbol === 'Platinum') {
        data[0].amount = metalsData.platinum[0].data.last;
        data[0].oneDayChange = metalsData.platinum[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.platinum[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.platinum[0].data.timeStamp;
    }

    if (params.symbol === 'Palladium') {
        data[0].amount = metalsData.palladium[0].data.last;
        data[0].oneDayChange = metalsData.palladium[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.palladium[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.palladium[0].data.timeStamp;
    }

    if (params.symbol === 'Rhodium') {
        data[0].amount = metalsData.rhodium[0].data.last;
        data[0].oneDayChange = metalsData.rhodium[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.rhodium[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.rhodium[0].data.timeStamp;
    }

    return data;
};


/*
 * function to fetch metals data on parameters (5,10,25) years
 */
const getAnnualData = async(params) => {
    const metalsData = await metalsCurrentObject();

    // get all metals today data hourly basis (listing)
    var url = nfusionCredentials.nfusion_baseUrl + 'spot/performance/annual?token=' + nfusionCredentials.nfusion_token + '&metals=' + params.symbol + '&currency=USD&unitofmeasure=toz&format=json&years=' + params.years;
    const res = await fetch(url);
    const data = await res.json();

    if (params.symbol === 'Gold') {
        data[0].amount = metalsData.gold[0].data.last;
        data[0].oneDayChange = metalsData.gold[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.gold[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.gold[0].data.timeStamp;
    }

    if (params.symbol === 'Silver') {
        data[0].amount = metalsData.silver[0].data.last;
        data[0].oneDayChange = metalsData.silver[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.silver[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.silver[0].data.timeStamp;
    }

    if (params.symbol === 'Platinum') {
        data[0].amount = metalsData.platinum[0].data.last;
        data[0].oneDayChange = metalsData.platinum[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.platinum[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.platinum[0].data.timeStamp;
    }

    if (params.symbol === 'Palladium') {
        data[0].amount = metalsData.palladium[0].data.last;
        data[0].oneDayChange = metalsData.palladium[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.palladium[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.palladium[0].data.timeStamp;
    }

    if (params.symbol === 'Rhodium') {
        data[0].amount = metalsData.rhodium[0].data.last;
        data[0].oneDayChange = metalsData.rhodium[0].data.oneDayChange;
        data[0].oneDayPercentChange = metalsData.rhodium[0].data.oneDayPercentChange;
        data[0].timeStamp = metalsData.rhodium[0].data.timeStamp;
    }

    return data;
};

var event = schedule.scheduleJob({ hour: 1, minute: 0 }, function() {
    const date = moment().subtract(1, 'days').format('YYYY-MM-DD');
    var url = nfusionCredentials.nfusion_baseUrl + 'spot/history?token=' + nfusionCredentials.nfusion_token + '&metals=Rhodium&start=' + date + '&interval=d&historicalfx=true&currency=USD&unitofmeasure=toz&format=json';

    request(url, function(error, response, body) {
        if (error) {
            throw new Error(error);
        } else {
            var object = JSON.parse(response.body);
            var rhodiumModel = {
                'start': object[0].data.intervals[0].start,
                'end': object[0].data.intervals[0].end,
                'open': object[0].data.intervals[0].open,
                'high': object[0].data.intervals[0].high,
                'low': object[0].data.intervals[0].low,
                'last': object[0].data.intervals[0].last,
                'change': (object[0].data.intervals[0].change && object[0].data.intervals[0].change !== undefined) ? object[0].data.intervals[0].change : 0,
                'changePercent': (object[0].data.intervals[0].changePercent && object[0].data.intervals[0].changePercent !== undefined) ? object[0].data.intervals[0].changePercent : 0,
                'createdAt': moment().unix()
            };

            const saveData = db.rhodium.create(rhodiumModel);
        }
    });
});


const rhodiumAnnualData = async(params) => {

    const url = nfusionCredentials.nfusion_baseUrl + 'spot/history?token=' + nfusionCredentials.nfusion_token + '&metals=Rhodium&start=' + params.start_date + '&end=' + params.end_date + '&interval=y&historicalfx=false&currency=USD&unitofmeasure=toz&format=json';
    const res = await fetch(url);
    const data = await res.json();

    const currentData = await metalsCurrentObject();

    data[0].amount = currentData.rhodium[0].data.last;
    data[0].oneDayChange = currentData.rhodium[0].data.oneDayChange;
    data[0].oneDayPercentChange = currentData.rhodium[0].data.oneDayPercentChange;
    data[0].timeStamp = currentData.rhodium[0].data.timeStamp;

    const metalsData = data[0].data.intervals;
    var d = new Date();
    var n = d.getFullYear();

    let count = params.year;
    let tempArray = [];
    metalsData.forEach(function(key, value) {
        var localDate = new Date(key.start);
        var dates = localDate.getFullYear();
        if (dates === (n - count)) {
            tempArray.push(key);
            count = count - 1;
        }
    });

    data[0].data.intervals = tempArray.slice(0);
    return data;
};


const rhodiumYearlyData = async(params) => {
    if (params.interval === 'ytd') {
        let temparray = [];
        let currentDate = new Date();
        let currentMonth = moment(currentDate).format('M');
        let currentYear = moment(currentDate).format('YYYY');
        let startDate = currentYear + '-01-01';
        let startMonth = 1;
        let finalMon = parseInt(currentMonth) + parseInt(1);
        for (startMonth; startMonth < finalMon; startMonth++) {
            if (startMonth <= currentMonth) {
                let start = currentYear + '-' + startMonth + '-01';
                let end = currentYear + '-' + startMonth + '-' + moment(currentYear + '-' + startMonth, 'YYYY-MM').daysInMonth();

                let url = nfusionCredentials.nfusion_baseUrl + 'spot/history?token=' + nfusionCredentials.nfusion_token + '&metals=Rhodium&start=' + start + '&end=' + end + '&interval=d&historicalfx=false&currency=USD&unitofmeasure=toz&format=json';

                const res = await fetch(url);
                const data = await res.json();

                let arrayFirstObject = data[0].data.intervals[0];
                let arrayLastObject = data[0].data.intervals.slice(-1)[0];

                let finalDataModel = {
                    'start': arrayFirstObject.start,
                    'end': arrayLastObject.end,
                    'open': arrayLastObject.open,
                    'high': arrayLastObject.high,
                    'low': arrayLastObject.low,
                    'last': arrayLastObject.last,
                    // "change": (arrayLastObject.change && arrayLastObject.change != undefined) ? arrayLastObject.change : 0,
                    //  "changePercent": (arrayLastObject.changePercent && arrayLastObject.changePercent != undefined) ? arrayLastObject.changePercent : 0
                };
                temparray.push(finalDataModel);
            }
        }

        const url = nfusionCredentials.nfusion_baseUrl + 'spot/history?token=' + nfusionCredentials.nfusion_token + '&metals=Rhodium&start=' + moment().format('YYYY-MM-DD') + '&interval=y&historicalfx=false&currency=USD&unitofmeasure=toz&format=json';
        const res = await fetch(url);
        const data = await res.json();

        const currentData = await metalsCurrentObject();

        data[0].amount = currentData.rhodium[0].data.last;
        data[0].oneDayChange = currentData.rhodium[0].data.oneDayChange;
        data[0].oneDayPercentChange = currentData.rhodium[0].data.oneDayPercentChange;
        data[0].timeStamp = currentData.rhodium[0].data.timeStamp;
        data[0].data.intervals = temparray.slice(0);
        return data;
    }

    if (params.interval === 'year') {
        let temparray = [];
        let currentDate = new Date();
        let cDate = moment(currentDate).format('D');
        let currentMonth = moment(currentDate).format('M');
        let currentYear = moment(currentDate).format('YYYY');

        let startDate = moment().subtract(366, 'days').format('YYYY-MM-DD');
        let startMonth = moment(startDate).format('M');
        let startYear = moment(startDate).format('YYYY');

        // calculate for last year 
        if (startYear !== currentYear) {

            let finalMon = parseInt(12) + parseInt(1);

            for (startMonth; startMonth < finalMon; startMonth++) {
                if (startMonth <= 12) {
                    let start = startYear + '-' + startMonth + '-' + '01';
                    let end = startYear + '-' + startMonth + '-' + moment(startYear + '-' + startMonth, 'YYYY-MM').daysInMonth();

                    let url = nfusionCredentials.nfusion_baseUrl + 'spot/history?token=' + nfusionCredentials.nfusion_token + '&metals=Rhodium&start=' + start + '&end=' + end + '&interval=d&historicalfx=false&currency=USD&unitofmeasure=toz&format=json';

                    const res = await fetch(url);
                    const data = await res.json();

                    let arrayFirstObject = data[0].data.intervals[0];
                    let arrayLastObject = data[0].data.intervals.slice(-1)[0];

                    let finalDataModel = {
                        'start': arrayFirstObject.start,
                        'end': arrayLastObject.end,
                        'open': arrayLastObject.open,
                        'high': arrayLastObject.high,
                        'low': arrayLastObject.low,
                        'last': arrayLastObject.last,
                        // "change": (arrayLastObject.change && arrayLastObject.change != undefined) ? arrayLastObject.change : 0,
                        // "changePercent": (arrayLastObject.changePercent && arrayLastObject.changePercent != undefined) ? arrayLastObject.changePercent : 0
                    };
                    temparray.push(finalDataModel);
                }
            }
        }

        // calculate for current year 
        const currentYearData = await rhodiumYTD();
        currentYearData.forEach(function(key, value) {
            temparray.push(key);
        });

        const url = nfusionCredentials.nfusion_baseUrl + 'spot/history?token=' + nfusionCredentials.nfusion_token + '&metals=Rhodium&start=' + moment().format('YYYY-MM-DD') + '&interval=y&historicalfx=false&currency=USD&unitofmeasure=toz&format=json';
        const res = await fetch(url);
        const data = await res.json();

        const currentData = await metalsCurrentObject();

        data[0].amount = currentData.rhodium[0].data.last;
        data[0].oneDayChange = currentData.rhodium[0].data.oneDayChange;
        data[0].oneDayPercentChange = currentData.rhodium[0].data.oneDayPercentChange;
        data[0].timeStamp = currentData.rhodium[0].data.timeStamp;
        data[0].data.intervals = temparray.slice(0);
        return data;

    }


};


const rhodiumYTD = async() => {
    let temparray = [];
    let currentDate = new Date();
    let currentMonth = moment(currentDate).format('M');
    let currentYear = moment(currentDate).format('YYYY');
    let startDate = currentYear + '-01-01';
    let startMonth = 1;
    let finalMon = parseInt(currentMonth) + parseInt(1);
    for (startMonth; startMonth < finalMon; startMonth++) {
        if (startMonth <= currentMonth) {
            let start = currentYear + '-' + startMonth + '-01';
            let end = currentYear + '-' + startMonth + '-' + moment(currentYear + '-' + startMonth, 'YYYY-MM').daysInMonth();

            let url = nfusionCredentials.nfusion_baseUrl + 'spot/history?token=' + nfusionCredentials.nfusion_token + '&metals=Rhodium&start=' + start + '&end=' + end + '&interval=d&historicalfx=false&currency=USD&unitofmeasure=toz&format=json';

            const res = await fetch(url);
            const data = await res.json();

            let arrayFirstObject = data[0].data.intervals[0];
            let arrayLastObject = data[0].data.intervals.slice(-1)[0];

            let finalDataModel = {
                'start': arrayFirstObject.start,
                'end': arrayLastObject.end,
                'open': arrayLastObject.open,
                'high': arrayLastObject.high,
                'low': arrayLastObject.low,
                'last': arrayLastObject.last,
                // "change": (arrayLastObject.change && arrayLastObject.change != undefined) ? arrayLastObject.change : 0,
                // "changePercent": (arrayLastObject.changePercent && arrayLastObject.changePercent != undefined) ? arrayLastObject.changePercent : 0
            };
            temparray.push(finalDataModel);
        }
    }
    return temparray;
};