/**
author : Aditi
created_on : 12 Nov 2018
**/
'use strict';
const api = require('../api');
const specs = require('../specs');

module.exports = [{
        method: 'GET',
        path: '/api/nfusion/getMetals',
        options: specs.getMetals,
        handler: api.getMetals
    }, {
        method: 'GET',
        path: '/api/nfusion/getMetalDetail',
        options: specs.getMetalDetail,
        handler: api.getMetalDetail
    }
    /*,
        {
            method: 'GET',
            path: '/api/nfusion/getAllMetalDetails',
            options: specs.getAllMetalDetails,
            handler: api.getAllMetalDetails
        } */
    ,
    {
        method: 'GET',
        path: '/api/nfusion/getIntervalData',
        options: specs.getIntervalData,
        handler: api.getIntervalData
    }
];