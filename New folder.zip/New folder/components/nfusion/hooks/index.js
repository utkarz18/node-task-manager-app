'use strict';

const moment = require('moment');

const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (nfusion) => {
    nfusion.pre('save', function(next) {
        next();
    });

    nfusion.post('save', async(doc) => {});

    nfusion.pre('find', function(next) {
        next();
    });

    nfusion.pre('findOne', function(next) {
        next();
    });
};