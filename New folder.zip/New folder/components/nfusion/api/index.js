'use strict';

const mapper = require('../mapper');
const service = require('../service');
const path = require('path');

/*
 * function : get metals listing
 * params : n/a
 * output : success & failure
 */
exports.getMetals = async(request, h) => {
    const log = logger.start('nfusion:api:getMetals');
    try {
        const res = await service.getMetals(request.query);
        log.end();

        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function : get metals detail
 * params : currency and metal symbol
 * output : success & failure
 */
exports.getMetalDetail = async(request, h) => {
    const log = logger.start('nfusion:api:getMetalDetail');
    try {
        const res = await service.getMetalDetail(request.query);
        log.end();

        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function : get all metals listing with detail
 * params : currency
 * output : success & failure
 */
exports.getAllMetalDetails = async(request, h) => {
    const log = logger.start('nfusion:api:getAllMetalDetails');
    try {
        const res = await service.getAllMetalDetails(request.query);
        log.end();

        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function : to get the metals data on theinterval based i.e (today, week, month, ytd, 5year,10year,25 year)
 * params : symbol (metal name - gold,silver,platinum,palladium,rhodium), interval (today, week, month, ytd, 5year,10year,25 year)
 * output : success & failure
 */
exports.getIntervalData = async(request, h) => {
    const log = logger.start('nfusion:api:getIntervalData');
    try {
        const res = await service.getIntervalData(request.query);
        log.end();

        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};