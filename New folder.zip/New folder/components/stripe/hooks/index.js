/* eslint-disable camelcase */
'use strict';

const moment = require('moment');

const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (stripe) => {
    stripe.pre('save', function(next) {
        next();
    });

    stripe.post('save', async(doc) => {});

    stripe.pre('find', function(next) {
        next();
    });

    stripe.pre('findOne', function(next) {
        next();
    });
};