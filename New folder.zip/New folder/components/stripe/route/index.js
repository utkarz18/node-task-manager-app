/**
author : Aditi
created_on : 26 June 2019
**/
'use strict';
const api = require('../api');
const specs = require('../specs');

module.exports = [{
    method: 'POST',
    path: '/api/stripe/addBankAccount',
    options: specs.addBankAccount,
    handler: api.addBankAccount
}, {
    method: 'POST',
    path: '/api/stripe/addCard',
    options: specs.addCard,
    handler: api.addCard
}, {
    method: 'POST',
    path: '/api/stripe/setUpRecurring',
    options: specs.setUpRecurring,
    handler: api.setUpRecurring
}];