'use strict';

// const mapper = require('../mapper')
const service = require('../service');
const path = require('path');

/*
 * function : save user primary account for payments
 * params : user account details
 * output : success & failure
 */
exports.addBankAccount = async(request, h) => {
    const log = logger.start('stripe:api:addBankAccount');

    try {
        const res = await service.addBankAccount(request.userInfo, request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function : add user cards in the account
 * params : user card details
 * output : success & failure
 */
exports.addCard = async(request, h) => {
    const log = logger.start('stripe:api:addCard');

    try {
        const res = await service.addCard(request.userInfo, request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

/*
 * function : setup recurring for metals
 * params : recurring details
 * output : success & failure
 */
exports.setUpRecurring = async(request, h) => {
    const log = logger.start('stripe:api:setUpRecurring');

    try {
        const res = await service.setUpRecurring(request.userInfo, request.payload);
        log.end();
        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};