'use strict';
const Joi = require('joi');

module.exports = {
    addBankAccount: {
        payload: {
            country: Joi.string().required().description('Country Short code ex. US'),
            currency: Joi.string().required().description('Curreny shortcode ex. usd'),
            account_holder_name: Joi.string().required().description('Account Holder Name'),
            account_holder_type: Joi.string().required().description('Account type - individual / company'),
            routing_number: Joi.string().required().description('Bank Routing Number'),
            account_number: Joi.string().required().description('Bank Account Number')
        }
    },
    addCard: {
        payload: {
            number: Joi.number().required().description('card Number'),
            exp_month: Joi.number().required().description('card expiry month ex. 12'),
            exp_year: Joi.number().required().description('card expiry year ex. 2020'),
            cvc: Joi.number().required().description('CVC of card ex. 123'),
            card_type: Joi.string().required().valid(['credit_card', 'debit_card']).description('credit card or debit card'),
        }
    },
    setUpRecurring: {
        payload: {
            account_id: Joi.string().required().description('Account id'),
            metal_name: Joi.string().required().valid(['gold', 'silver', 'platinum', 'palladium', 'rhodium']).description('Metal name in which invested '),
            amount: Joi.number().required().description('Amount to be invested in metal'),
            interval: Joi.string().required().valid(['day', 'week', 'bi-week', 'month']).description('Recurring period'),
            currency: Joi.string().required().description('Card curreny')
        }
    },
    accessGranted: Joi.object({
        isSuccess: Joi.boolean(),
        status: Joi.string(),
        statusCode: Joi.number().default(200),
        data: Joi.object({})
    }),
    accessDenied: Joi.object({
        isSuccess: Joi.boolean().default(false),
        status: Joi.string(),
        statusCode: Joi.number().default(400),
        message: Joi.string()
    }),
    failure: Joi.object({
        isSuccess: Joi.boolean().default(false),
        status: Joi.string(),
        statusCode: Joi.number().default(320),
        message: Joi.string()
    }),
    success: Joi.object({
        isSuccess: Joi.boolean(),
        status: Joi.string(),
        statusCode: Joi.number().default(200),
        message: Joi.string()
    }),
    header: Joi.object({
        'x-logintoken': Joi.string().required().trim().description('Provide token to access api')
    }).unknown()
};