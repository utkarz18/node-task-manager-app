'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    addBankAccount: {
        description: 'Save user bank account',
        notes: 'Save user bank account',
        tags: ['api', 'stripe'],
        pre: [{ method: context.validateToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.addBankAccount.payload,
            failAction: response.failAction
        }
    },
    addCard: {
        description: 'Add user bank cards (Debit)',
        notes: 'Add user bank cards (Debit)',
        tags: ['api', 'stripe'],
        pre: [{ method: context.validateToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.addCard.payload,
            failAction: response.failAction
        }
    },
    setUpRecurring: {
        description: 'Setup recurring for metals',
        notes: 'Setup recurring for metals',
        tags: ['api', 'stripe'],
        pre: [{ method: context.validateToken, assign: 'token' }],
        validate: {
            headers: validator.header,
            payload: validator.setUpRecurring.payload,
            failAction: response.failAction
        }
    }
};