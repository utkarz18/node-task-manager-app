/* eslint-disable camelcase */
'use strict';

const fetch = require('node-fetch');
const saltModel = require('../../salt_edge/model');
const saltEdgeKeys = require('config').get('SALTEDGE_KEYS');
const stripe = require('stripe')('sk_test_zblSW9BrYlsHw4BRhqq8MYDa00ww0CGFRO');


/*
 * function : save user primary account for payments
 * params : user account details
 * output : success & failure
 */
exports.addBankAccount = async(userData, params) => {

    // fo live
    /* var accountDetail = {
        country: params.country,
        currency: params.currency,
        account_holder_name: params.currency,
        account_holder_type: params.currency,
        routing_number: params.currency,
        account_number: params.currency
    } */

    // for testing
    var accountDetail = {
        country: 'US',
        currency: 'usd',
        account_holder_name: 'Jenny Rosen',
        account_holder_type: 'individual',
        routing_number: '110000000',
        account_number: '000123456789'
    };

    // create bank details token
    const bankToken = await stripe.tokens.create({
        bank_account: accountDetail
    });
    if (!bankToken) {
        throw new Error('unable to create stripe bank account token');
    }

    // attach bank to customer
    const attachBank = await stripe.customers.createSource(userData.stripeCustomerId, {
        source: bankToken.id
    });
    if (!attachBank) {
        throw new Error('unable to attach bank account to customer');
    }

    // verify user account for ACH
    const verifyAch = await stripe.customers.verifySource(userData.stripeCustomerId, attachBank.id, {
        amounts: [32, 45],
    });
    if (!verifyAch) {
        throw new Error('Unable to verify user account for ACh.Please try again.');
    }

    if (verifyAch.status !== 'verified') {
        throw new Error('User bank account is not verified. Please try again');
    }

    // find primary account 
    const primaryAcc = await db.accounts.findOne({
        userId: userData.id,
        isPrimary: true
    });

    if (primaryAcc) {
        var isPrimary = false;
    } else {
        var isPrimary = true;
    }
    // save user bank id from stripe in database
    var accModel = {
        userId: userData.id,
        bankId: attachBank.id,
        type: 'bank',
        accountName: attachBank.bank_name,
        bankAccountNumber: attachBank.last4,
        isPrimary: isPrimary,
        status: 1,
        createdAt: moment().unix(),
        updatedAt: moment().unix()
    };

    const saveDetails = db.accounts.create(accModel);
    if (!saveDetails) {
        throw new Error('Unable to add account. Please try again');
    }
    return {
        'message': 'Account added successfully.',
        'data': {}
    };
};

/*
 * function : add user cards in the account
 * params : user card details
 * output : success & failure
 */
exports.addCard = async(userData, params) => {

    const cardToken = await stripe.tokens.create({
        card: {
            number: '4000056655665556',
            exp_month: 12,
            exp_year: 2020,
            cvc: '123'
        }
    });

    if (!cardToken) {
        throw new Error('Unable to create card token. Please your card details.');
    }

    const attachCard = await stripe.customers.createSource(userData.stripeCustomerId, {
        source: cardToken.id
    });

    if (!attachCard) {
        throw new Error('Unable to atatch card to user.');
    }

    // find primary account 
    const primaryAcc = await db.accounts.findOne({
        userId: userData.id,
        isPrimary: true
    });
    if (primaryAcc) {
        var isPrimary = false;
    } else {
        var isPrimary = true;
    }
    // save user bank id from stripe in database
    var accModel = {
        userId: userData.id,
        cardId: attachCard.id,
        type: 'card',
        card_type: params.card_type,
        accountName: attachCard.brand,
        bankAccountNumber: attachCard.last4,
        isPrimary: isPrimary,
        status: 1,
        createdAt: moment().unix(),
        updatedAt: moment().unix()
    };

    const saveDetails = db.accounts.create(accModel);
    if (!saveDetails) {
        throw new Error('Unable to add card. Please try again');
    }
    return {
        'message': 'Card added successfully.',
        'data': {}
    };
};

/*
 * function : setup recurring for metals
 * params : recurring details
 * output : success & failure
 */
exports.setUpRecurring = async(userData, params) => {

    const getAcc = await db.accounts.findOne({ _id: params.account_id });
    if (!getAcc) {
        throw new Error('No account found');
    }

    var accId;
    if (getAcc.bankId !== undefined || getAcc.bankId !== '') {
        accId = getAcc.bankId;
    } else {
        accId = getAcc.cardId;
    }

    if (params.amount < 625) {
        var stripeFee = Math.ceil((params.amount * 100) * (0.8 / 100));
    } else {
        var stripeFee = Math.ceil((params.amount * 100) + (5 * 100));
    }
    var conversionFee = 0;
    /* if (params.currency == 'USD' || params.curreny == 'usd') {
         var conversionFee = 0;
     } else {
         var conversionFee = Math.ceil((params.amount * 100) * (1 / 100));
     } */

    if (params.interval === 'bi-week') {
        var interval = 'day';
        var interval_count = 4;
    } else {
        var interval = params.interval;
        var interval_count = 1;
    }
    var totalAmount = (params.amount * 100) + stripeFee + conversionFee;
    // create plan for recurring
    const plan = await stripe.plans.create({
        amount: totalAmount,
        interval: interval,
        interval_count: interval_count,
        product: {
            name: params.metal_name
        },
        currency: params.currency,
    });

    if (!plan) {
        throw new Error('Unable to create plan.');
    }

    // create subscription
    const subscription = await stripe.subscriptions.create({
        customer: userData.stripeCustomerId,
        items: [{
            plan: plan.id,
        }, ],
        default_payment_method: accId
    });

    if (!subscription) {
        throw new Error('Unable to create recurring.Please try again.');
    }

    if (params.metal_name === 'gold') {
        var metal_gold = params.amount;
    } else if (params.metal_name === 'silver') {
        var metal_silver = params.amount;
    } else if (params.metal_name === 'platinum') {
        var metal_platinum = params.amount;
    } else if (params.metal_name === 'palladium') {
        var metal_palladium = params.amount;
    } else if (params.metal_name === 'rhodium') {
        var metal_rhodium = params.amount;
    }

    var paymentModel = {
        user_id: userData.id,
        amountType: 'recurring', // recurring, roundup, one_time, cash_balance, sell, reward
        amountInDollars: (totalAmount / 100),
        amountInCents: totalAmount,
        stripeFeeInCents: stripeFee,
        conversionFee: conversionFee,
        currency: params.curreny,
        type: 'invested', // added, invested, withdrawn
        stripeChargeId: subscription.id,
        recurring_interval: params.interval, // day,month, week, bi-week
        payment_type: 'debit', // credit/debit
        metal_investment: {
            gold: metal_gold,
            silver: metal_silver,
            platinum: metal_platinum,
            palladium: metal_palladium,
            rhodium: metal_rhodium,
        },
        plan_id: plan.id, // plan id of stripe plan
        account_id: params.account_id,
        status: 1,
        created_at: moment().unix()
    };

    const payment = db.payments.create(paymentModel);
    if (!payment) {
        throw new Error('Error in saving payment');
    }

    return {
        'message': 'recurring setup successfully.',
        'data': {}
    };
};