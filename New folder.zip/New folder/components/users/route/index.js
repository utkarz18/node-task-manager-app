/**
author : Aditi
created_on : 12 Nov 2018
**/
'use strict';
const api = require('../api');
const specs = require('../specs');

module.exports = [{
        method: 'POST',
        path: '/api/users/signUp',
        options: specs.signUp,
        handler: api.signUp
    }, {
        method: 'POST',
        path: '/api/users/signUpStep2',
        options: specs.signUpStep2,
        handler: api.signUpStep2
    }, {
        method: 'GET',
        path: '/api/users/splashStatus',
        options: specs.splashStatus,
        handler: api.splashStatus
    }, {
        method: 'POST',
        path: '/api/users/login',
        options: specs.login,
        handler: api.login
    },
    {
        method: 'POST',
        path: '/api/users/loginViaOtp',
        options: specs.loginViaOtp,
        handler: api.loginViaOtp
    },
    {
        method: 'POST',
        path: '/api/users/otp/verify',
        options: specs.verifyOtp,
        handler: api.verifyOtp
    }
    /* {
    method: 'GET',
    path: '/api/users/email/verify',
    options: specs.verifyEmail,
    handler: api.verifyEmail
} */
    , {
        method: 'PUT',
        path: '/api/users/resendOtp',
        options: specs.resendOtp,
        handler: api.resendOtp
    }
    /*, {
        method: 'POST',
        path: '/api/users/checkEmailExists',
        options: specs.checkEmailExists,
        handler: api.checkEmailExists
    } */
    , {
        method: 'POST',
        path: '/api/users/forgotPassword',
        options: specs.forgotPassword,
        handler: api.forgotPassword
    },
    /* {
    method: 'GET',
    path: '/api/users/verifyResetPasswordToken',
    options: specs.verifyResetPasswordToken,
    handler: api.verifyResetPasswordToken
}, */
    {
        method: 'POST',
        path: '/api/users/resetPasswordToken',
        options: specs.resetPasswordToken,
        handler: api.resetPasswordToken
    }, {
        method: 'POST',
        path: '/api/users/setNewPassword',
        options: specs.setNewPassword,
        handler: api.setNewPassword
    },
    /* {
        method: 'POST',
        path: '/api/users/resendEmailVerificationLink',
        options: specs.resendEmailVerificationLink,
        handler: api.resendEmailVerificationLink
    }, */
    {
        method: 'POST',
        path: '/api/users/logout',
        options: specs.logout,
        handler: api.logout
    }, {
        method: 'POST',
        path: '/api/users/changePassword',
        options: specs.changePassword,
        handler: api.changePassword
    }, {
        method: 'GET',
        path: '/api/users/welcomeScreen',
        options: specs.welcomeScreen,
        handler: api.welcomeScreen
    },
    {
        method: 'GET',
        path: '/api/users/viewProfile',
        options: specs.viewProfile,
        handler: api.viewProfile
    },
    {
        method: 'PUT',
        path: '/api/users/updateProfile',
        options: specs.updateProfile,
        handler: api.updateProfile
    },
    {
        method: 'PUT',
        path: '/api/users/settings',
        options: specs.settings,
        handler: api.settings
    },
    {
        method: 'GET',
        path: '/api/users/viewSettings',
        options: specs.viewSettings,
        handler: api.viewSettings
    },
    {
        method: 'PUT',
        path: '/api/users/bankSetupUpdate',
        options: specs.bankSetupUpdate,
        handler: api.bankSetupUpdate
    },
    {
        method: 'GET',
        path: '/api/users/isBankSetup',
        options: specs.isBankSetup,
        handler: api.isBankSetup
    },
    {
        method: 'GET',
        path: '/api/users/getReferCode',
        options: specs.getReferCode,
        handler: api.getReferCode
    },
    {
        method: 'POST',
        path: '/api/users/setRoundUp',
        options: specs.setRoundUp,
        handler: api.setRoundUp
    },
    {
        method: 'GET',
        path: '/api/users/getRoundUp',
        options: specs.getRoundUp,
        handler: api.getRoundUp
    },
    {
        method: 'GET',
        path: '/api/users/isPrimaryAccountSetup',
        options: specs.isPrimaryAccountSetup,
        handler: api.isPrimaryAccountSetup
    }
];