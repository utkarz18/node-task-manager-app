'use strict';
const hooks = require('../hooks');

const user = new mongoose.Schema({
    first_name: { type: String },
    last_name: { type: String },
    email: { type: String },
    password: { type: String }, // save md5 hash
    userRole: { type: String, enum: ['user', 'admin'] },
    gender: { type: String, enum: ['Male', 'Female', 'Other'] },
    profilePic: { type: String },
    isVerified: { type: Number, default: 0 }, // 0 - not verified , // 1 - own verify, 2- verify by admin
    isActive: { type: Boolean, default: true },
    isProfileUpdated: { type: Boolean, default: false },
    isDeleted: { type: Boolean, default: false },
    isDeactivated: { type: Boolean, default: false },
    isBankAccountAdded: { type: Boolean, default: false }, // used or not??
    isCardAdded: { type: Boolean, default: false }, // used or not??
    phone: { type: String },
    countryCode: { type: String },
    country: { type: mongoose.Schema.Types.ObjectId, ref: 'Country' },
    dob: { type: String },
    city: { type: String },
    state: { type: String },
    address: { type: String },
    pinCode: { type: String },
    isRecurringEnabled: { type: Boolean, default: false },
    isRoundUpEnabled: { type: Boolean, default: false },
    isLockMultiplier: { type: Boolean, default: false },
    referralCode: { type: String },
    referralPoints: { type: Number },
    deviceToken: { type: String },
    deviceType: { type: String }, // android or ios
    userRegisterationTime: { type: Number },
    profileCompletionTime: { type: Number },
    lastProfileUpdatedTime: { type: Number },
    accountVerificationTime: { type: Number },
    loginTime: { type: Number }, // user login time in app
    logoutTime: { type: Number }, // user logout time in app
    adminVerifyId: { type: Number }, // id of admin who verified user account
    emailVerifyToken: { type: String },
    mobileVerifyToken: { type: String },
    resetPasswordToken: { type: Number },
    isSplashView: { type: Boolean, default: false },
    isPushNotification: { type: Boolean, default: true },
    isTwoStepVerification: { type: Boolean, default: true },
    otpCode: { type: Number },
    isFirstLogin: { type: Boolean, default: false }, // is user first time login or not 
    isBiometric: { type: Boolean, default: false },
    isEmailNotification: { type: Boolean, default: true },
    isAppNotification: { type: Boolean, default: true },
    accessToken: [String],
    player_id: { type: String, default: '' },
    stripeCustomerId: { type: String, default: '' },
    loginName: { type: String, default: '' }, // from saltedge customer id
    customerSecret: { type: String, default: '' }, // from saltedge customer secret key
    connectionId: { type: String, default: '' }, // bank account id linked on salt edge
    roundup: {
        gold: { type: Number, default: 0 },
        silver: { type: Number, default: 0 },
        platinum: { type: Number, default: 0 },
        palladium: { type: Number, default: 0 },
        rhodium: { type: Number, default: 0 }
    }
}, {
    versionKey: false
});


hooks.configure(user);
module.exports = user;