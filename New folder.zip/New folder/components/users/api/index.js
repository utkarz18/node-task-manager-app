'use strict';

const mapper = require('../mapper');
const service = require('../service');
const path = require('path');

exports.signUp = async(request, h) => {
    try {
        const res = await service.signUp(request.payload);
        return response.success(h, res.message, res.data);
    } catch (err) {
        return response.failure(h, err.message);
    }
};

exports.signUpStep2 = async(request, h) => {
    const log = logger.start('users:api:signUpStep2');
    try {
        const res = await service.signUpStep2(request.payload);
        return response.success(h, res.message, res.data);
    } catch (err) {
        return response.failure(h, err.message);
    }
};

exports.login = async(request, h) => {
    const log = logger.start('users:api:login');

    try {
        const res = await service.login(request.payload);
        log.end();

        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.loginViaOtp = async(request, h) => {
    const log = logger.start('users:api:loginViaOtp');
    try {
        const res = await service.loginViaOtp(request.payload);
        log.end();

        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.verifyOtp = async(request, h) => {
    const log = logger.start('users:api:verifyOtp');
    try {
        const res = await service.verifyOtp(request.payload);
        log.end();

        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.resendOtp = async(request, h) => {
    const log = logger.start('users:api:resendOtp');
    try {
        const res = await service.resendOtp(request.payload);
        log.end();

        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, mapper.toModel(res.data));
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.splashStatus = async(request, h) => {
    const log = logger.start('users:api:splashStatus');
    try {
        const res = await service.splashStatus(request.query);
        log.end();

        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};

exports.verifyEmail = async(request, h) => {
    const log = logger.start('users:api:verifyEmail');

    try {
        await service.verifyEmail(request.query.token);
        log.end();
        return h.file(path.join(__dirname, '../../../templates/user-register-success.html'));
    } catch (err) {
        log.error(err);
        log.end();
        return h.file(path.join(__dirname, '../../../templates/user-register-failure.html'));
    }
};

exports.checkEmailExists = async(request, h) => {
    const log = logger.start('users:api:checkEmailExists');
    try {
        const res = await service.checkEmailExists(request.payload);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.forgotPassword = async(request, h) => {
    const log = logger.start('users:api:forgotPassword');

    try {
        const res = await service.forgotPassword(request.payload);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.resendEmailVerificationLink = async(request, h) => {
    const log = logger.start('users:api:resendEmailVerificationLink');

    try {
        const res = await service.resendEmailVerificationLink(request.payload.email);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.resetPasswordToken = async(request, h) => {
    const log = logger.start('users:api:resetPasswordToken');

    try {
        const res = await service.resetPasswordToken(request.payload);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.verifyResetPasswordToken = async(request, h) => {
    const log = logger.start('users:api:verifyResetPasswordToken');

    try {
        await service.verifyResetPasswordToken(request.query.token);
        log.end();
        return h.file(path.join(__dirname, '../../../templates/user-update-password.html'));
    } catch (err) {
        log.error(err);
        log.end();
        return h.file(path.join(__dirname, '../../../templates/user-verify-password-failure.html'));
    }
};

exports.logout = async(request, h) => {
    const log = logger.start('users:api:logout');

    try {
        const res = await service.logout(request.headers);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.changePassword = async(request, h) => {
    const log = logger.start('user:api:changePassword');
    try {
        request.payload.userId = request.userInfo._id;
        const res = await service.changePassword(request.payload);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.setNewPassword = async(request, h) => {
    const log = logger.start('user:api:setNewPassword');
    try {
        const res = await service.setNewPassword(request.payload);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};


exports.welcomeScreen = async(request, h) => {
    const log = logger.start('user:api:welcomeScreen');
    try {
        const res = await service.welcomeScreen(request.userInfo, request.query);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.viewProfile = async(request, h) => {
    const log = logger.start('user:api:viewProfile');
    try {
        const res = await service.viewProfile(request.userInfo, request.query);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.updateProfile = async(request, h) => {
    const log = logger.start('user:api:updateProfile');
    try {
        const res = await service.updateProfile(request.userInfo, request.payload);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.settings = async(request, h) => {
    const log = logger.start('user:api:settings');
    try {
        const res = await service.settings(request.userInfo.id, request.payload);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.viewSettings = async(request, h) => {
    const log = logger.start('user:api:viewSettings');
    try {
        const res = await service.viewSettings(request.userInfo.id);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.isBankSetup = async(request, h) => {
    const log = logger.start('user:api:isBankSetup');
    try {
        const res = await service.isBankSetup(request.userInfo);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.bankSetupUpdate = async(request, h) => {
    const log = logger.start('user:api:bankSetupUpdate');
    try {
        const res = await service.bankSetupUpdate(request.userInfo.id, request.payload);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.getReferCode = async(request, h) => {
    const log = logger.start('user:api:getReferCode');
    try {
        const res = await service.getReferCode(request.userInfo.id);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.setRoundUp = async(request, h) => {
    const log = logger.start('user:api:setRoundUp');
    try {
        const res = await service.setRoundUp(request.userInfo.id, request.payload);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.getRoundUp = async(request, h) => {
    const log = logger.start('user:api:getRoundUp');
    try {
        const res = await service.getRoundUp(request.userInfo.id);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

/*
 * function : to check is primary account setup by user or not
 * params : userId
 * output : success or error
 */
exports.isPrimaryAccountSetup = async(request, h) => {
    const log = logger.start('user:api:isPrimaryAccountSetup');
    try {
        const res = await service.isPrimaryAccountSetup(request.userInfo.id);
        log.end();
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};