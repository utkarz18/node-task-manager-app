'use strict';
const Joi = require('joi');

module.exports = {
    signUp: {
        payload: {
            email: Joi.string().email().required().description('Valid email Id'),
            password: Joi.string().label('Password').required().description('Password')
        }
    },
    signUpStep2: {
        payload: {
            user_id: Joi.string().required().description('User Id'),
            first_name: Joi.string().required().trim().description('First Name'),
            last_name: Joi.string().required().trim().description('Last Name'),
            dob: Joi.string().required().description('Date of birth'),
            gender: Joi.string().required().valid(['Male', 'Female', 'Other']).description('Gender'),
            phone: Joi.string().required().description('Mobile Number'),
            country: Joi.string().required().description('Country Id'),
            referralCode: Joi.string().valid('').description('Referral Code'),
            player_id: Joi.string().valid('').description('One signal player id'),
        }
    },
    login: {
        payload: {
            phoneOrEmail: Joi.string().description('Enter registered mobile no or email'),
            password: Joi.string().required(),
            deviceType: Joi.string().required().valid(['ios', 'android']).description('Device type android / ios'),
            deviceToken: Joi.string().required().description('Device Id')
        }
    },
    loginViaOtp: {
        payload: {
            phoneOrEmail: Joi.string().description('Enter registered mobile no or email'),
            otp: Joi.number().description('Enter OTP'),
            deviceType: Joi.string().required().valid(['ios', 'android']).description('Device type android / ios'),
            deviceToken: Joi.string().required().description('Device Id')
        }
    },
    verifyEmail: {
        query: {
            token: Joi.string().required()
        }
    },
    verifyOtp: {
        payload: {
            phoneOrEmail: Joi.string().description('Enter registered mobile no or email'),
            otp: Joi.number().required().description('OTP'),
            deviceType: Joi.string().required().valid(['ios', 'android']).description('Device type android / ios'),
            deviceToken: Joi.string().required().description('Device Id')
        }
    },
    resendOtp: {
        payload: {
            phoneOrEmail: Joi.string().description('Enter registered mobile no or email'),
            type: Joi.string().required().valid(['register', 'login', 'forgot']).description('Resend otp type'),
            // user_id: Joi.string().required().description('User Id'),
            // phone: Joi.string().required().description('Mobile Number'),
        }
    },
    splashStatus: {
        query: {
            phone: Joi.string().required()
        }
    },
    checkEmailExists: {
        payload: {
            email: Joi.string().email().required().trim().description('Email'),
        }
    },
    viewSettings: {
        query: {}
    },
    resendEmailVerificationLink: {
        payload: {
            email: Joi.string().email().required().trim().description('Email')
        }
    },
    setNewPassword: {
        payload: {
            phoneOrEmail: Joi.string().description('Enter registered mobile no or email'),
            resetPasswordToken: Joi.number().required(),
            password: Joi.string().label('Password').required().description('Password')
        }
    },
    forgot: {
        payload: {
            phoneOrEmail: Joi.string().description('Enter registered mobile no or email'),
        }
    },
    changePassword: {
        payload: {
            oldPassword: Joi.string().required(),
            newPassword: Joi.string().label('Password').required().description('Password')
        }
    },
    resetPasswordToken: {
        payload: {
            phoneOrEmail: Joi.string().description('Enter registered mobile no or email'),
            token: Joi.number().required()
        }
    },
    welcomeScreen: {
        query: {}
    },
    viewProfile: {
        query: {}
    },
    updateProfile: {
        payload: {
            first_name: Joi.string().required().trim().description('First Name'),
            last_name: Joi.string().required().trim().description('Last Name'),
            profilePic: Joi.string().required().description('Profile image'),
            dob: Joi.string().required().description('Date of birth'),
            gender: Joi.string().required().valid(['Male', 'Female', 'Other']).description('Gender'),
            country: Joi.string().required().description('Country Id'),
            isTwoStepVerification: Joi.boolean().required().description('Two step verification'),
            address: Joi.string().required().trim().description('Address'),
            city: Joi.string().required().trim().description('City'),
            state: Joi.string().required().trim().description('State'),
            pinCode: Joi.string().required().trim().description('Pincode'),
        }
    },
    settings: {
        payload: {
            isBiometric: Joi.boolean().required(),
            isEmailNotification: Joi.boolean().required(),
            isAppNotification: Joi.boolean().required()
        }
    },
    isBankSetup: {
        query: {}
    },
    bankSetupUpdate: {
        payload: {
            bankSetup: Joi.boolean().required().default('true')
        }
    },
    getReferCode: {
        query: {}
    },
    setRoundUp: {
        payload: {
            isRoundUpEnabled: Joi.boolean().required(),
            isLockMultiplier: Joi.boolean().required(),
            gold: Joi.number().when('isRoundUpEnabled', { is: true, then: Joi.required(), otherwise: Joi.optional() }),
            silver: Joi.number().when('isRoundUpEnabled', { is: true, then: Joi.required(), otherwise: Joi.optional() }),
            platinum: Joi.number().when('isRoundUpEnabled', { is: true, then: Joi.required(), otherwise: Joi.optional() }),
            palladium: Joi.number().when('isRoundUpEnabled', { is: true, then: Joi.required(), otherwise: Joi.optional() }),
            rhodium: Joi.number().when('isRoundUpEnabled', { is: true, then: Joi.required(), otherwise: Joi.optional() })
        }
    },
    getRoundUp: {
        query: {}
    },
    isPrimaryAccountSetup: {
        query: {}
    },
    accessGranted: Joi.object({
        isSuccess: Joi.boolean(),
        status: Joi.string(),
        statusCode: Joi.number().default(200),
        data: Joi.object({})
    }),
    accessDenied: Joi.object({
        isSuccess: Joi.boolean().default(false),
        status: Joi.string(),
        statusCode: Joi.number().default(400),
        message: Joi.string()
    }),
    failure: Joi.object({
        isSuccess: Joi.boolean().default(false),
        status: Joi.string(),
        statusCode: Joi.number().default(320),
        message: Joi.string()
    }),
    success: Joi.object({
        isSuccess: Joi.boolean(),
        status: Joi.string(),
        statusCode: Joi.number().default(200),
        message: Joi.string()
    }),
    header: Joi.object({
        'x-logintoken': Joi.string().required().trim().description('Provide token to access api')
    }).unknown()
};