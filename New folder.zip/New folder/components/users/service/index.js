/* eslint-disable no-cond-assign */
/* eslint-disable no-constant-condition */
/* eslint-disable require-atomic-updates */
/* eslint-disable no-array-constructor */
/* eslint-disable standard/object-curly-even-spacing */
'use strict';

const md5 = require('md5');
const twilio = require('twilio');
const twilioCredentials = require('config').get('TWILIO_CREDENTIALS');
const auth = require('../../../utils/auth');
const yodlee = require('../../../utils/yodlee');
const yodleeBaseUrl = require('config').get('yodleeBaseURL');
const yodleeModel = require('../../yodlee_users/model');
const inviteModel = require('../../invites/model');
var request = require('request');
const config = require('config');
const welcomeMsg = require('config').get('WelcomeMsg');
const saltEdgeKeys = require('config').get('SALTEDGE_KEYS');
const fetch = require('node-fetch');
const stripe = require('stripe')('sk_test_zblSW9BrYlsHw4BRhqq8MYDa00ww0CGFRO');
const saltModel = require('../../salt_edge/model');
const message = require('../../../utils/messages');


/*
 * functon to get the user details by email
 * params : email
 * output : user object
 */
const getUserByEmail = async(emailId) => {
    const log = logger.start(`users:services:getUserByEmail:${emailId}`);

    const user = await db.users.findOne({
        email: emailId,
        isDeleted: false
    });
    log.end();

    return user;
};

/*
 * functon to get the user details by phone number
 * params : phone number
 * output : user object
 */
const getUserByPhone = async(phoneNo) => {
    const log = logger.start(`users:services:getUserByPhone:${phoneNo}`);

    const user = await db.users.findOne({
        phone: phoneNo,
        isDeleted: false
    });
    log.end();

    return user;
};

/*
 * functon to get the user details by OTP
 * params : OTP
 * output : user object
 */
const getUserOtp = async(otp) => {
    const log = logger.start(`users:services:getUserOtp:${otp}`);

    const user = await db.users.findOne({
        otpCode: otp,
        isDeleted: false
    });
    log.end();

    return user;
};

/*
 * functon to signup user or new registration
 * params : email & password
 * output : user id
 */
exports.signUp = async(params) => {
    const log = logger.start('users:service:signUp');

    const oldUser = await getUserByEmail(params.email);

    if (oldUser) {
        log.end();
        throw new Error(message.user_exist);
    }

    const userModel = {
        userRole: 'user',
        email: params.email,
        password: md5(params.password),
        userRegisterationTime: moment().unix(),
        isSplashView: true
    };

    const user = await new db.users(userModel);
    var x = await user.save();
    /* offline.queue('user', 'sign-up', {
        id: user.id
    }, {}) */

    log.end();

    return {
        message: message.registration_step1,
        data: {
            user_id: user._id
        }
    };
};

/*
 * functon to signup user step 2 with more details of user
 * referral code functionality to save invities
 * params : first name, last name , dob etc
 * output : user object
 */
exports.signUpStep2 = async(params) => {
    const log = logger.start('users:service:signUpStep2');


    /* const oldUserByPhone = await getUserByPhone(params.phone)

    if (oldUserByPhone) {
        log.end()
        throw new Error('User already registered with this number.')
    } */

    if (params.referralCode !== '') {
        const validateRefferalCode = await db.users.findOne({ 'referralCode': params.referralCode });
        if (!validateRefferalCode) throw new Error(message.invalid_code);

        var inviteData = {
            invited_by: validateRefferalCode.id,
            invited_to: params.user_id,
            status: 1,
            created_at: moment().unix()
        };

        const saveInvite = await new db.invites(inviteData);
        var x = await saveInvite.save();
    }
    var otp = auth.randomOtp(4);

    /* var client = new twilio(twilioCredentials.SID, twilioCredentials.Token);

     const messageSent = await client.messages.create({
         body: otp,
         to: params.phone, // Text this number
         from: twilioCredentials.twilio_number // From a valid Twilio number
     }, function(error, message) {
         if (!error) {
             console.log('Success! The SID for this SMS message is:');
             console.log(message.sid);
         } else {
             throw new Error(error.code + ' - ' + error.message)
         }
     }); */

    const userDatas = await db.users.findOneAndUpdate({
        _id: params.user_id,
    }, {
        first_name: params.first_name,
        last_name: params.last_name,
        dob: params.dob,
        gender: params.gender,
        phone: params.phone,
        country: params.country,
        otpCode: 1234, // otp,
        referralCode: auth.referralCode(6),
        player_id: params.player_id
    }, { new: true, lean: true });
    log.end();

    return {
        message: message.registration_success,
        data: {
            'otp': 1234, // otp,
            'user_id': params.user_id
        }
    };

};

/*
 * functon to login user using email / phone number & password
 * params : email/phone number & password, deviceToken, deviceType
 * output : user object
 */
exports.login = async(params) => {
    const log = logger.start('users:service:login');

    const user = await db.users.findOne({
        $or: [{
                phone: params.phoneOrEmail
            },
            {
                email: params.phoneOrEmail
            }
        ]
    });

    if ((!user) || (user && user.isDeleted)) {
        throw new Error(message.invalid_credentials);
    }

    if (user && user.isVerified === 0) {
        throw new Error(`Your phone number ${user.phone} has not been verified. Please verify your account.`);
    }


    var isValid = await db.users.findOne({
        $and: [{
                $or: [{
                        phone: params.phoneOrEmail
                    },
                    {
                        email: params.phoneOrEmail
                    }
                ]
            },
            {
                password: md5(params.password)
            },
            {
                isDeleted: false
            }
        ]
    });

    if (!isValid || isValid == null)
        throw new Error(message.invalid_credentials);

    if (isValid.isTwoStepVerification === true) {
        var otp = '1234'; // auth.randomOtp(4);
        /* var client = new twilio(twilioCredentials.SID, twilioCredentials.Token);

        const messageSent = await client.messages.create({
            body: otp,
            to: isValid.phone, // Text this number
            from: twilioCredentials.twilio_number // From a valid Twilio number
        }, function(error, message) {
            if (!error) {
                console.log('Success! The SID for this SMS message is:');
                console.log(message.sid);
            } else {
                throw new Error(error.code + ' - ' + error.message)
            }
        }); */

        isValid.otpCode = 1234; // otp
        var x = await isValid.save();
        log.end();
        return {
            message: message.otp_sent,
            data: { 'otp': otp }
        };
    } else {
        if (isValid && isValid.isFirstLogin === false) {
            const yodleeUser = await createSaltEdgeStripeAccounts(isValid);
        }


        var accessToken = auth.createToken(isValid._id);

        const userDatas = await db.users.findOneAndUpdate({
            _id: isValid._id,
        }, {
            loginTime: moment().unix(),
            deviceToken: params.deviceToken,
            deviceType: params.deviceType,
            isFirstLogin: true,
            $push: {
                accessToken: accessToken
            }
        }, { new: true, lean: true });
        log.end();

        return {
            message: message.login_success,
            data: {
                'userDatas': userDatas,
                'accessToken': accessToken
            }
        };

    }


};

/*
 * functon to login user using email / phone number & password
 * params : email/phone number & password, deviceToken, deviceType,otp
 * output : user object
 */
exports.loginViaOtp = async(params) => {

    const log = logger.start('users:service:login');

    const user = await db.users.findOne({
        $and: [{
                $or: [{
                        phone: params.phoneOrEmail
                    },
                    {
                        email: params.phoneOrEmail
                    }
                ]
            },
            {
                otpCode: params.otp
            }
        ]
    });

    if (!user) {
        throw new Error(message.invalid_otp);
    }

    if (user && user.isFirstLogin === false) {
        const yodleeUser = await createSaltEdgeStripeAccounts(user);
    }


    var accessToken = auth.createToken(user._id);

    const userDatas = await db.users.findOneAndUpdate({
        otpCode: params.otp,
    }, {
        loginTime: moment().unix(),
        deviceToken: params.deviceToken,
        deviceType: params.deviceType,
        isFirstLogin: true,
        $push: {
            accessToken: accessToken
        },
        $unset: {
            otpCode: 1
        }
    }, { new: true, lean: true });
    log.end();

    return {
        message: message.login_success,
        data: {
            'userDatas': userDatas,
            'accessToken': accessToken
        }
    };

};

/*
 * functon to create customer at saltedge & Stripe
 * params : userData
 * output : success
 */
const createSaltEdgeStripeAccounts = async(userData) => {
    const log = logger.start('users:services:createSaltEdgeStripeAccounts');
    var reqBody = {
        'data': {
            'identifier': userData.email.substring(0, userData.email.indexOf('@')) + moment().unix(),
        }
    };
    const url = saltEdgeKeys.base_url + 'customers';
    const res = await fetch(url, {
        method: 'post',
        body: JSON.stringify(reqBody),
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'App-id': saltEdgeKeys.app_id,
            'Secret': saltEdgeKeys.secret
        },
    });

    const datas = await res.json();

    if (datas.errorCode) {
        return datas;
    }
    await db.users.findOneAndUpdate({ _id: userData.id }, {
        loginName: datas.data.id,
        customerSecret: datas.data.secret
    }, { new: true, lean: true });

    const stripeAcc = await stripe.customers.create({
        email: userData.email,
        description: userData.id
    });

    if (!stripeAcc) {
        throw new Error('unable to create stripe account');
    }
    await db.users.findOneAndUpdate({ _id: userData.id }, {
        stripeCustomerId: stripeAcc.id
    }, { new: true, lean: true });

    return true;
};

/*
 * functon to verify user account via otp
 * params : otp, phone/email, deviceToken, deviceType
 * output : success with user object
 */
exports.verifyOtp = async(params) => {
    const log = logger.start('users:service:login');

    const user = await db.users.findOne({
        $and: [{
                $or: [{
                        phone: params.phoneOrEmail
                    },
                    {
                        email: params.phoneOrEmail
                    }
                ]
            },
            {
                otpCode: params.otp
            }
        ]
    });

    if (!user) {
        throw new Error('Invalid OTP');
    }

    if (user && user.isFirstLogin === false) {
        const yodleeUser = await createSaltEdgeStripeAccounts(user);
    }

    var accessToken = auth.createToken(user._id);

    const userData = await db.users.findOneAndUpdate({
        _id: user.id,
        otpCode: params.otp,
        isDeleted: false
    }, {
        accountVerificationTime: moment().unix(),
        isVerified: 1,
        loginTime: moment().unix(),
        deviceToken: params.deviceToken,
        deviceType: params.deviceType,
        isFirstLogin: true,
        $push: {
            accessToken: accessToken
        },
        $unset: {
            otpCode: 1
        }
    }, { new: true, lean: true });


    log.end();

    return {
        message: message.login_success,
        data: {
            'userData': userData,
            'accessToken': accessToken
        }
    };
};

/*
 * functon to re-send otp
 * params :  phone/email
 * output : success 
 */
exports.resendOtp = async(params) => {
    const log = logger.start('users:service:resendOtp');


    const user = await db.users.findOne({
        $and: [{
            $or: [{
                    phone: params.phoneOrEmail
                },
                {
                    email: params.phoneOrEmail
                }
            ],
            isDeleted: false
        }]
    });

    if (!user)
        throw new Error(message.email_noexist);

    var otp = auth.randomOtp(4);

    /* var client = new twilio(twilioCredentials.SID, twilioCredentials.Token);
    
            const messageSent = await client.messages.create({
                body: otp,
                to: user.phone, // Text this number
                from: twilioCredentials.twilio_number // From a valid Twilio number
            }, function(error, message) {
                if (!error) {
                    console.log('Success! The SID for this SMS message is:');
                    console.log(message.sid);
                } else {
                    throw new Error(error.code + ' - ' + error.message)
                }
            });
            */

    if (params.type === 'register') {
        user.otpCode = 1234; // otp
        var x = await user.save();
        /* offline.queue('user', 'sign-up', {
            id: user.id
        }, {}) */

        log.end();

        return {
            message: message.otp_sent_msg,
            data: {
                'otp': 1234
                    /* otp */
            }
        };
    }

    if (params.type === 'login') {
        user.otpCode = 1234; // otp
        var x = await user.save();
        /* offline.queue('user', 'sign-up', {
            id: user.id
        }, {}) */

        log.end();

        return {
            message: message.otp_sent_msg,
            data: { 'otp': 1234 /* otp */ }
        };
    }


    if (params.type = 'forgot') {

        user.resetPasswordToken = 1234; // otp

        await user.save();

        offline.queue('user', 'forgot-password', {
            id: user.id
        }, {});

        log.end();

        return {
            message: message.forgot_email_inbox,
            data: { 'otp': 1234 /* otp */ }
        };
    }
};

/*
 * functon to check is user seen all splash screen or not
 * params :  phone
 * output : success 
 */
exports.splashStatus = async(params) => {
    const log = logger.start('users:service:splashStatus');

    const user = await db.users.findOne({
        phone: params.phone,
    });

    if (!user) {
        throw new Error('No records found.');
    }

    return {
        message: message.splash,
        data: {
            'isSplashView': user.isSplashView
        }
    };

};

/*
 * functon to verify user email
 * params :  verify token
 * output : success 
 */
exports.verifyEmail = async(token) => {
    const log = logger.start('users:service:verifyEmail');

    const user = await db.users.findOne({
        emailVerifyToken: token,
        isDeleted: false
    });

    if (!user) {
        throw new Error(message.link_expire);
    }

    const userData = await db.users.findOneAndUpdate({
        emailVerifyToken: token,
        isDeleted: false
    }, {
        accountVerificationTime: moment().unix(),
        isVerified: true,
        $unset: {
            emailVerifyToken: 1
        }
    });

};

/*
 * functon to check is email exist in our system or not
 * params :  email
 * output : success 
 */
exports.checkEmailExists = async(params) => {

    const user = await db.users.findOne({
        email: params.email,
        isDeleted: false
    });

    if (!user) throw new Error(message.email_noexist);

    if (user && !user.isEmailVerified) throw new Error(message.email_notverify);

    return message.email_exist;

};

/*
 * functon to forgot password
 * params :  phone/email
 * output : success 
 */
exports.forgotPassword = async(params) => {
    const log = logger.start('users:service:forgotPassword');

    // const user = await getUserByEmail(params.email)

    const user = await db.users.findOne({
        $and: [{
            $or: [{
                    phone: params.phoneOrEmail
                },
                {
                    email: params.phoneOrEmail
                }
            ]
        }]
    });

    if (!user)
        throw new Error(message.email_noexist);

    var otp = auth.randomOtp(4);

    /* var client = new twilio(twilioCredentials.SID, twilioCredentials.Token);
    
        const messageSent = await client.messages.create({
            body: otp,
            to: user.phone, // Text this number
            from: twilioCredentials.twilio_number // From a valid Twilio number
        }, function(error, message) {
            if (!error) {
                console.log('Success! The SID for this SMS message is:');
                console.log(message.sid);
            } else {
                throw new Error(error.code + ' - ' + error.message)
            }
        });
        */
    user.resetPasswordToken = 1234; // otp
    // user.resetPasswordToken = auth.randomToken(user.id)
    await user.save();

    offline.queue('user', 'forgot-password', {
        id: user.id
    }, {});

    log.end();

    return {
        'message': message.resetpassword_email,
        'data': {}
    };
};

/*
 * functon to verify reset password token
 * params :  phone/email & token
 * output : success 
 */
exports.resetPasswordToken = async(params) => {
    const log = logger.start('users:service:resetPasswordToken');

    const user = await db.users.findOne({
        $and: [{
            $or: [{
                    phone: params.phoneOrEmail
                },
                {
                    email: params.phoneOrEmail
                }
            ],
            resetPasswordToken: params.token
        }]
    });


    if (!user) {
        throw new Error(message.token_expire);
    }
    log.end();
    return {
        'message': message.valid_token,
        'data': {}
    };
};

/*
 * functon to verify reset password token
 * params :  phone/email & token
 * output : success 
 */
exports.verifyResetPasswordToken = async(token) => {

    const log = logger.start('users:service:verifyResetPasswordToken');

    const user = await db.users.findOne({
        resetPasswordToken: token
    });

    if (!user) throw new Error(message.link_expire);
    log.end();
    return message.valid_link;
};

/*
 * functon to logout user form application
 * params :  x-logintoken
 * output : success 
 */
exports.logout = async(params) => {
    const log = logger.start('users:service:logout');

    await db.users.update({
        'accessToken': {
            '$in': [params['x-logintoken']]
        }
    }, {
        $pull: {
            'accessToken': params['x-logintoken']
        }
    });

    log.end();

    return {
        'message': message.logout,
        'data': {}
    };
};

exports.resendEmailVerificationLink = async(email) => {
    const log = logger.start('users:service:resendEmailVerificationLink');

    const user = await getUserByEmail(email);

    if (!user) throw new Error(message.email_noexist);
    if (user.isEmailVerified) throw new Error(`Email ${user.email} is already verified , Please login !`);

    user.emailVerifyToken = auth.randomToken(user.id);
    var x = await user.save();
    offline.queue('user', 'sign-up', {
        id: user.id
    }, {});

    log.end();

    return `A link to verify the email has been sent to ${user.email}. Please check your inbox, then follow the instructions.`;
};

/*
 * functon to change user password
 * params :  oldpassowrd & newpassword
 * output : success or failure
 */
exports.changePassword = async(params) => {
    const log = logger.start('user:service:changePassword');

    var user = await db.users.findOneAndUpdate({
        _id: params.userId,
        password: md5(params.oldPassword)
    }, {
        password: md5(params.newPassword)
    });

    if (!user) throw new Error(message.invalid_oldpass);

    return {
        message: message.password_change,
        data: {}
    };
};

/*
 * functon to set new password from frogot password
 * params :  phone/email & token, new password
 * output : success 
 */
exports.setNewPassword = async(params) => {
    const log = logger.start('user:service:setNewPassword');

    const user = await db.users.findOne({
        $and: [{
            $or: [{
                    phone: params.phoneOrEmail
                },
                {
                    email: params.phoneOrEmail
                }
            ],
            resetPasswordToken: params.resetPasswordToken
        }]
    });

    /* const user = await db.users.findOne({
         resetPasswordToken: params.resetPasswordToken
     }) */
    if (!user) throw new Error(message.token_expire);

    await db.users.findOneAndUpdate({
        _id: user._id
    }, {
        password: md5(params.password),
        $unset: {
            resetPasswordToken: 1
        }
    });
    log.end();
    return {
        'message': message.password_update,
        'data': {}
    };
};

/*
 * functon to send static welcome screen messages
 * params :  
 * output : success with message array
 */
exports.welcomeScreen = async(userData, params) => {
    const log = logger.start('user:service:welcomeScreen');

    const user = await db.users.findOne({
        _id: userData.id
    });
    if (!user) throw new Error(message.no_user);
    var username = (user && user.first_name !== undefined) ? user.first_name : 'User';
    const array = new Array();
    var msg1 = welcomeMsg.Text_One + ' ' + username;
    var msg2 = welcomeMsg.Text_Two;

    array.push(msg1);
    array.push(msg2);

    log.end();
    return {
        'message': message.welcome_msg,
        data: {
            data: array
        }
    };
};


/*
 * functon to view user profile
 * params :  
 * output : success with user object
 */
exports.viewProfile = async(userData, params) => {
    const log = logger.start('user:service:viewProfile');

    let criteria = { _id: mongoose.Types.ObjectId(userData.id) };

    const user = await db.users.aggregate([
        { $match: criteria },
        {
            $lookup: {
                from: 'countries',
                localField: 'country',
                foreignField: '_id',
                as: 'usercountries'
            }
        },
        {
            $project: {
                'usercountries._id': 1,
                'usercountries.name': 1,
                first_name: 1,
                last_name: 1,
                profilePic: 1,
                dob: 1,
                isTwoStepVerification: 1,
                userRegisterationTime: 1,
                accountVerificationTime: 1,
                gender: 1,
                phone: 1,
                address: 1,
                city: 1,
                state: 1,
                pinCode: 1,
                email: 1,
            }
        }
    ]);

    const userDataModel = {
        _id: user[0]._id,
        first_name: (user && user[0].first_name !== undefined) ? user[0].first_name : '',
        last_name: (user && user[0].last_name !== undefined) ? user[0].last_name : '',
        profilePic: (user && user[0].profilePic !== undefined) ? user[0].profilePic : '',
        dob: (user && user[0].dob !== undefined) ? user[0].dob : '',
        address: (user && user[0].address !== undefined) ? user[0].address : '',
        city: (user && user[0].city !== undefined) ? user[0].city : '',
        state: (user && user[0].state !== undefined) ? user[0].state : '',
        pinCode: (user && user[0].pinCode !== undefined) ? user[0].pinCode : '',
        isTwoStepVerification: user[0].isTwoStepVerification,
        gender: user[0].gender,
        phone: user[0].phone,
        email: user[0].email,
        country: user[0].usercountries[0]
    };

    if (!user) throw new Error(message.no_record);
    log.end();
    return { message: message.user_profile, data: { user: userDataModel } };
};

/*
 * functon to update user profile
 * params :  all required fields
 * output : success 
 */
exports.updateProfile = async(userData, params) => {
    const log = logger.start('users:service:updateProfile');

    var user = await db.users.findOneAndUpdate({ _id: userData.id }, {
        first_name: params.first_name,
        last_name: params.last_name,
        profilePic: params.profilePic,
        dob: params.dob,
        gender: params.gender,
        country: params.country,
        isTwoStepVerification: params.isTwoStepVerification,
        address: params.address,
        city: params.city,
        state: params.state,
        pinCode: params.pinCode,
        lastProfileUpdatedTime: moment().unix()
    }, { new: true });

    if (!user) throw new Error(message.error_profile);
    log.end();
    return { message: message.profile_success, data: { user: user } };
};

/*
 * functon to update user security & notifications settings
 * params :  isBiometric,isEmailNotification,isAppNotification
 * output : success 
 */
exports.settings = async(userId, params) => {
    const log = logger.start('users:service:settings');

    var options = {
        isBiometric: params.isBiometric,
        isEmailNotification: params.isEmailNotification,
        isAppNotification: params.isAppNotification
    };

    const user = await db.users.findOneAndUpdate({ _id: userId }, options);


    if (!user) throw new Error(message.error_setting);

    const updatedUser = await db.users.findOne({ _id: userId });
    log.end();
    return {
        message: message.settings_success,
        data: {
            'userDatas': updatedUser
        }
    };
};

/*
 * functon to fetch is user bank setup or not
 * params :  
 * output : success 
 */
exports.isBankSetup = async(userData) => {
    const log = logger.start('user:service:isBankSetup');

    // get connections of the user (i.e bank accounts of the user)
    const url = saltEdgeKeys.base_url + 'connections?customer_id=' + userData.loginName;
    const res = await fetch(url, {
        method: 'get',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'App-id': saltEdgeKeys.app_id,
            'Secret': saltEdgeKeys.secret,
            'Customer-Secret': userData.customerSecret
        },
    });

    const datas = await res.json();

    if (datas.data.length === 0) {
        throw new Error(message.no_bank_account);
    }

    if (datas.error !== undefined) {
        throw new Error(datas.error.class);
    }

    log.end();
    return { message: message.user_bank_fetch, data: { 'isBankAccountAdded': true } };
    /*
        const user = await db.users.findOne({ '_id': userId }, { 'isBankAccountAdded': 1 });

        if (!user) throw new Error('No record found')

        log.end();
        return { message: 'User bank status fetched successfully.', data: user } */

};

/*
 * functon to update user bank status
 * params :  
 * output : success 
 */
exports.bankSetupUpdate = async(userId, params) => {
    const log = logger.start('user:service:isBankSetup');

    const user = await db.users.findOneAndUpdate({ '_id': userId }, { 'isBankAccountAdded': params.bankSetup });

    if (!user) throw new Error(message.no_record);

    log.end();
    return { message: message.bank_updated, data: {} };

};

/*
 * functon to fetch user security & notifications settings
 * params :  
 * output : success 
 */
exports.viewSettings = async(userId) => {
    const log = logger.start('users:service:settings');


    const user = await db.users.findOne({ _id: userId }, { isBiometric: 1, isEmailNotification: 1, isAppNotification: 1 });


    if (!user) throw new Error(message.details_error);
    log.end();
    return {
        message: message.setting_fetch,
        data: user
    };
};

/*
 * functon to get user referre code
 * params : 
 * output : success 
 */
exports.getReferCode = async(userId) => {
    const log = logger.start('users:service:getReferCode');

    const user = await db.users.findOne({ _id: userId }, { referralCode: 1 });
    if (!user) throw new Error(message.details_error);

    log.end();
    return {
        message: message.refer_fetch,
        data: {
            referralCode: user.referralCode
        }
    };
};

/*
 * functon to set user roundup settings
 * params : userid, params
 * output : success or error
 */
exports.setRoundUp = async(userId, params) => {
    const log = logger.start('users:service:setRoundUp');

    const user = await db.users.findOneAndUpdate({ _id: userId, isDeleted: false }, {
        isRoundUpEnabled: params.isRoundUpEnabled,
        isLockMultiplier: params.isLockMultiplier,
        roundup: {
            gold: params.gold,
            silver: params.silver,
            platinum: params.platinum,
            palladium: params.palladium,
            rhodium: params.rhodium
        }
    });
    if (!user) throw new Error(message.no_user);

    log.end();
    return {
        message: message.roundup_update,
        data: {}
    };
};

/*
 * functon to get user roundup settings
 * params : userid
 * output : success or error
 */
exports.getRoundUp = async(userId) => {
    const log = logger.start('users:service:getRoundUp');

    const user = await db.users.findOne({ _id: userId, isDeleted: false }, {
        isRoundUpEnabled: 1,
        isLockMultiplier: 1,
        roundup: 1
    });
    if (!user) throw new Error(message.no_user);

    log.end();
    return {
        message: message.roundup_fetch,
        data: user
    };
};

/*
 * functon to get user primary account is setup or not
 * params : userid
 * output : success or error
 */
exports.isPrimaryAccountSetup = async(userId) => {
    const log = logger.start('users:service:isPrimaryAccountSetup');

    const user = await db.accounts.findOne({ userId: userId, isPrimary: true });
    if (!user) throw new Error(message.no_primary_acc);

    log.end();
    return {
        message: message.primary_acc_link,
        data: {}
    };
};