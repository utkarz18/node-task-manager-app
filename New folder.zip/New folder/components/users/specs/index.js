'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    signUp: {
        description: 'User signUp',
        notes: 'User signUp',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    }
                }
            }
        },
        validate: {
            payload: validator.signUp.payload,
            failAction: response.failAction
        }
    },
    signUpStep2: {
        description: 'User signUp Signup Step 2',
        notes: 'User signUp step 2',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    }
                }
            }
        },
        validate: {
            payload: validator.signUpStep2.payload,
            failAction: response.failAction
        }
    },
    login: {
        description: 'User manual login',
        notes: 'User login ',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        headers: {
                            schema: {
                                'x-access-token': 'string',
                                description: 'x-logintoken is found in response headers'
                            }
                        },
                        schema: validator.accessGranted
                    },
                    400: {
                        description: 'UnAuthorized User',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        validate: {
            payload: validator.login.payload,
            failAction: response.accessDeniedAction
        }
    },
    loginViaOtp: {
        description: 'User 2nd step login',
        notes: 'User login via OTp ',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        headers: {
                            schema: {
                                'x-access-token': 'string',
                                description: 'x-logintoken is found in response headers'
                            }
                        },
                        schema: validator.accessGranted
                    },
                    400: {
                        description: 'UnAuthorized User',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        validate: {
            payload: validator.loginViaOtp.payload,
            failAction: response.accessDeniedAction
        }
    },
    verifyOtp: {
        description: 'Verify User Mobile number via OTP',
        notes: 'User Verification',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    }
                }
            }
        },
        validate: {
            payload: validator.verifyOtp.payload,
            failAction: response.failAction
        }
    },
    resendOtp: {
        description: 'Resend OTP on registered mobile number',
        notes: 'User resend verification OTP',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    }
                }
            }
        },
        validate: {
            payload: validator.resendOtp.payload,
            failAction: response.failAction
        }
    },
    splashStatus: {
        description: 'Check user can view splash screen or not',
        notes: 'User Splash Screen',
        tags: ['api', 'users'],
        validate: {
            query: validator.splashStatus.query,
            failAction: response.failAction
        }
    },
    verifyEmail: {
        description: 'Verify User Email Id',
        notes: 'User Verification',
        tags: ['api', 'users'],
        validate: {
            query: validator.verifyEmail.query,
            failAction: response.failAction
        }
    },

    checkEmailExists: {
        description: 'Check if email exists on login/signup',
        notes: 'check email',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    }
                }
            }
        },
        validate: {
            payload: validator.checkEmailExists.payload,
            failAction: response.failAction
        }
    },

    forgotPassword: {
        description: 'Forgot Password Api',
        notes: 'Verify email to get reset password Details',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    },
                    400: {
                        description: 'invalid token/user',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        validate: {
            payload: validator.forgot.payload,
            failAction: response.failAction
        }
    },

    resendEmailVerificationLink: {
        description: 'User Resend Verification Link',
        notes: 'To get verification link again on your email id',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    },
                    400: {
                        description: 'invalid token/user',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        validate: {
            payload: validator.resendEmailVerificationLink.payload,
            failAction: response.failAction
        }
    },

    resetPasswordToken: {
        description: 'Verify User for password change',
        notes: 'User Verification For password change',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    },
                    400: {
                        description: 'invalid token/user',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        validate: {
            payload: validator.resetPasswordToken.payload,
            failAction: response.failAction
        }
    },

    changePassword: {
        description: 'User Change Password',
        notes: 'Change/Update Own Password',
        tags: ['api', 'users'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    },
                    400: {
                        description: 'invalid token/user',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        validate: {
            payload: validator.changePassword.payload,
            headers: validator.header,
            failAction: response.failAction
        }
    },
    setNewPassword: {
        description: 'User Password Reset',
        notes: 'To reset password via resetPasswordToken',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    }
                }
            }
        },
        validate: {
            payload: validator.setNewPassword.payload,
            failAction: response.failAction
        }
    },
    logout: {
        description: 'User logout',
        notes: 'User log out from system',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    },
                    400: {
                        description: 'invalid token/user',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            failAction: response.failAction
        }
    },
    welcomeScreen: {
        description: 'Get welcome screen text',
        notes: 'Welcome screen text',
        tags: ['api', 'users'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.welcomeScreen.query,
            failAction: response.failAction
        }
    },
    viewSettings: {
        description: 'Get user settings',
        notes: 'Get user settings',
        tags: ['api', 'users'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.viewSettings.query,
            failAction: response.failAction
        }
    },
    viewProfile: {
        description: 'Get user profile',
        notes: 'Get user profile',
        tags: ['api', 'users'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.viewProfile.query,
            failAction: response.failAction
        }
    },
    updateProfile: {
        description: 'Update user profile',
        notes: 'Update user profile',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    },
                    400: {
                        description: 'invalid token/user',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            payload: validator.updateProfile.payload,
            failAction: response.failAction
        }
    },
    settings: {
        description: 'User security & notifications setting',
        notes: 'User security & notifications setting, setting type - security / notification',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    },
                    400: {
                        description: 'invalid token/user',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            payload: validator.settings.payload,
            failAction: response.failAction
        }
    },
    isBankSetup: {
        description: 'Check is bank setup',
        notes: 'Check is bank setup',
        tags: ['api', 'users'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.isBankSetup.query,
            failAction: response.failAction
        }
    },
    bankSetupUpdate: {
        description: 'Update user bank setup after banksetup at saltedge',
        notes: 'Update user bank setup after banksetup at saltedge',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    },
                    400: {
                        description: 'invalid token/user',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            payload: validator.bankSetupUpdate.payload,
            failAction: response.failAction
        }
    },
    getReferCode: {
        description: 'Get user refer code',
        notes: 'Get user refer code',
        tags: ['api', 'users'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.getReferCode.query,
            failAction: response.failAction
        }
    },
    setRoundUp: {
        description: 'Set roundups for user',
        notes: 'Set roundups for user',
        tags: ['api', 'users'],
        plugins: {
            'hapi-swagger': {
                responses: {
                    200: {
                        description: 'Example of response model in return to success request',
                        schema: validator.success
                    },
                    320: {
                        description: 'Example of response model in return to failure request',
                        schema: validator.failure
                    },
                    400: {
                        description: 'invalid token/user',
                        schema: validator.accessDenied
                    }
                }
            }
        },
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            payload: validator.setRoundUp.payload,
            failAction: response.failAction
        }
    },
    getRoundUp: {
        description: 'Get user roundups',
        notes: 'Get user roundups',
        tags: ['api', 'users'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.getRoundUp.query,
            failAction: response.failAction
        }
    },
    isPrimaryAccountSetup: {
        description: 'Primary account setup status',
        notes: 'Primary account setup status',
        tags: ['api', 'users'],
        pre: [{
            method: context.validateToken,
            assign: 'token'
        }],
        validate: {
            headers: validator.header,
            query: validator.isPrimaryAccountSetup.query,
            failAction: response.failAction
        }
    }
};