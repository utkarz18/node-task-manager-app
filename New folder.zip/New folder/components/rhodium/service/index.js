'use strict';

const md5 = require('md5');