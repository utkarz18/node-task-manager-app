'use strict';

const moment = require('moment');

const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (rhodium) => {
    rhodium.pre('save', function(next) {
        next();
    });

    rhodium.post('save', async(doc) => {});

    rhodium.pre('find', function(next) {
        next();
    });

    rhodium.pre('findOne', function(next) {
        next();
    });
};