'use strict';
const hooks = require('../hooks');

const rhodium = new mongoose.Schema({
    start: { type: String },
    end: { type: String },
    open: { type: Number },
    high: { type: Number },
    low: { type: Number },
    last: { type: Number },
    change: { type: Number },
    changePercent: { type: Number },
    createdAt: { type: Number }
}, {
    versionKey: false
});


hooks.configure(rhodium);
module.exports = rhodium;