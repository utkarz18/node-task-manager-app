'use strict';

const service = require('../service');
const path = require('path');
exports.uploadFile = async(request, h) => {
    try {
        const res = await service.uploadFile(request.payload);
        return response.success(h, res.message, res.data);
    } catch (err) {
        return response.failure(h, err.message);
    }
};