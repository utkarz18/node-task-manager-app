'use strict';

const md5 = require('md5');
const auth = require('../../../utils/offline');
const message = require('../../../utils/messages');
const cloudinary = require('../../../utils/cloudinary')

// exports.uploadFile = async(params) => {
//     const log = logger.start('files:services:uploadFile');
//     const file = await offline.uploadFile(params);

//     return { message: message.file_uploaded, data: { file_name: file } };
// };


exports.uploadFile = async(params) => {
    const log = logger.start('files:services:uploadFile');
    const response = await cloudinary.uploadFile(params);

    return {
        message: message.file_uploaded,
        data: { imageUrl : response.imageUrl }
    };
};