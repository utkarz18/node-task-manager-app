/**
author : Aditi
created_on : 21 Jan 2019
**/
'use strict';
const api = require('../api');
const specs = require('../specs');

module.exports = [{
    method: 'POST',
    path: '/api/files/uploadFile',
    options: specs.uploadFile,
    handler: api.uploadFile
}];