'use strict';
const Joi = require('joi');

module.exports = {
    uploadFile: {
        payload: {
            image: Joi.any().required()
                .meta({ swaggerType: 'file' })
                .description('image'),
            filename: Joi.string().required(),
            maxBytes: Joi.number().required().default(30485760), // 100 mb
            timeout: Joi.boolean().required().default('false'),
            parse: Joi.boolean().required().default('true'),
        }
    },
    accessGranted: Joi.object({
        isSuccess: Joi.boolean(),
        status: Joi.string(),
        statusCode: Joi.number().default(200),
        data: Joi.object({
            id: Joi.string(),
            firstName: Joi.string(),
            lastName: Joi.string(),
            email: Joi.string(),
            secondaryEmail: Joi.string(),
            role: Joi.number(),
            pic: Joi.string(),
            qualification: Joi.object({
                id: Joi.string(),
                name: Joi.string()
            }),
            gender: Joi.string(),
            dob: Joi.date().default(new Date().toISOString()),
            address: Joi.object({
                street: Joi.string(),
                city: Joi.string(),
                state: Joi.string(),
                country: Joi.string()
            }),
            isCompleted: Joi.boolean(),
            isVerified: Joi.boolean(),
            isSuspended: Joi.boolean(),
            isDeleted: Joi.boolean(),
            createdAt: Joi.date().default(new Date().toISOString()),
            updatedAt: Joi.date().default(new Date().toISOString())
        })
    }),
    accessDenied: Joi.object({
        isSuccess: Joi.boolean().default(false),
        status: Joi.string(),
        statusCode: Joi.number().default(400),
        message: Joi.string()
    }),
    failure: Joi.object({
        isSuccess: Joi.boolean().default(false),
        status: Joi.string(),
        statusCode: Joi.number().default(320),
        message: Joi.string()
    }),
    success: Joi.object({
        isSuccess: Joi.boolean(),
        status: Joi.string(),
        statusCode: Joi.number().default(200),
        message: Joi.string()
    }),
    header: Joi.object({
        'x-logintoken': Joi.string().required().trim().description('Provide token to access api')
    }).unknown()
};