'use strict';

const mapper = require('../mapper');
const service = require('../service');
const path = require('path');

/*
 * function : get page data
 * params : slug
 * output : success & failure with details
 */
exports.getPageData = async(request, h) => {
    const log = logger.start('pages:api:getPageData');
    try {
        const message = await service.getPageData(request.query);
        log.end();
        return response.success(h, message);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};