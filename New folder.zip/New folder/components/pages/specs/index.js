'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    getPageData: {
        description: 'Get static page data',
        notes: 'Get static page data , Input slug - (legal/privacy)',
        tags: ['api', 'pages'],
        /* pre: [{
            method: context.validateToken,
            assign: 'token'
        }], */
        validate: {
            // headers: validator.header,
            query: validator.getPageData.query,
            failAction: response.failAction
        }
    }
};