'use strict';
const hooks = require('../hooks');

const page = new mongoose.Schema({
    meta_key: { type: String },
    meta_value: { type: String },
    status: { type: Number },
    created_at: { type: Number },
    updated_at: { type: Number }
}, {
    versionKey: false
});


hooks.configure(page);
module.exports = page;