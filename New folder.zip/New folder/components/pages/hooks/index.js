'use strict';

const moment = require('moment');

const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (page) => {
    page.pre('save', function(next) {
        next();
    });

    page.post('save', async(doc) => {});

    page.pre('find', function(next) {
        next();
    });

    page.pre('findOne', function(next) {
        next();
    });
};