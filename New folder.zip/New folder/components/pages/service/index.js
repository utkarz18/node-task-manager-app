'use strict';

const md5 = require('md5');
const twilio = require('twilio');
const twilioCredentials = require('config').get('TWILIO_CREDENTIALS');
const auth = require('../../../utils/auth');
const config = require('config');
const message = require('../../../utils/messages');

/*
 * function : get page data
 * params : slug
 * output : success & failure with details
 */
exports.getPageData = async(params) => {
    const log = logger.start('pages:service:getPageData');

    const page = await db.pages.findOne({
        meta_key: params.slug
    });
    if (!page) throw new Error(message.no_page);

    log.end();
    return {
        'message': message.page_data,
        data: page
    };
};