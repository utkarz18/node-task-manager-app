'use strict';
const api = require('../api');
const specs = require('../specs');

module.exports = [{
    method: 'GET',
    path: '/api/pages/getPageData',
    options: specs.getPageData,
    handler: api.getPageData
}];