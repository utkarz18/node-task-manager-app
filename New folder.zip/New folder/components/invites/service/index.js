'use strict';

const md5 = require('md5');
const twilio = require('twilio');
const twilioCredentials = require('config').get('TWILIO_CREDENTIALS');
const auth = require('../../../utils/auth');