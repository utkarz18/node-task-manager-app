'use strict';
const hooks = require('../hooks');

const invite = new mongoose.Schema({
    invited_by: { type: mongoose.Schema.Types.ObjectId, ref: 'users' },
    invited_to: { type: mongoose.Schema.Types.ObjectId, ref: 'users' },
    status: { type: Number },
    created_at: { type: Number }
}, {
    versionKey: false
});


hooks.configure(invite);
module.exports = invite;