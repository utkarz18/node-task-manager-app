'use strict';

const moment = require('moment');

const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (invite) => {
    invite.pre('save', function(next) {
        next();
    });

    invite.post('save', async(doc) => {});

    invite.pre('find', function(next) {
        next();
    });

    invite.pre('findOne', function(next) {
        next();
    });
};