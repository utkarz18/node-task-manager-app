'use strict';

const mapper = require('../mapper');
const service = require('../service');
const path = require('path');

exports.getCountries = async(request, h) => {
    const log = logger.start('countries:api:getCountries');
    try {
        const res = await service.getCountries(request.query);
        log.end();

        if (typeof(res) === 'string') {
            return response.failure(h, res);
        }
        return response.success(h, res.message, res.data);
    } catch (err) {
        log.error(err);
        log.end();
        return response.accessDenied(h, err.message);
    }
};