'use strict';

exports.toModel = (entity) => {
    const model = {
        id: entity._id,
        name: entity.name,
        code: entity.code
    };

    return model;
};