'use strict';

const md5 = require('md5');
const twilio = require('twilio');
const twilioCredentials = require('config').get('TWILIO_CREDENTIALS');
const auth = require('../../../utils/auth');
const message = require('../../../utils/messages');

exports.getCountries = async(name) => {
    const log = logger.start('countries:services:getCountries');

    const countryList = await db.countries.find({});
    log.end();

    return {
        message: message.country_list,
        data: countryList
    };
};