'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    getCountries: {
        description: 'Get list of all countries',
        notes: 'Countries List',
        tags: ['api', 'countries'],
        validate: {
            query: validator.getCountries.query,
            failAction: response.failAction
        }
    }
};