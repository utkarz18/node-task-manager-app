'use strict';

const moment = require('moment');

const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (country) => {
    country.pre('save', function(next) {
        next();
    });

    country.post('save', async(doc) => {});

    country.pre('find', function(next) {
        next();
    });

    country.pre('findOne', function(next) {
        next();
    });
};