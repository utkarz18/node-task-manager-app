'use strict';
const hooks = require('../hooks');

const country = new mongoose.Schema({
    name: { type: String },
    code: { type: String },
}, {
    versionKey: false
});


hooks.configure(country);
module.exports = country;