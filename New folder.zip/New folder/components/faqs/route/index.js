'use strict';
const api = require('../api');
const specs = require('../specs');

module.exports = [{
    method: 'GET',
    path: '/api/faqs/getFaqs',
    options: specs.getFaqs,
    handler: api.getFaqs
}, {
    method: 'GET',
    path: '/api/faqs/faqDetail',
    options: specs.faqDetail,
    handler: api.faqDetail
}];