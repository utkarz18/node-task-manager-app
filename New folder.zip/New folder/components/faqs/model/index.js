'use strict';
const hooks = require('../hooks');

const faq = new mongoose.Schema({
    answer: { type: String },
    question: { type: String },
    status: { type: Number },
    created_at: { type: Number },
    updated_at: { type: Number }
}, {
    versionKey: false
});


hooks.configure(faq);
module.exports = faq;