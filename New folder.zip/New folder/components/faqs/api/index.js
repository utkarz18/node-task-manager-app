'use strict';

const mapper = require('../mapper');
const service = require('../service');
const path = require('path');

exports.getFaqs = async(request, h) => {
    const log = logger.start('faqs:api:getFaqs');
    try {
        const message = await service.getFaqs(request.query);
        log.end();
        return response.success(h, message);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};

exports.faqDetail = async(request, h) => {
    const log = logger.start('faqs:api:faqDetail');
    try {
        const message = await service.faqDetail(request.query);
        log.end();
        return response.success(h, message);
    } catch (err) {
        log.error(err);
        log.end();
        return response.failure(h, err.message);
    }
};