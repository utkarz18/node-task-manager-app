'use strict';
const validator = require('../validator');
const context = require('../../../utils/context-builder');

module.exports = {
    getFaqs: {
        description: 'Get faqs data',
        notes: 'Get faqs data)',
        tags: ['api', 'faqs'],
        /* pre: [{
            method: context.validateToken,
            assign: 'token'
        }], */
        validate: {
            //   headers: validator.header,
            query: validator.getFaqs.query,
            failAction: response.failAction
        }
    },
    faqDetail: {
        description: 'Get faqs detail',
        notes: 'Get faqs detail)',
        tags: ['api', 'faqs'],
        /* pre: [{
            method: context.validateToken,
            assign: 'token'
        }], */
        validate: {
            // headers: validator.header,
            query: validator.faqDetail.query,
            failAction: response.failAction
        }
    }
};