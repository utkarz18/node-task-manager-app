'use strict';

const moment = require('moment');

const populate = (doc) => {
    return new Promise((resolve, reject) => {
        doc.populate([{}], (err, res) => {
            if (err) {
                return reject(err);
            }
            return resolve();
        });
    });
};

exports.configure = (faq) => {
    faq.pre('save', function(next) {
        next();
    });

    faq.post('save', async(doc) => {});

    faq.pre('find', function(next) {
        next();
    });

    faq.pre('findOne', function(next) {
        next();
    });
};