'use strict';

const md5 = require('md5');
const auth = require('../../../utils/auth');
const config = require('config');
const message = require('../../../utils/messages');


exports.getFaqs = async(params) => {
    const log = logger.start('faqs:service:getFaqs');

    if (params.search && params.search !== '') {
        var condition = {
            'status': 1,
            $or: [{ question: { $regex: '.*' + params.search + '.*', $options: 'i' } }, { answer: { $regex: '.*' + params.search + '.*', $options: 'i' } }]
        };
    } else {
        var condition = {
            'status': 1
        };
    }

    var skip = (params.page - 1) * 10;
    const faqs = await db.faqs.find(condition).skip(skip).limit(10);

    if (!faqs) {
        throw new Error(message.no_record);
    }

    const total = await db.faqs.count(condition);

    log.end();
    return {
        'message': message.faq_fetch,
        'data': { 'faqData': faqs, 'total': total }
    };
};

exports.faqDetail = async(params) => {
    const log = logger.start('faqs:service:faqDetail');

    const faq = await db.faqs.findOne({ _id: params.faq_id });

    if (!faq) throw new Error('No records found.');

    const relatedQuestion = await db.faqs.find({ 'status': 1, _id: { $ne: params.faq_id } }, { 'question': 1, '_id': 1 }).limit(5);

    log.end();
    return {
        'message': message.faq_fetch,
        'data': { 'faqData': faq, 'relatedQuestion': relatedQuestion }
    };
};