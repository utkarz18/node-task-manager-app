// File for validating acess token
'use strict';
const auth = require('./auth');
const response = require('./responses');

const builder = (user, token) => {
    const context = {};
    context.user = user;
    context.token = token;

    return context;
};

exports.validateToken = async(request, h) => {
    logger.start('Check accessToken');
    const token = request.headers['x-logintoken'];

    if (!token) {
        return response.accessRevoked(h, 'user token is required');
    }

    const userId = await auth.verifyToken(token);

    if (!userId) {
        return response.accessRevoked(h, 'invalid token');
    }
    const user = await db.users.findById(userId.id);

    if ((!user) || (user && !user.isVerified) || (user && user.isDeleted)) {
        return response.accessRevoked(h, 'token expired');
    }

    const tokenExists = await db.users.findOne({
        'accessToken': {
            '$in': [token]
        }
    });

    if (!tokenExists) {
        return response.accessRevoked(h, 'token expired');
    }

    // eslint-disable-next-line require-atomic-updates
    request.userInfo = user;

    return h;
};

exports.validateAdminToken = async(request, h) => {
    logger.start('Check accessToken');
    const token = request.headers['admin_access_token'];

    if (!token) {
        return response.accessRevoked(h, 'user token is required');
    }

    const userId = await auth.verifyToken(token);

    if (!userId) {
        return response.accessRevoked(h, 'invalid token');
    }
    const user = await db.users.findById(userId.id);

    if ((!user) || (user && !user.isVerified) || (user && user.isDeleted)) {
        return response.accessRevoked(h, 'token expired');
    }

    const tokenExists = await db.users.findOne({
        'accessToken': {
            '$in': [token]
        }
    });

    if (!tokenExists) {
        return response.accessRevoked(h, 'token expired');
    }

    // eslint-disable-next-line require-atomic-updates
    request.userInfo = user;

    return h;
};


exports.requiresManipulation = async(request, h) => {
    if (!request.context) {
        request.context = {
            logger: require('@open-age/logger')()
        };
    }

    const manipulator = 'con' + request.route.settings.handler.name.charAt(0).toUpperCase() + request.route.settings.handler.name.slice(1);
    let source = request.route.settings.pre.find((value) => {
        return value.assign.split(':')[0] === 'manipulate';
    });

    source = source.assign.split(':')[1];
    if (!source) {
        return h;
    }

    const isManipulator = require(`../components/${source}/middleware`)[manipulator];

    if (!isManipulator) {
        return h;
    }

    try {
        return isManipulator(request, h);
    } catch (err) {
        return response.failure(h, err.message);
    }
};