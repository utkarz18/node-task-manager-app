'use strict';

const path = require('path');
const fs = require('fs');
const appRoot = require('app-root-path');


const applicationToken = () => {
    var jwt = require('jsonwebtoken');
    var privateKey = fs.readFileSync(path.join(appRoot.path, '/utils/private.key'), 'utf8'); // Location of the file with your private key
    var payload = {};
    var currentTime = Math.floor(Date.now() / 1000);
    var signOptions = {
        algorithm: 'RS512' // Yodlee requires RS512 algorithm when encoding JWT
    };

    payload.iss = '0098e798-f5e954e4-a111-4f59-9828-d7a0d98e59ad'; // The issuer id from the API Dashboard
    payload.iat = currentTime; // Epoch time when token is issued in seconds
    payload.exp = currentTime + 1800; // Epoch time when token is set to expire. Must be 1800 seconds 


    var token = jwt.sign(payload, privateKey, signOptions);
    return token;
};

const userToken = (loginName) => {
    var jwt = require('jsonwebtoken');

    var privateKey = fs.readFileSync(path.join(appRoot.path, '/utils/private.key'), 'utf8'); // Location of the file with your private key
    var payload = {};
    var currentTime = Math.floor(Date.now() / 1000);
    var signOptions = {
        algorithm: 'RS512'
    };

    payload.iss = '0098e798-f5e954e4-a111-4f59-9828-d7a0d98e59ad';
    payload.iat = currentTime;
    payload.exp = currentTime + 1800;
    payload.sub = loginName; // "sbMemeEqVSATtKXMIS4";

    var token = jwt.sign(payload, privateKey, signOptions);
    return token;
};

exports.applicationToken = applicationToken;
exports.userToken = userToken;