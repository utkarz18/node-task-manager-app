'use strict';

var fs = require('fs');
var cloudinary = require('cloudinary').v2;


exports.uploadFile = async (data) => {
    if (!data.filename) return failAction('Type is not allowed!');
    return new Promise((resolve, reject) => {
        uploadFileToServer(data, (err, response) => {
            if (err) {
                return reject(err);
            } 
            return resolve(response);
        });
    });
}

const uploadFileToServer = async (data, cb) => {
    let randomNumber = Math.floor(Math.random() * (999999 - 999 + 1)) + 999999;
    const filename = `${randomNumber}_${data.filename}`;
    const datas = data.image._data;
    const filePath = 'assets/' + filename;

    // uploading file to server
    fs.writeFile(filePath, datas, err => {
        if (err) {
            cb(err, null);
        }
        logger.info(filename + ' uploaded to Server');
    });

    // uploading file to cloudinary
    cloudinary.uploader.upload(filePath, { tags: 'AmassMetals', quality: "auto:eco", folder: 'AmassMetals' }, function (err, image) {
        if (err) {
            cb(err, null);
        }
        logger.info(filename + ' uploaded to  Cloudinary');
        fs.unlinkSync(filePath);
        const response = {
            imageUrl: image.url,
            fileName: filename
        };
        cb(null, response);
    });
}